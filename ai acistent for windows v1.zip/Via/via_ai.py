"""
via_ai.py - Via's eigenes Gehirn, komplett von null in reinem NumPy.

Enthält alles, was eine KI braucht:
  * Zeichen-Tokenizer
  * GPT-Transformer (Embeddings, Self-Attention, MLP, LayerNorm)
  * Rückwärtslauf (Backpropagation) von Hand
  * Adam-Optimizer
  * schnelle Textgenerierung mit KV-Cache

Kein PyTorch, kein TensorFlow, kein fertiges Modell, nichts Fremdes.
"""
import json
import math
import re
import numpy as np

SQRT_2PI = math.sqrt(2.0 / math.pi)


# ───────────────────────────── Tokenizer ─────────────────────────────────
def norm_user(text):
    """So sieht Via die Eingabe: klein, ohne Satzzeichen (wie die Spracherkennung sie liefert)."""
    t = text.lower()
    t = re.sub(r"[^a-z0-9äöüß ]+", " ", t)
    return re.sub(r"\s+", " ", t).strip()


PRETOK = re.compile(r" ?[A-Za-zÄÖÜäöüß]+| ?\d+| ?[^\sA-Za-zÄÖÜäöüß\d]+|\n| ")


class Tokenizer:
    """Einfacher Zeichen-Tokenizer (kind='char')."""
    kind = "char"

    def __init__(self, chars):
        self.chars = list(chars)
        self.stoi = {c: i for i, c in enumerate(self.chars)}

    def encode(self, s):
        return [self.stoi[c] for c in s if c in self.stoi]

    def encode_offsets(self, s):
        ids = self.encode(s)
        return ids, list(range(len(ids)))

    def decode(self, ids):
        return "".join(self.chars[i] for i in ids)

    def piece(self, i):
        return self.chars[i]

    @property
    def size(self):
        return len(self.chars)

    def to_json(self):
        return {"kind": "char", "chars": self.chars}


class BPETokenizer:
    """Eigener Byte-Pair-Encoding-Tokenizer (kind='bpe'): häufige Buchstabenfolgen werden zu einem Token."""
    kind = "bpe"

    def __init__(self, chars, merges):
        self.chars = list(chars)
        self.merges = [tuple(m) for m in merges]
        self.vocab = self.chars + [a + b for a, b in self.merges]
        self.stoi = {t: i for i, t in enumerate(self.vocab)}
        self.known = set(self.chars)
        self.rank = {m: i for i, m in enumerate(self.merges)}
        self.cache = {}

    def _bpe(self, w):
        if w in self.cache:
            return self.cache[w]
        sym = list(w)
        while len(sym) > 1:
            best = None
            for i in range(len(sym) - 1):
                r = self.rank.get((sym[i], sym[i + 1]))
                if r is not None and (best is None or r < best[0]):
                    best = (r, sym[i], sym[i + 1])
            if best is None:
                break
            _, x, y = best
            out, i = [], 0
            while i < len(sym):
                if i < len(sym) - 1 and sym[i] == x and sym[i + 1] == y:
                    out.append(x + y); i += 2
                else:
                    out.append(sym[i]); i += 1
            sym = out
        self.cache[w] = sym
        return sym

    def encode_offsets(self, s):
        s = "".join(c for c in s if c in self.known)
        ids, offs, pos = [], [], 0
        for w in PRETOK.findall(s):
            for t in self._bpe(w):
                ids.append(self.stoi[t]); offs.append(pos); pos += len(t)
        return ids, offs

    def encode(self, s):
        return self.encode_offsets(s)[0]

    def decode(self, ids):
        return "".join(self.vocab[i] for i in ids)

    def piece(self, i):
        return self.vocab[i]

    @property
    def size(self):
        return len(self.vocab)

    def to_json(self):
        return {"kind": "bpe", "chars": self.chars, "merges": [list(m) for m in self.merges]}


def train_bpe(text, n_merges, chars):
    """Lernt die häufigsten Buchstabenpaare aus dem Trainingstext (von null, ohne Bibliothek)."""
    from collections import Counter
    words = Counter(PRETOK.findall(text))
    seqs = {w: list(w) for w in words}
    merges = []
    for _ in range(n_merges):
        pc = Counter()
        for w, c in words.items():
            sq = seqs[w]
            for i in range(len(sq) - 1):
                pc[(sq[i], sq[i + 1])] += c
        if not pc:
            break
        (x, y), n = pc.most_common(1)[0]
        if n < 3:
            break
        merges.append((x, y))
        for w in words:
            sq = seqs[w]
            if x in sq:
                out, i = [], 0
                while i < len(sq):
                    if i < len(sq) - 1 and sq[i] == x and sq[i + 1] == y:
                        out.append(x + y); i += 2
                    else:
                        out.append(sq[i]); i += 1
                seqs[w] = out
    return BPETokenizer(chars, merges)


def tokenizer_from_json(d):
    if d.get("kind") == "bpe":
        return BPETokenizer(d["chars"], d["merges"])
    return Tokenizer(d["chars"])


# ───────────────────────────── Parameter ─────────────────────────────────
def init_params(cfg, seed=0, dtype=np.float32):
    V, T, D, L = cfg["V"], cfg["T"], cfg["D"], cfg["L"]
    rng = np.random.default_rng(seed)
    s, so = 0.02, 0.02 / math.sqrt(2 * L)
    p = {"wte": rng.normal(0, s, (V, D)), "wpe": rng.normal(0, s, (T, D)),
         "lnfg": np.ones(D), "lnfb": np.zeros(D)}
    for l in range(L):
        q = f"l{l}."
        p[q + "ln1g"], p[q + "ln1b"] = np.ones(D), np.zeros(D)
        p[q + "wqkv"], p[q + "bqkv"] = rng.normal(0, s, (D, 3 * D)), np.zeros(3 * D)
        p[q + "wo"], p[q + "bo"] = rng.normal(0, so, (D, D)), np.zeros(D)
        p[q + "ln2g"], p[q + "ln2b"] = np.ones(D), np.zeros(D)
        p[q + "w1"], p[q + "b1"] = rng.normal(0, s, (D, 4 * D)), np.zeros(4 * D)
        p[q + "w2"], p[q + "b2"] = rng.normal(0, so, (4 * D, D)), np.zeros(D)
    return {k: v.astype(dtype) for k, v in p.items()}


def count_params(p):
    return sum(v.size for v in p.values())


# ───────────────────────────── Bausteine ─────────────────────────────────
def ln_f(x, g, b, eps=1e-5):
    xc = x - x.mean(-1, keepdims=True)
    rstd = 1.0 / np.sqrt((xc * xc).mean(-1, keepdims=True) + eps)
    xh = xc * rstd
    return xh * g + b, (xh, rstd, g)


def ln_b(dy, c):
    xh, rstd, g = c
    dxh = dy * g
    dx = rstd * (dxh - dxh.mean(-1, keepdims=True) - xh * (dxh * xh).mean(-1, keepdims=True))
    D = dy.shape[-1]
    return dx, (dy * xh).reshape(-1, D).sum(0), dy.reshape(-1, D).sum(0)


def gelu(x):
    return 0.5 * x * (1.0 + np.tanh(SQRT_2PI * (x + 0.044715 * x ** 3)))


def gelu_grad(x):
    t = np.tanh(SQRT_2PI * (x + 0.044715 * x ** 3))
    return 0.5 * (1 + t) + 0.5 * x * (1 - t * t) * SQRT_2PI * (1 + 3 * 0.044715 * x * x)


# ───────────────────────────── Vorwärtslauf ──────────────────────────────
def forward(p, cfg, idx):
    B, T = idx.shape
    D, H, L = cfg["D"], cfg["H"], cfg["L"]
    hd = D // H
    scale = 1.0 / math.sqrt(hd)
    x = p["wte"][idx] + p["wpe"][:T]
    mask = np.triu(np.ones((T, T), dtype=bool), 1)
    caches = []
    for l in range(L):
        q = f"l{l}."
        h, c1 = ln_f(x, p[q + "ln1g"], p[q + "ln1b"])
        qkv = h @ p[q + "wqkv"] + p[q + "bqkv"]
        qq, kk, vv = np.split(qkv, 3, axis=-1)
        qh, kh, vh = (t.reshape(B, T, H, hd).transpose(0, 2, 1, 3) for t in (qq, kk, vv))
        s = (qh @ kh.transpose(0, 1, 3, 2)) * scale
        s = np.where(mask, -1e9, s)
        s = s - s.max(-1, keepdims=True)
        a = np.exp(s)
        a /= a.sum(-1, keepdims=True)
        y = (a @ vh).transpose(0, 2, 1, 3).reshape(B, T, D)
        x1 = x + y @ p[q + "wo"] + p[q + "bo"]
        h2, c2 = ln_f(x1, p[q + "ln2g"], p[q + "ln2b"])
        u = h2 @ p[q + "w1"] + p[q + "b1"]
        g = gelu(u)
        x = x1 + g @ p[q + "w2"] + p[q + "b2"]
        caches.append((h, c1, qh, kh, vh, a, y, h2, c2, u, g))
    hf, cf = ln_f(x, p["lnfg"], p["lnfb"])
    logits = hf @ p["wte"].T
    return logits, (idx, caches, hf, cf)


def loss_and_grad_logits(logits, targets, weights):
    z = logits - logits.max(-1, keepdims=True)
    e = np.exp(z)
    probs = e / e.sum(-1, keepdims=True)
    B, T, V = logits.shape
    flat = probs.reshape(-1, V)
    tg = targets.reshape(-1)
    w = weights.reshape(-1)
    wsum = max(float(w.sum()), 1e-9)
    nll = -np.log(flat[np.arange(len(tg)), tg] + 1e-12)
    loss = float((nll * w).sum() / wsum)
    d = flat.copy()
    d[np.arange(len(tg)), tg] -= 1.0
    d *= (w / wsum)[:, None]
    return loss, d.reshape(B, T, V).astype(logits.dtype)


# ───────────────────────────── Rückwärtslauf ─────────────────────────────
def backward(p, cfg, cache, dlogits):
    idx, caches, hf, cf = cache
    B, T = idx.shape
    D, H, L, V = cfg["D"], cfg["H"], cfg["L"], cfg["V"]
    hd = D // H
    scale = 1.0 / math.sqrt(hd)
    g = {k: np.zeros_like(v) for k, v in p.items()}

    g["wte"] += dlogits.reshape(-1, V).T @ hf.reshape(-1, D)
    dhf = dlogits @ p["wte"]
    dx, g["lnfg"], g["lnfb"] = ln_b(dhf, cf)

    for l in reversed(range(L)):
        q = f"l{l}."
        h, c1, qh, kh, vh, a, y, h2, c2, u, gl = caches[l]
        # MLP
        g[q + "w2"] = gl.reshape(-1, 4 * D).T @ dx.reshape(-1, D)
        g[q + "b2"] = dx.reshape(-1, D).sum(0)
        du = (dx @ p[q + "w2"].T) * gelu_grad(u)
        g[q + "w1"] = h2.reshape(-1, D).T @ du.reshape(-1, 4 * D)
        g[q + "b1"] = du.reshape(-1, 4 * D).sum(0)
        dh2 = du @ p[q + "w1"].T
        dx1, g[q + "ln2g"], g[q + "ln2b"] = ln_b(dh2, c2)
        dx1 = dx1 + dx
        # Attention
        g[q + "wo"] = y.reshape(-1, D).T @ dx1.reshape(-1, D)
        g[q + "bo"] = dx1.reshape(-1, D).sum(0)
        dy = (dx1 @ p[q + "wo"].T).reshape(B, T, H, hd).transpose(0, 2, 1, 3)
        da = dy @ vh.transpose(0, 1, 3, 2)
        dvh = a.transpose(0, 1, 3, 2) @ dy
        ds = a * (da - (da * a).sum(-1, keepdims=True)) * scale
        dqh = ds @ kh
        dkh = ds.transpose(0, 1, 3, 2) @ qh
        dqkv = np.concatenate([t.transpose(0, 2, 1, 3).reshape(B, T, D) for t in (dqh, dkh, dvh)], axis=-1)
        g[q + "wqkv"] = h.reshape(-1, D).T @ dqkv.reshape(-1, 3 * D)
        g[q + "bqkv"] = dqkv.reshape(-1, 3 * D).sum(0)
        dh = dqkv @ p[q + "wqkv"].T
        dxa, g[q + "ln1g"], g[q + "ln1b"] = ln_b(dh, c1)
        dx = dxa + dx1

    g["wpe"][:T] += dx.sum(0)
    np.add.at(g["wte"], idx, dx)
    return g


# ───────────────────────────── Adam ──────────────────────────────────────
class Adam:
    def __init__(self, params, b1=0.9, b2=0.99, eps=1e-8, wd=0.01):
        self.m = {k: np.zeros_like(v) for k, v in params.items()}
        self.v = {k: np.zeros_like(v) for k, v in params.items()}
        self.t, self.b1, self.b2, self.eps, self.wd = 0, b1, b2, eps, wd

    def step(self, params, grads, lr, clip=1.0):
        norm = math.sqrt(sum(float((g * g).sum()) for g in grads.values()))
        k = min(1.0, clip / (norm + 1e-6))
        self.t += 1
        c1, c2 = 1 - self.b1 ** self.t, 1 - self.b2 ** self.t
        for n, w in params.items():
            gr = grads[n] * k
            self.m[n] = self.b1 * self.m[n] + (1 - self.b1) * gr
            self.v[n] = self.b2 * self.v[n] + (1 - self.b2) * gr * gr
            upd = (self.m[n] / c1) / (np.sqrt(self.v[n] / c2) + self.eps)
            if w.ndim >= 2 and n not in ("wte", "wpe"):
                upd = upd + self.wd * w
            w -= lr * upd
        return norm


# ───────────────────────────── Speichern / Laden ─────────────────────────
def save_model(path, params, cfg, tok):
    np.savez_compressed(path, cfg=json.dumps(cfg), tok=json.dumps(tok.to_json(), ensure_ascii=False),
                        **{"p_" + k: v for k, v in params.items()})


def load_model(path):
    z = np.load(path, allow_pickle=False)
    cfg = json.loads(str(z["cfg"]))
    if "tok" in z.files:
        tok = tokenizer_from_json(json.loads(str(z["tok"])))
    else:
        tok = Tokenizer(json.loads(str(z["chars"])))
    params = {k[2:]: z[k].astype(np.float32) for k in z.files if k.startswith("p_")}
    return params, cfg, tok


# ───────────────────────────── Generieren (schnell, mit KV-Cache) ────────
class Generator:
    def __init__(self, path):
        self.p, self.cfg, self.tok = load_model(path)
        c = self.cfg
        self.T, self.D, self.H, self.L = c["T"], c["D"], c["H"], c["L"]
        self.hd = self.D // self.H
        self.rng = np.random.default_rng()
        self.lp = []              # Log-Wahrscheinlichkeit jedes gewählten Zeichens (Selbstsicherheit)
        self.reset()

    def reset(self):
        self.K = np.zeros((self.L, self.T, self.H, self.hd), np.float32)
        self.V = np.zeros_like(self.K)
        self.pos = 0

    def _ln(self, x, g, b):
        xc = x - x.mean()
        return xc / math.sqrt(float((xc * xc).mean()) + 1e-5) * g + b

    def step(self, tok):
        p, D, H, hd = self.p, self.D, self.H, self.hd
        pos = self.pos
        x = p["wte"][tok] + p["wpe"][pos]
        scale = 1.0 / math.sqrt(hd)
        for l in range(self.L):
            q = f"l{l}."
            h = self._ln(x, p[q + "ln1g"], p[q + "ln1b"])
            qkv = h @ p[q + "wqkv"] + p[q + "bqkv"]
            self.K[l, pos] = qkv[D:2 * D].reshape(H, hd)
            self.V[l, pos] = qkv[2 * D:].reshape(H, hd)
            qh = qkv[:D].reshape(H, hd)
            s = np.einsum("hd,thd->ht", qh, self.K[l, :pos + 1]) * scale
            s -= s.max(-1, keepdims=True)
            a = np.exp(s)
            a /= a.sum(-1, keepdims=True)
            y = np.einsum("ht,thd->hd", a, self.V[l, :pos + 1]).reshape(D)
            x = x + y @ p[q + "wo"] + p[q + "bo"]
            h2 = self._ln(x, p[q + "ln2g"], p[q + "ln2b"])
            x = x + gelu(h2 @ p[q + "w1"] + p[q + "b1"]) @ p[q + "w2"] + p[q + "b2"]
        self.pos += 1
        return self._ln(x, p["lnfg"], p["lnfb"]) @ p["wte"].T

    def sample(self, logits, temp=0.6, top_k=10):
        if temp <= 0:
            return int(np.argmax(logits))
        l = logits / temp
        if top_k and top_k < len(l):
            thr = np.partition(l, -top_k)[-top_k]
            l = np.where(l < thr, -1e9, l)
        l = l - l.max()
        pr = np.exp(l)
        pr /= pr.sum()
        return int(self.rng.choice(len(pr), p=pr))

    def stream_chars(self, prompt, max_new=140, temp=0.6, top_k=10, stop="\n"):
        """Gibt die Antwort Stück für Stück zurück (ein Stück = ein Token)."""
        keep = self.T - (24 if self.tok.kind == "char" else 56)
        ids = self.tok.encode(prompt)[-keep:]
        self.reset()
        self.lp = []
        logits = None
        for t in ids:
            logits = self.step(t)
        for _ in range(max_new):
            if self.pos >= self.T:
                return
            t = self.sample(logits, temp, top_k)
            mx = float(logits.max())
            self.lp.append(float(logits[t]) - mx - math.log(float(np.exp(logits - mx).sum())))
            piece = self.tok.piece(t)
            if stop in piece:
                head = piece.split(stop)[0]
                if head:
                    yield head
                return
            yield piece
            logits = self.step(t)

    def confidence(self):
        """Mittlere Log-Wahrscheinlichkeit der letzten Antwort (näher an 0 = sicherer)."""
        return float(np.mean(self.lp)) if self.lp else -9.0
