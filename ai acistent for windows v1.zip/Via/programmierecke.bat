@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist venv\Scripts\python.exe (
    echo Bitte zuerst start.bat ausfuehren.
    pause
    exit /b 1
)
start "" venv\Scripts\pythonw.exe codelab.py
