#!/usr/bin/env python3
"""
train.py - Training auf der Kommandozeile (die komfortable Variante ist trainer_app.py).

  python make_data.py                       # Trainingsdaten erzeugen
  python train.py                           # neu trainieren (kleines Gehirn)
  python train.py --size mittel --steps 8000
  python train.py --resume --steps 12000    # weitertrainieren
"""
import argparse
import sys

import trainer as tr


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--size", choices=list(tr.PRESETS), default="klein")
    ap.add_argument("--steps", type=int, default=4000)
    ap.add_argument("--batch", type=int, default=24)
    ap.add_argument("--ctx", type=int, default=96)
    ap.add_argument("--merges", type=int, default=1200)
    ap.add_argument("--lr", type=float, default=None)
    ap.add_argument("--resume", action="store_true")
    a = ap.parse_args()
    t = tr.Trainer()
    t.prepare(a.size, a.ctx, a.merges, a.resume)

    def on_step(step, total, loss, lr, sps):
        if step % 20 == 0 or step == 1:
            rest = (total - step) / max(sps, 1e-9) / 60
            print(f"Schritt {step:6d}/{total}  Verlust {loss:.3f}  {sps:.2f} Schritte/s  Rest ca. {rest:.0f} min", flush=True)

    def on_sample(step, res):
        for q, a_ in res:
            print(f"   Du: {q}\n   Via: {a_}")
        sys.stdout.flush()

    try:
        t.run(a.steps, a.batch, a.lr, on_step, sample_every=500, on_sample=on_sample)
    except KeyboardInterrupt:
        t.save()
        print("Abgebrochen, Stand gespeichert.")
    print("Fertig. Modell:", tr.MODEL)


if __name__ == "__main__":
    main()
