#!/usr/bin/env python3
"""
Via - lokaler Sprachassistent (kein Ollama, keine API, keine Cloud)

  Zuhören  : Vosk (offline, streaming)
  Verstehen: Vias eigenes, selbst gebautes und trainiertes neuronales Netz (via_ai.py,
             reines NumPy, GPT-Architektur) fürs freie Gespräch
             + schnelle Regel-Engine für Timer, Wetter, Uhrzeit, Datum, Rechnen
  Sprechen : Piper (offline, neuronale Stimme "Thorsten")
  Oberfläche: PySide6 - Tray-Icon + Popup oben rechts + Einstellungen

Aktivierung: "Hey Via ..." / "Via ..." / "Hey ..." oder Klick auf die Kugel.
"""
import sys, os, re, json, math, time, wave, io, queue, random, threading, datetime, difflib
import urllib.request, urllib.parse, subprocess
from collections import OrderedDict
from pathlib import Path

import numpy as np
import sounddevice as sd
from vosk import Model, KaldiRecognizer, SetLogLevel
from via_ai import norm_user
import gemini
import llmapi
import webbrowser
from apps import AppLauncher
from PySide6.QtCore import QStringListModel
from PySide6.QtWidgets import QScrollArea, QFileDialog, QCompleter, QListWidget, QGridLayout
from speech import Speaker, Whisper, Segmenter, list_devices, find_device, speakable
from PySide6.QtCore import (Qt, QTimer, QObject, Signal, QPointF, QRectF, QPropertyAnimation)
from PySide6.QtGui import (QPainter, QColor, QRadialGradient, QPen, QFont, QPainterPath,
                           QIcon, QPixmap, QCursor, QGuiApplication, QAction)
from PySide6.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                               QPushButton, QFrame, QLineEdit, QSpinBox, QComboBox, QSlider,
                               QCheckBox, QProgressBar, QDialog, QSystemTrayIcon, QMenu,
                               QGraphicsDropShadowEffect, QLayout, QSizePolicy)

SetLogLevel(-1)

# ───────────────────────────── Konfiguration ─────────────────────────────
BASE = Path(__file__).resolve().parent
MODELS = BASE / "models"
VOSK_DIR = MODELS / "vosk-model-small-de-0.15"
VOICE = MODELS / "de_DE-thorsten-high.onnx"
CFG_FILE = BASE / "config.json"
DEFAULT_CFG = {"city": "München", "lat": 48.1374, "lon": 11.5755,
               "input_device": None, "output_device": None,
               "speak": True, "volume": 0.9, "autohide": 7, "corner": "tr", "pin": False,
               "llm": True, "brain_conf": -0.45,
               "name": "Via", "stt": "whisper-small", "voice": "de_DE-thorsten-high.onnx", "speed": 1.0,
               "mic_gate": 150, "log_chats": True,
               "brain": "own", "gemini_key": "", "gemini_model": "", "apps": {}, "fav_apps": [],
               "llm_provider": "ollama", "ollama_model": "", "ollama_url": "http://127.0.0.1:11434"}
HEY = {"hey", "hei", "hej", "hay", "hallo", "hi"}
CFG = {}


def name():
    return (CFG.get("name") or "Via").strip()


def name_words():
    n = name().lower()
    ws = set(re.findall(r"[a-zäöüß]+", n))
    if n == "via":
        ws |= {"fia", "wia", "viva", "mia"}
    return ws


def rules_text(t):
    """Whisper-Text für die Regel-Engine: klein, ohne Satzzeichen."""
    t = t.lower()
    t = re.sub(r"[„“”\"'()]", " ", t)
    t = re.sub(r"(?<=\w)-(?=\w)", " ", t)
    t = re.sub(r"[.,!?;:](?!\d)", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def log_chat(du, via):
    try:
        if CFG.get("log_chats", True):
            (BASE / "data").mkdir(exist_ok=True)
            with open(BASE / "data" / "gespraeche.txt", "a", encoding="utf-8") as f:
                f.write(f"Du: {norm_user(du)}\nVia: {via}\n\n")
    except Exception:
        pass
SR_IN = 16000
SR_OUT = 22050


def save_cfg(cfg):
    try:
        CFG_FILE.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception as e:
        print("Konfig nicht gespeichert:", e)


def load_cfg():
    cfg = dict(DEFAULT_CFG)
    try:
        cfg.update(json.loads(CFG_FILE.read_text(encoding="utf-8")))
    except Exception:
        save_cfg(cfg)
    if cfg.get("mic_gate") == 350:          # alter Standardwert war zu unempfindlich
        cfg["mic_gate"] = 150
    return cfg


# ───────────────────────────── Async-Helfer ──────────────────────────────
class Bridge(QObject):
    result = Signal(object, object)

    def __init__(self):
        super().__init__()
        self.result.connect(self._invoke)

    def _invoke(self, cb, value):
        cb(value)


BRIDGE = None


def run_async(fn, cb):
    def work():
        try:
            v = fn()
        except Exception as e:
            v = {"error": str(e)}
        BRIDGE.result.emit(cb, v)
    threading.Thread(target=work, daemon=True).start()


# ───────────────────────────── Deutsche Zahlen ───────────────────────────
U = {"null": 0, "ein": 1, "eins": 1, "eine": 1, "einen": 1, "zwei": 2, "drei": 3, "vier": 4,
     "fünf": 5, "sechs": 6, "sieben": 7, "acht": 8, "neun": 9, "zehn": 10, "elf": 11,
     "zwölf": 12, "dreizehn": 13, "vierzehn": 14, "fünfzehn": 15, "sechzehn": 16,
     "siebzehn": 17, "achtzehn": 18, "neunzehn": 19}
T = {"zwanzig": 20, "dreißig": 30, "dreissig": 30, "vierzig": 40, "fünfzig": 50,
     "sechzig": 60, "siebzig": 70, "achtzig": 80, "neunzig": 90}


def parse_word(w):
    if w.isdigit():
        return int(w)
    if w in U:
        return U[w]
    if w in T:
        return T[w]
    m = re.fullmatch(r"(\w*?)hundert(\w*)", w)
    if m:
        pre, rest = m.groups()
        h = U.get(pre, None) if pre else 1
        if h is None:
            return None
        r = parse_word(rest) if rest else 0
        return None if r is None else h * 100 + r
    m = re.fullmatch(r"(\w+?)und(\w+)", w)
    if m and m.group(1) in U and m.group(2) in T:
        return U[m.group(1)] + T[m.group(2)]
    return None


def normalize(text):
    t = text.lower().strip()
    t = re.sub(r"(anderthalb|eineinhalb)\s+stunden?", "90 minuten", t)
    t = re.sub(r"drei\s?viertel\s?stunde", "45 minuten", t)
    t = re.sub(r"(?:eine\s+)?halbe\s+stunde", "30 minuten", t)
    t = re.sub(r"(?:eine\s+)?viertel\s?stunde", "15 minuten", t)
    out = []
    for w in t.split():
        n = parse_word(w)
        out.append(str(n) if n is not None else w)
    return " ".join(out)


def plural(n, one, many):
    return f"{n} {one if n == 1 else many}"


def fmt_dur(sec):
    sec = int(round(sec))
    h, r = divmod(sec, 3600)
    m, s = divmod(r, 60)
    parts = []
    if h: parts.append(plural(h, "Stunde", "Stunden"))
    if m: parts.append(plural(m, "Minute", "Minuten"))
    if s or not parts: parts.append(plural(s, "Sekunde", "Sekunden"))
    return " und ".join([", ".join(parts[:-1]), parts[-1]]) if len(parts) > 1 else parts[0]


def clock(sec):
    sec = max(0, int(math.ceil(sec)))
    h, r = divmod(sec, 3600)
    m, s = divmod(r, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


# ───────────────────────────── KI: Vias eigenes Gehirn ───────────────────
SENT = re.compile(r"(?<=[.!?])\s+|\n+")
EMOJI = re.compile("[\U00010000-\U0010ffff\u2600-\u27bf]")
BRAIN_FILE = MODELS / "via_gpt.npz"


def clean_speech(t):
    t = EMOJI.sub("", t)
    t = re.sub(r"[*_#`>~|]+", "", t)
    return re.sub(r"\s+", " ", t).strip()


class LLM:
    """Vias selbst gebautes und selbst trainiertes neuronales Netz (reines NumPy, siehe via_ai.py)."""

    def __init__(self, cfg):
        self.cfg = cfg
        self.gen = None
        self.ready = False
        self.error = None
        self.info = ""
        self.history = []                 # [(du, via)]
        self.last_conf = 0.0
        self.mature = False
        self.loss = 9.0
        self.step = 0

    def load(self):
        if not self.cfg.get("llm", True):
            return
        try:
            if not BRAIN_FILE.exists():
                raise FileNotFoundError("Via-Gehirn fehlt (models/via_gpt.npz). Bitte mit der Trainings-App trainieren.")
            from via_ai import Generator
            self.gen = Generator(str(BRAIN_FILE))
            kind = self.gen.tok.kind
            n = sum(v.size for v in self.gen.p.values())
            self.loss = float(self.gen.cfg.get("loss", 9.0))
            self.step = int(self.gen.cfg.get("step", 0))
            lim = self.cfg.get("brain_max_loss") or (0.30 if kind == "char" else 1.20)
            self.mature = self.loss <= lim or self.cfg.get("brain_force", False)
            self.info = (f"{n / 1e6:.2f} Mio. Parameter, Schritt {self.step}, Verlust {self.loss:.2f}"
                         + ("" if self.mature else " · noch in Ausbildung, feste Antworten aktiv"))
            list(self.gen.stream_chars("Du: hallo\nVia:", max_new=3))      # aufwärmen
            self.ready = True
        except Exception as e:
            self.error = str(e)
            print("Via-Gehirn nicht verfügbar:", e)

    def reset(self):
        self.history.clear()

    def remember(self, user, answer):
        u = norm_user(user)[:60]
        if len(u) + len(answer) <= 90:
            self.history.append((u, answer))
            self.history = self.history[-4:]

    def _prompt(self, user):
        tail = " " if self.gen.tok.kind == "char" else ""
        cur = f"Du: {norm_user(user)[:60]}\nVia:{tail}"
        budget = max(0, 70 - len(cur) + 24)
        past = ""
        for u, a in reversed(self.history):
            line = f"Du: {u}\nVia:{tail} {a}\n".replace(":  ", ": ")
            if len(past) + len(line) > budget:
                break
            past = line + past
        return past + cur

    def stream(self, user, assistant):
        """Erzeugt die komplette Antwort (Sekundenbruchteile) und gibt sie satzweise zurück."""
        if not self.mature:
            return
        kind = self.gen.tok.kind
        text = "".join(self.gen.stream_chars(self._prompt(user), max_new=130 if kind == "char" else 56,
                                             temp=0.45, top_k=8)).strip()
        self.last_conf = self.gen.confidence()
        if kind == "char" and self.last_conf < self.cfg.get("brain_conf", -0.45):
            return
        full = [x for x in (clean_speech(p) for p in SENT.split(text)) if x]
        for sent in full:
            yield re.sub(r"\bVia\b", name(), sent)
        self.remember(user, " ".join(full))


# ───────────────────────────── Wetter (Open-Meteo, ohne Key) ─────────────
WMO = {0: "klarer Himmel", 1: "überwiegend klar", 2: "teils bewölkt", 3: "bedeckt",
       45: "Nebel", 48: "Reifnebel", 51: "leichter Nieselregen", 53: "Nieselregen",
       55: "starker Nieselregen", 61: "leichter Regen", 63: "Regen", 65: "starker Regen",
       66: "gefrierender Regen", 67: "starker gefrierender Regen", 71: "leichter Schneefall",
       73: "Schneefall", 75: "starker Schneefall", 77: "Schneegriesel", 80: "leichte Schauer",
       81: "Regenschauer", 82: "heftige Schauer", 85: "Schneeschauer", 86: "starke Schneeschauer",
       95: "Gewitter", 96: "Gewitter mit Hagel", 99: "schweres Gewitter mit Hagel"}
ICON = {0: "☀️", 1: "🌤️", 2: "⛅", 3: "☁️", 45: "🌫️", 48: "🌫️", 51: "🌦️", 53: "🌦️", 55: "🌧️",
        61: "🌦️", 63: "🌧️", 65: "🌧️", 66: "🌧️", 67: "🌧️", 71: "🌨️", 73: "❄️", 75: "❄️",
        77: "❄️", 80: "🌦️", 81: "🌧️", 82: "⛈️", 85: "🌨️", 86: "❄️", 95: "⛈️", 96: "⛈️", 99: "⛈️"}
SHORT = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"]
DAYS = ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"]
MONTHS = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August",
          "September", "Oktober", "November", "Dezember"]
JOKES = [
    "Was macht ein Pirat am Computer? Er drückt die Enter-Taste.",
    "Warum können Geister so schlecht lügen? Weil man direkt durch sie hindurchsieht.",
    "Treffen sich zwei Magnete. Sagt der eine: Was soll ich heute nur anziehen?",
    "Was ist grün und schaut durchs Schlüsselloch? Ein Spionat.",
]


def get_json(url):
    with urllib.request.urlopen(url, timeout=6) as r:
        return json.load(r)


def geocode(city):
    g = get_json("https://geocoding-api.open-meteo.com/v1/search?count=1&language=de&name="
                 + urllib.parse.quote(city))
    r = g.get("results")
    if not r:
        return None
    r = r[0]
    return r["latitude"], r["longitude"], r["name"]


def fetch_weather(lat, lon, name):
    w = get_json("https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s"
                 "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m"
                 "&daily=weather_code,temperature_2m_max,temperature_2m_min,"
                 "precipitation_probability_max&timezone=auto&forecast_days=5" % (lat, lon))
    c, d = w["current"], w["daily"]
    days = []
    for i, ds in enumerate(d["time"]):
        wd = datetime.date.fromisoformat(ds).weekday()
        days.append({"label": "Heute" if i == 0 else "Morgen" if i == 1 else SHORT[wd],
                     "long": "Heute" if i == 0 else "Morgen" if i == 1 else DAYS[wd],
                     "hi": round(d["temperature_2m_max"][i]), "lo": round(d["temperature_2m_min"][i]),
                     "code": d["weather_code"][i], "rain": d["precipitation_probability_max"][i] or 0})
    return {"name": name, "lat": lat, "lon": lon, "temp": round(c["temperature_2m"]),
            "feels": round(c["apparent_temperature"]), "code": c["weather_code"],
            "wind": round(c["wind_speed_10m"]), "days": days}


# ───────────────────────────── Assistent-Logik ───────────────────────────
STOP = "\0stop"


class Assistant:
    def __init__(self, cfg):
        self.cfg = cfg
        self.timers = []
        self.lock = threading.Lock()
        self._next = 1
        self.pending_timer = False
        self.quit = False
        self.followup = False
        self.hint = None
        self.weather_data = None
        self.watches = []
        self._wid = 1
        self.apps = AppLauncher(cfg)

    @property
    def name(self):
        return name()

    def add_note(self, text):
        (BASE / "data").mkdir(exist_ok=True)
        with open(BASE / "data" / "notizen.txt", "a", encoding="utf-8") as f:
            f.write(f"{datetime.datetime.now():%d.%m. %H:%M}  {text}\n")

    def read_notes(self):
        f = BASE / "data" / "notizen.txt"
        lines = [l.strip() for l in f.read_text(encoding="utf-8").splitlines() if l.strip()] if f.exists() else []
        if not lines:
            return "Du hast noch keine Notizen."
        return "Deine letzten Notizen: " + ". ".join(l.split("  ", 1)[-1].strip() for l in lines[-3:]) + "."

    # ---- Stoppuhren
    def sw_new(self):
        with self.lock:
            w = {"id": self._wid, "acc": 0.0, "t0": time.time(), "running": True, "laps": []}
            self._wid += 1
            self.watches.append(w)
        return w

    @staticmethod
    def _sw_el(w, now=None):
        now = now or time.time()
        return w["acc"] + ((now - w["t0"]) if w["running"] else 0.0)

    def sw_toggle(self, wid):
        with self.lock:
            for w in self.watches:
                if w["id"] == wid:
                    now = time.time()
                    if w["running"]:
                        w["acc"], w["running"] = self._sw_el(w, now), False
                    else:
                        w["t0"], w["running"] = now, True

    def sw_lap(self, wid):
        with self.lock:
            for w in self.watches:
                if w["id"] == wid:
                    total = self._sw_el(w)
                    prev = w["laps"][-1] if w["laps"] else 0.0
                    w["laps"].append(total)
                    return len(w["laps"]), total - prev, total
        return 0, 0.0, 0.0

    def sw_remove(self, wid):
        with self.lock:
            self.watches = [w for w in self.watches if w["id"] != wid]

    def sw_snapshot(self):
        now = time.time()
        with self.lock:
            return [{"id": w["id"], "el": self._sw_el(w, now), "running": w["running"], "laps": list(w["laps"])}
                    for w in self.watches]

    # ---- Timer
    def add_timer(self, sec):
        with self.lock:
            self.timers.append({"id": self._next, "end": time.time() + sec, "total": sec,
                                "label": fmt_dur(sec), "paused": False, "left": sec,
                                "done": False, "alarms": 0, "next": 0})
            self._next += 1
        return fmt_dur(sec)

    def _find(self, tid):
        for t in self.timers:
            if t["id"] == tid:
                return t

    def toggle_pause(self, tid):
        with self.lock:
            t = self._find(tid)
            if t and not t["done"]:
                if t["paused"]:
                    t["end"] = time.time() + t["left"]; t["paused"] = False
                else:
                    t["left"] = max(0, t["end"] - time.time()); t["paused"] = True

    def pause_all(self, pause):
        with self.lock:
            now = time.time()
            for t in self.timers:
                if t["done"]:
                    continue
                if pause and not t["paused"]:
                    t["left"] = max(0, t["end"] - now); t["paused"] = True
                elif not pause and t["paused"]:
                    t["end"] = now + t["left"]; t["paused"] = False

    def add_time(self, tid, sec):
        with self.lock:
            t = self._find(tid)
            if not t:
                return
            now = time.time()
            if t["done"]:
                t.update(done=False, end=now + sec, total=sec, left=sec, alarms=0,
                         paused=False, label=fmt_dur(sec))
            else:
                if t["paused"]: t["left"] += sec
                else: t["end"] += sec
                t["total"] += sec

    def remove(self, tid):
        with self.lock:
            self.timers = [t for t in self.timers if t["id"] != tid]

    def dismiss_done(self):
        with self.lock:
            n = len(self.timers)
            self.timers = [t for t in self.timers if not t["done"]]
            return n - len(self.timers)

    def clear(self):
        with self.lock:
            n = len(self.timers); self.timers.clear(); return n

    def snapshot(self):
        now = time.time()
        with self.lock:
            return [{"id": t["id"], "total": t["total"], "label": t["label"],
                     "paused": t["paused"], "done": t["done"],
                     "rem": t["left"] if t["paused"] else max(0, t["end"] - now)}
                    for t in self.timers]

    def pop_alarms(self):
        now, res = time.time(), []
        with self.lock:
            for t in self.timers:
                if not t["paused"] and not t["done"] and t["end"] <= now:
                    t["done"] = True; t["next"] = now
                if t["done"] and t["alarms"] < 3 and now >= t["next"]:
                    res.append((t["label"], t["alarms"] == 0))
                    t["alarms"] += 1; t["next"] = now + 18
        return res

    @staticmethod
    def duration(t):
        total = 0
        for n, unit in re.findall(r"(\d+)\s*(sekunden?|sek|minuten?|min|stunden?|std)\b", t):
            n = int(n)
            total += n * (3600 if unit.startswith(("stund", "std")) else
                          60 if unit.startswith("min") else 1)
        return total

    # ---- Wetter
    def weather(self, city, offset):
        try:
            if city:
                g = geocode(city)
                if not g:
                    return f"Den Ort {city} habe ich nicht gefunden."
            else:
                g = (self.cfg["lat"], self.cfg["lon"], self.cfg["city"])
            d = fetch_weather(*g)
        except Exception:
            return "Ich konnte das Wetter gerade nicht abrufen. Bist du online?"
        self.weather_data = d
        self.hint = "weather"
        day = d["days"][min(offset, len(d["days"]) - 1)]
        if offset == 0:
            return (f"In {d['name']} sind es gerade {d['temp']} Grad, gefühlt {d['feels']}. "
                    f"{WMO.get(d['code'], 'wechselhaft').capitalize()}. "
                    f"Heute bis zu {day['hi']} Grad, Regenwahrscheinlichkeit {day['rain']} Prozent.")
        when = "Morgen" if offset == 1 else "Übermorgen"
        return (f"{when} in {d['name']}: {WMO.get(day['code'], 'wechselhaft')}, "
                f"zwischen {day['lo']} und {day['hi']} Grad, Regenwahrscheinlichkeit {day['rain']} Prozent.")

    # ---- Hauptlogik
    def handle(self, raw):
        t = normalize(raw)
        self.followup = False
        self.hint = None
        now = datetime.datetime.now()

        if re.fullmatch(r"(stopp|stop|halt|ruhe|sei still|abbrechen)", t):
            self.dismiss_done()
            return STOP

        if self.pending_timer:
            self.pending_timer = False
            sec = self.duration(t)
            if not sec and re.fullmatch(r"(\d+)", t):      # nackte Zahl = Minuten
                sec = int(t) * 60
            if sec:
                self.hint = "timers"
                return f"Timer für {self.add_timer(sec)} läuft."
            if "nein" in t or "vergiss" in t:
                return "Okay, kein Timer."
            # sonst: ganz normal als neuer Befehl weiterverarbeiten

        if re.search(r"einstellung|optionen", t):
            self.hint = "settings"
            return "Ich öffne die Einstellungen."

        tsw = re.sub(r"stop+ ?uhr", "stoppuhr", t)
        if self.watches and re.fullmatch(r"(neue )?(runde|zwischenzeit)", t):
            tsw = "stoppuhr " + t
        if "stoppuhr" in tsw:
            self.hint = "stopwatch"
            last = self.watches[-1] if self.watches else None
            if re.search(r"lösch|zurücksetz|reset|entfern|schließ|beend|\baus\b", tsw):
                n = len(self.watches)
                with self.lock:
                    self.watches.clear()
                return "Stoppuhr gelöscht." if n else "Es läuft keine Stoppuhr."
            if re.search(r"runde|zwischenzeit|\blap\b", tsw):
                if not last:
                    return "Es läuft keine Stoppuhr."
                n, split, total = self.sw_lap(last["id"])
                return f"Runde {n}: {fmt_dur(split)}. Gesamt {fmt_dur(total)}."
            if re.search(r"weiter|fortsetz", tsw):
                if last and not last["running"]:
                    self.sw_toggle(last["id"]); return "Stoppuhr läuft weiter."
                return "Es gibt keine pausierte Stoppuhr."
            if re.search(r"\b(stopp(?:e|en|t)?|stop|anhalten|halt|pausier\w*)\b", tsw) and not re.search(r"\bstart\w*|\blos\b|\bneu\w*", tsw):
                if not last or not last["running"]:
                    return "Es läuft keine Stoppuhr."
                self.sw_toggle(last["id"])
                return f"Gestoppt bei {fmt_dur(self._sw_el(last))}."
            if re.search(r"wie lange|wie viel|wieviel|\bzeit\b|läuft|status|stand|zeig", tsw):
                if not last:
                    return "Es läuft keine Stoppuhr."
                return (f"Die Stoppuhr steht bei {fmt_dur(self._sw_el(last))}."
                        + (" Sie läuft." if last["running"] else " Sie ist gestoppt."))
            if last and not last["running"] and not re.search(r"\bneu\w*", tsw):
                self.sw_toggle(last["id"]); return "Stoppuhr läuft weiter."
            self.sw_new()
            return "Stoppuhr gestartet."

        if "timer" in t or "wecker" in t or re.search(r"erinner\w* mich in \d", t):
            self.hint = "timers"
            if re.search(r"pausier|anhalten", t):
                self.pause_all(True); return "Timer pausiert."
            if re.search(r"fortsetz|weiter|wieder starten", t):
                self.pause_all(False); return "Timer läuft weiter."
            if re.search(r"(lösch|stopp|stop|abbrech|beend|entfern|abbruch)", t):
                n = self.clear()
                return "Alle Timer sind gelöscht." if n else "Es läuft kein Timer."
            if re.search(r"(wie lange|wie viel|wieviel|welche|noch|läuft|laufen|status|zeig)", t) \
                    and not self.duration(t):
                snap = self.snapshot()
                if not snap:
                    return "Es läuft gerade kein Timer."
                return " ".join(f"Noch {fmt_dur(s['rem'])} von {s['label']}." for s in snap)
            sec = self.duration(t)
            if sec:
                return f"Timer für {self.add_timer(sec)} gestellt."
            self.pending_timer = True
            self.followup = True
            return "Für wie lange soll der Timer laufen?"

        if re.search(r"wetter|temperatur|regnet|regen\b|schneit|wie warm|wie kalt", t):
            m = re.search(r"\b(?:in|für|bei|von)\s+([a-zäöüß\- ]+?)(?:\s+(?:heute|morgen|übermorgen|jetzt|gerade)\b|$)", t)
            city = m.group(1).strip() if m else None
            if city and any(x in city for x in ("nähe", "umgebung", "hier", "dem", "der")):
                city = None
            offset = 2 if "übermorgen" in t else 1 if "morgen" in t else 0
            return self.weather(city, offset)

        m = re.match(r"^(?:bitte )?(öffne|öffnen|starte|starten|mach|zeig|geh|gehe|ruf) (.+)$", t)
        if m and not re.search(r"timer|stoppuhr|wecker|notiz|wetter|lauter|leiser|einstellung|programmierecke", m.group(2)):
            rest = re.sub(r"\b(1|den|die|das|dem|mal|bitte|mir|programm|app|anwendung|auf|aus|an|zu|nach)\b", " ", m.group(2))
            q = re.sub(r"\s+", " ", rest).strip()
            if q:
                hit = self.apps.open(q)
                if hit:
                    return f"Öffne {hit}."
                if m.group(1) in ("öffne", "öffnen", "starte", "starten"):
                    return f"Die App {q} habe ich nicht gefunden. Du kannst sie in den Einstellungen unter Apps hinzufügen."
        m = re.match(r"^(?:such|suche|google|googel|recherchiere)\s+(?:im internet |im web |bei google |online )?(?:nach )?(.+)$", t)
        if m:
            self.apps.web_search(m.group(1))
            return f"Ich suche nach {m.group(1)}."
        if re.search(r"programmierecke|code ?lab|werkstatt", t):
            self.hint = "codelab"
            return "Ich öffne die Programmierecke."

        rl = re.sub(r"[.,!?;:](?!\d)", " ", raw.lower()).strip()
        m = re.match(r"^(?:merk dir|merke dir|notiere|notier|schreib auf|schreibe auf|notiz)\s+(.+)", rl)
        if m:
            self.add_note(m.group(1))
            return "Notiert."
        if re.search(r"notizen|was habe ich (notiert|aufgeschrieben)", t) and re.search(r"lies|zeig|sag|nenn|was|vorlesen", t):
            return self.read_notes()
        if re.search(r"\b(lauter|leiser)\b", t) and "timer" not in t:
            v = float(self.cfg.get("volume", 0.9)) + (0.15 if "lauter" in t else -0.15)
            self.cfg["volume"] = round(min(1.0, max(0.1, v)), 2)
            save_cfg(self.cfg)
            return "Okay, lauter." if "lauter" in t else "Okay, leiser."

        if re.search(r"wie spät|uhrzeit|wie viel uhr|wieviel uhr", t):
            if now.minute == 0:
                return f"Es ist genau {now.hour} Uhr."
            return f"Es ist {now.hour} Uhr {now.minute}."

        if re.search(r"datum|welcher tag|welchen tag|welcher wochentag|den wievielten", t):
            return f"Heute ist {DAYS[now.weekday()]}, der {now.day}. {MONTHS[now.month - 1]} {now.year}."

        m = re.search(r"(\d+(?:[.,]\d+)?)\s*(plus|minus|mal|geteilt durch|durch|geteilt)\s*(\d+(?:[.,]\d+)?)", t)
        if m:
            a, op, b = float(m.group(1).replace(",", ".")), m.group(2), float(m.group(3).replace(",", "."))
            if op == "plus": r = a + b
            elif op == "minus": r = a - b
            elif op == "mal": r = a * b
            else:
                if b == 0:
                    return "Durch null kann man nicht teilen."
                r = a / b
            r = round(r, 3)
            s = str(int(r)) if r == int(r) else str(r).replace(".", " Komma ")
            return f"Das ergibt {s}."

        if re.search(r"(beende dich|schließ dich|programm beenden|tschüss|auf wiedersehen)", t):
            self.quit = True
            return "Bis bald!"
        return None          # kein fester Befehl -> das Sprachmodell antwortet

    def static_fallback(self, raw):
        """Nur wenn kein Sprachmodell verfügbar ist."""
        t = normalize(raw)
        if "witz" in t:
            return random.choice(JOKES)
        if re.search(r"wer bist du|wie heißt du|was bist du", t):
            return f"Ich bin {name()}, dein lokaler Sprachassistent. Ich laufe komplett auf deinem Rechner."
        if re.search(r"was kannst du|hilfe", t):
            return "Ich kann Timer stellen, das Wetter nennen, Uhrzeit und Datum sagen, rechnen und Witze erzählen."
        if re.search(r"danke", t):
            return "Gern geschehen!"
        if re.search(r"^(hallo|hi|guten (morgen|tag|abend)|wie geht)", t):
            return random.choice(["Hallo! Wie kann ich helfen?", "Hi! Was kann ich für dich tun?"])
        return "Da bin ich unsicher. Mein Gehirn ist noch klein und lernt dazu. Sag es gern anders, oder frag nach Timer, Wetter und Uhrzeit."


# ───────────────────────────── Zuhören ───────────────────────────────────
class Brain(QObject):
    state = Signal(str)     # loading | idle | listening | thinking | error
    heard = Signal(str)
    reply = Signal(str)
    level = Signal(float)
    error = Signal(str)
    hint = Signal(str)
    weather = Signal(object)
    quit = Signal()

    def __init__(self, cfg, assistant, speaker, llm, whisper):
        super().__init__()
        self.cfg, self.a, self.speaker, self.llm, self.whisper = cfg, assistant, speaker, llm, whisper
        self.cancel = False
        self.cloud = None
        self.q = None
        self.running = True
        self.muted = False
        self.restart = threading.Event()
        self.awaiting = False
        self.window_until = 0.0
        self.was_busy = False
        self.replied = False
        self.cur = "loading"

    def start(self):
        threading.Thread(target=self._run, daemon=True).start()
        threading.Thread(target=self.llm.load, daemon=True).start()

    def refresh_wake(self):
        self.restart.set()

    def set_input(self, name_):
        self.cfg["input_device"] = name_
        save_cfg(self.cfg)
        self.restart.set()

    def _set(self, s):
        if s != self.cur:
            self.cur = s
            self.state.emit(s)

    def activate(self):
        """Klick auf die Kugel statt Wake-Word."""
        self.cancel = True
        self.speaker.stop()
        self.awaiting = True
        self.window_until = time.time() + 8
        self.speaker.sound("chime")
        self._set("listening")
        self.heard.emit("")

    def _open(self, q):
        dev = find_device(self.cfg.get("input_device"), "input")
        try:
            native = int(sd.query_devices(dev, "input")["default_samplerate"])
        except Exception:
            native = 44100
        last = None
        for sr in (SR_IN, native):
            def cb(indata, frames, t, status, sr=sr):
                b = bytes(indata)
                if sr != SR_IN:
                    a = np.frombuffer(b, np.int16).astype(np.float32)
                    n = max(1, int(len(a) * SR_IN / sr))
                    a = np.interp(np.linspace(0, len(a) - 1, n), np.arange(len(a)), a).astype(np.int16)
                    b = a.tobytes()
                try: q.put_nowait(b)
                except queue.Full: pass
            try:
                st = sd.RawInputStream(samplerate=sr, blocksize=int(sr / 10), dtype="int16",
                                       channels=1, device=dev, callback=cb)
                st.start()
                return st, None
            except Exception as e:
                last = e
        return None, last

    def _wake_rec(self):
        words = sorted(HEY | name_words()) + ["[unk]"]
        try:
            return KaldiRecognizer(self.model, SR_IN, json.dumps(words, ensure_ascii=False))
        except Exception:
            return KaldiRecognizer(self.model, SR_IN)

    def _run(self):
        try:
            if not VOSK_DIR.exists():
                raise FileNotFoundError("Spracherkennung fehlt. Bitte zuerst  python setup_models.py  ausführen.")
            self.model = Model(str(VOSK_DIR))
            self.rec_full = KaldiRecognizer(self.model, SR_IN)
        except Exception as e:
            self.error.emit(str(e)); self._set("error"); return
        q = self.q = queue.Queue(maxsize=100)
        while self.running:
            stream, err = self._open(q)
            self.restart.clear()
            if stream is None:
                self.error.emit(f"Mikrofon nicht verfügbar: {err}")
                self._set("error")
                self.restart.wait(); continue
            if self.cur in ("loading", "error"):
                self._set("idle")
            self._loop(q, self._wake_rec())
            try:
                stream.stop(); stream.close()
            except Exception:
                pass
            while not q.empty():
                q.get_nowait()

    def _loop(self, q, rec):
        seg = Segmenter(self.cfg.get("mic_gate", 150))
        vtexts = []
        while self.running and not self.restart.is_set():
            try:
                data = q.get(timeout=0.4)
            except queue.Empty:
                continue
            if self.muted:
                self.level.emit(0.0); seg.reset(); continue
            if self.speaker.pending:             # nicht sich selbst zuhören
                self.was_busy = True
                continue
            if self.was_busy:
                self.was_busy = False
                while not q.empty():
                    q.get_nowait()
                rec.Reset(); seg.reset(); vtexts = []
                if self.awaiting:
                    self.window_until = time.time() + 8
                elif self.replied or self.a.followup:
                    self.window_until = time.time() + 7
                continue
            seg.gate = self.cfg.get("mic_gate", 150)
            audio, rms, started = seg.feed(data, fast_end=self._active())
            self.level.emit(min(1.0, rms / 5000))
            if rec.AcceptWaveform(data):
                t = json.loads(rec.Result()).get("text", "")
                if t: vtexts.append(t)
            else:
                self._early(json.loads(rec.PartialResult()).get("partial", ""))
            if started and self._active() and self.cur in ("idle", "listening"):
                self._set("listening")
            if audio is not None:
                t = json.loads(rec.FinalResult()).get("text", "")
                if t: vtexts.append(t)
                self._segment(audio, " ".join(vtexts))
                vtexts = []
                while not q.empty():
                    q.get_nowait()
                rec.Reset(); seg.reset()

    def _active(self):
        return self.awaiting or time.time() < self.window_until

    @staticmethod
    def _is_wake(words):
        return bool(words) and (words[0] in HEY or words[0] in name_words())

    def _early(self, p):
        w = [x for x in p.split() if x != "[unk]"]
        if self._is_wake(w[:1]) and self.cur in ("idle", "listening"):
            self._set("listening")
            self.heard.emit(f"Hey {name()} …")

    def _strip_wake(self, text):
        toks, names = text.split(), name_words()
        key = lambda t: re.sub(r"[^a-zäöüß]", "", t.lower())
        like = lambda k: bool(k) and (k in names or any(difflib.SequenceMatcher(None, k, n).ratio() >= 0.75 for n in names))
        i = 0
        if toks and key(toks[0]) in HEY:
            i = 1
        if i < len(toks) and like(key(toks[i])):
            i += 1
        elif i == 0 and toks and like(key(toks[0])):
            i = 1
        return " ".join(toks[i:])

    def _transcribe(self, audio):
        if self.cfg.get("stt", "whisper-small").startswith("whisper") and self.whisper.ready:
            try:
                prompt = (f"Hey {name()}, stelle einen Timer auf fünf Minuten. Wie ist das Wetter in "
                          f"{self.cfg.get('city', 'München')}? Wie spät ist es?")
                return self.whisper.transcribe(audio, prompt)
            except Exception as e:
                print("Whisper-Fehler:", e)
        r = self.rec_full
        r.AcceptWaveform(audio)
        txt = json.loads(r.FinalResult()).get("text", "")
        r.Reset()
        return txt

    def _wake_only(self):
        self.awaiting = True
        self.window_until = time.time() + 8
        self.speaker.sound("chime")
        self._set("listening")
        self.heard.emit(f"Hey {name()} …")

    def _segment(self, audio, vtext):
        words = [w for w in vtext.lower().split() if w != "[unk]"]
        wake = self._is_wake(words[:1])
        if not wake and not self._active():
            self._set("idle"); self.heard.emit("")
            return
        dur = len(audio) / (2.0 * SR_IN)
        if wake and dur < 2.0 and all(w in HEY or w in name_words() for w in words):
            self._wake_only(); return
        self._set("thinking")
        self.heard.emit("…")
        text = self._transcribe(audio).strip()
        if wake:
            text = self._strip_wake(text)
        text = text.strip(" .,!?;:")
        if not text:
            if wake:
                self._wake_only()
            else:
                self._set("idle"); self.heard.emit("")
            return
        self.awaiting = False
        self.heard.emit(text)
        self._process(text)

    def _process(self, raw):
        reply = self.a.handle(rules_text(raw))
        if reply == STOP:
            self.speaker.stop()
            self._set("idle")
            return
        if reply is None:
            self._chat(raw)
        else:
            if self.a.hint == "weather" and self.a.weather_data:
                self.weather.emit(self.a.weather_data)
            if self.a.hint:
                self.hint.emit(self.a.hint)
            self.reply.emit(reply)
            self.speaker.say(reply)
            self.llm.remember(raw, reply)
        self.replied = True
        if self.a.followup:
            self.awaiting = True
        self._set("idle")
        if self.a.quit:
            self.quit.emit()

    def _say(self, text):
        self.reply.emit(text)
        self.speaker.say(text)

    def _drain(self):
        if self.q is not None:
            while not self.q.empty():
                self.q.get_nowait()

    def _chat(self, cmd):
        """Freies Gespräch: Gemini (online, vortrainiert) oder Vias eigenes Gehirn (offline, trainierbar)."""
        if self.cfg.get("brain", "own") in ("llm", "gemini"):
            if not self.cloud or not self.cloud.ready:
                self._say("Für Gemini fehlt noch der Schlüssel. Du trägst ihn in den Einstellungen ein.")
                return
            self.cancel = False
            full = ""
            try:
                for sent in self.cloud.stream(cmd, self.a):
                    if self.cancel:
                        break
                    full = (full + " " + sent).strip()
                    self.reply.emit(full)
                    self.speaker.say(sent)
            except Exception as e:
                print("KI-Modell:", e)
                if not full:
                    self._say(str(e)[:170] if isinstance(e, RuntimeError) else "Das KI-Modell ist gerade nicht erreichbar.")
            self._drain()
            return
        self._own_chat(cmd)

    def _own_chat(self, cmd):
        """Vias eigenes Gehirn; was sie nicht weiß, landet im Gesprächs-Log zum Nachtrainieren."""
        if not self.cfg.get("llm", True) or self.llm.error:
            text = self.a.static_fallback(cmd)
            self._say(text); log_chat(cmd, text); return
        if not self.llm.ready:
            self._say("Mein Gehirn lädt noch. Einen Moment bitte."); return
        self.cancel = False
        full = ""
        try:
            for sent in self.llm.stream(cmd, self.a):
                if self.cancel:
                    break
                full = (full + " " + sent).strip()
                self.reply.emit(full)
                self.speaker.say(sent)
        except Exception as e:
            print("KI-Fehler:", e)
        if not full and not self.cancel:
            full = self.a.static_fallback(cmd)
            self._say(full)
        if full:
            log_chat(cmd, full)
        self._drain()


# ───────────────────────────── UI: Stil ──────────────────────────────────
COL = {"idle": "#6c7bff", "listening": "#2ee6c8", "thinking": "#b57bff",
       "speaking": "#ff6fa8", "loading": "#8892c8", "error": "#ff5d6c"}
def label(st):
    return {"idle": f"Bereit · sag „Hey {name()}“", "listening": "Ich höre zu …", "thinking": "Verstehe …",
            "speaking": f"{name()} spricht …", "loading": "Lade Modelle …", "error": "Fehler"}.get(st, "")

QSS = """
QFrame#panel{background:qlineargradient(x1:0,y1:0,x2:0.7,y2:1,stop:0 #0f1330,stop:0.55 #151238,stop:1 #1d1243);
  border:1px solid rgba(160,172,255,46);border-radius:26px;}
QDialog,QScrollArea,QScrollArea>QWidget>QWidget{background:#12152b;}
QScrollArea{border:none;}
QLabel{color:#e9ecff;background:transparent;font-size:13px;}
QLabel#muted{color:rgba(255,255,255,125);}
QLabel#sec{color:#8c99ff;font-size:11px;font-weight:700;letter-spacing:2px;padding-top:8px;}
QLabel#title{font-size:20px;font-weight:800;color:white;}
QLabel#status{font-size:12px;font-weight:600;letter-spacing:1px;}
QLabel#bubbleUser{color:rgba(255,255,255,170);font-style:italic;background:rgba(255,255,255,13);
  border:1px solid rgba(255,255,255,20);border-radius:16px;border-top-right-radius:5px;padding:9px 14px;}
QLabel#bubbleVia{color:white;font-size:15px;font-weight:500;border-radius:16px;border-top-left-radius:5px;padding:11px 15px;
  background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 rgba(79,95,232,205),stop:1 rgba(150,90,230,190));}
QLabel#ttime{font-size:21px;font-weight:700;}
QLabel#bigtemp{font-size:34px;font-weight:700;}
QLabel#bigicon{font-size:36px;}
QPushButton#chip{background:rgba(255,255,255,14);color:#cfd4ff;border:1px solid rgba(255,255,255,18);border-radius:14px;
  padding:7px 8px;font-size:12px;font-weight:600;}
QPushButton#chip:hover{background:rgba(255,255,255,30);}
QPushButton#chip:checked{background:rgba(108,123,255,150);color:white;border:1px solid rgba(190,198,255,160);}
QPushButton#pill{background:rgba(255,255,255,18);color:#dfe3ff;border:none;border-radius:12px;padding:6px 12px;font-size:12px;}
QPushButton#pill:hover{background:rgba(255,255,255,36);}
QPushButton#pill:checked{background:rgba(108,123,255,140);color:white;}
QPushButton#appbtn{background:rgba(255,255,255,14);color:#e4e7ff;border:1px solid rgba(255,255,255,16);border-radius:12px;
  padding:9px 6px;font-size:12px;}
QPushButton#appbtn:hover{background:rgba(108,123,255,110);}
QPushButton#icon{background:rgba(255,255,255,16);color:#dfe3ff;border:none;border-radius:15px;
  min-width:30px;max-width:30px;min-height:30px;max-height:30px;font-size:13px;}
QPushButton#icon:hover{background:rgba(255,255,255,40);}
QPushButton#icon:checked{background:rgba(108,123,255,150);}
QPushButton#day{background:rgba(255,255,255,12);color:#dfe3ff;border:1px solid transparent;
  border-radius:12px;padding:6px 2px;font-size:11px;}
QPushButton#day:hover{background:rgba(255,255,255,26);}
QPushButton#day:checked{background:rgba(108,123,255,110);border:1px solid rgba(160,172,255,160);}
QFrame#card{background:rgba(255,255,255,13);border:1px solid rgba(255,255,255,22);border-radius:16px;}
QFrame#card[done="true"]{background:rgba(255,93,108,40);border:1px solid rgba(255,93,108,140);}
QLineEdit,QSpinBox,QComboBox{background:rgba(255,255,255,15);color:#eef0ff;border:1px solid rgba(255,255,255,28);
  border-radius:11px;padding:7px 11px;font-size:13px;selection-background-color:#6c7bff;}
QLineEdit:focus{border:1px solid rgba(160,172,255,170);}
QListWidget{background:rgba(255,255,255,10);color:#eef0ff;border:1px solid rgba(255,255,255,24);border-radius:10px;}
QComboBox QAbstractItemView{background:#171a33;color:#e9ecff;selection-background-color:#6c7bff;border:none;}
QComboBox::drop-down{border:none;width:22px;}
QCheckBox{color:#e9ecff;font-size:13px;spacing:8px;}
QSlider::groove:horizontal{height:4px;background:rgba(255,255,255,40);border-radius:2px;}
QSlider::handle:horizontal{background:#8c99ff;width:16px;margin:-6px 0;border-radius:8px;}
QSlider::sub-page:horizontal{background:#6c7bff;border-radius:2px;}
QProgressBar{background:rgba(255,255,255,18);border:none;border-radius:4px;max-height:8px;}
QProgressBar::chunk{background:#2ee6c8;border-radius:4px;}
QProgressBar#level{background:rgba(255,255,255,10);border-radius:2px;max-height:4px;}
QProgressBar#level::chunk{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #2ee6c8,stop:1 #8c99ff);border-radius:2px;}
"""


class Orb(QWidget):
    clicked = Signal()

    def __init__(self, size=84, ratio=0.2, glow=2.3):
        super().__init__()
        self.state, self.level, self.sm, self.t = "loading", 0.0, 0.0, 0.0
        self.ratio, self.glow = ratio, glow
        self.setFixedSize(size, size)
        self.setCursor(Qt.PointingHandCursor)
        self.timer = QTimer(self, interval=33, timeout=self._tick)
        self.timer.start()

    def _tick(self):
        if not self.isVisible():
            return
        self.t += 0.033
        self.sm += (self.level - self.sm) * 0.3
        self.update()

    def mousePressEvent(self, e):
        self.clicked.emit()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        c = QPointF(self.width() / 2, self.height() / 2)
        base = min(self.width(), self.height()) * self.ratio
        st, t = self.state, self.t
        col = QColor(COL.get(st, "#6c7bff"))
        pulse = {"idle": 0.03 * math.sin(t * 1.6), "loading": 0.04 * math.sin(t * 3),
                 "listening": self.sm * 0.3 + 0.04 * math.sin(t * 5),
                 "thinking": 0.03 * math.sin(t * 8),
                 "speaking": 0.08 * abs(math.sin(t * 7)) + 0.04 * math.sin(t * 13),
                 "error": 0.02 * math.sin(t * 10)}.get(st, 0)
        r = base * (1 + pulse)
        gr = min(r * self.glow, self.width() / 2)
        g = QRadialGradient(c, gr)
        a = QColor(col); a.setAlpha(130); g.setColorAt(0, a)
        a = QColor(col); a.setAlpha(0); g.setColorAt(1, a)
        p.setPen(Qt.NoPen); p.setBrush(g)
        p.drawEllipse(c, gr, gr)
        for i in range(2):
            ph = (t * 0.5 + i / 2) % 1
            rr = min(r * (1.15 + ph * 0.55), self.width() / 2 - 1)
            ring = QColor(col); ring.setAlpha(int(90 * (1 - ph)) if st != "idle" else int(35 * (1 - ph)))
            p.setPen(QPen(ring, 1.4)); p.setBrush(Qt.NoBrush)
            p.drawEllipse(c, rr, rr)
        core = QRadialGradient(c, r, QPointF(c.x() - r * 0.35, c.y() - r * 0.4))
        core.setColorAt(0, col.lighter(190)); core.setColorAt(0.55, col); core.setColorAt(1, col.darker(230))
        p.setPen(Qt.NoPen); p.setBrush(core)
        p.drawEllipse(c, r, r)
        if st in ("thinking", "loading"):
            p.setPen(QPen(QColor(255, 255, 255, 210), 2.6, Qt.SolidLine, Qt.RoundCap))
            p.setBrush(Qt.NoBrush)
            rr = r * 1.3
            p.drawArc(QRectF(c.x() - rr, c.y() - rr, rr * 2, rr * 2), int(-t * 300 * 16), 100 * 16)


class Ring(QWidget):
    def __init__(self):
        super().__init__()
        self.setFixedSize(46, 46)
        self.frac, self.color = 1.0, "#2ee6c8"

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(5, 5, 36, 36)
        p.setPen(QPen(QColor(255, 255, 255, 40), 4)); p.drawEllipse(r)
        p.setPen(QPen(QColor(self.color), 4, Qt.SolidLine, Qt.RoundCap))
        p.drawArc(r, 90 * 16, -int(360 * 16 * self.frac))


class TimerCard(QFrame):
    def __init__(self, app, tid):
        super().__init__()
        self.app, self.tid = app, tid
        self.setObjectName("card")
        h = QHBoxLayout(self); h.setContentsMargins(10, 8, 10, 8); h.setSpacing(10)
        self.ring = Ring(); h.addWidget(self.ring)
        v = QVBoxLayout(); v.setSpacing(0)
        self.time = QLabel("00:00"); self.time.setObjectName("ttime")
        self.name = QLabel(""); self.name.setObjectName("muted")
        v.addWidget(self.time); v.addWidget(self.name)
        h.addLayout(v, 1)
        self.b_pause, self.b_plus, self.b_del = QPushButton("⏸"), QPushButton("+1"), QPushButton("✕")
        for b in (self.b_pause, self.b_plus, self.b_del):
            b.setObjectName("icon"); b.setCursor(Qt.PointingHandCursor); h.addWidget(b)
        self.b_pause.setToolTip("Pause / Weiter"); self.b_del.setToolTip("Löschen")
        self.b_pause.clicked.connect(lambda: app.assistant.toggle_pause(tid))
        self.b_del.clicked.connect(lambda: app.assistant.remove(tid))
        self.done = False
        self.b_plus.clicked.connect(self._plus)

    def _plus(self):
        self.app.assistant.add_time(self.tid, 300 if self.done else 60)

    def refresh(self, d):
        self.done = d["done"]
        if self.done != self.property("done"):
            self.setProperty("done", self.done)
            self.style().unpolish(self); self.style().polish(self)
        self.ring.frac = 0.0 if d["done"] else d["rem"] / max(1, d["total"])
        self.ring.color = "#ff5d6c" if d["done"] else "#ffb84d" if d["paused"] else "#2ee6c8"
        self.ring.update()
        self.time.setText("Abgelaufen" if d["done"] else clock(d["rem"]))
        self.name.setText(("⏸ pausiert · " if d["paused"] else "") + d["label"])
        self.b_pause.setVisible(not d["done"])
        self.b_pause.setText("▶" if d["paused"] else "⏸")
        self.b_plus.setText("+5" if d["done"] else "+1")
        self.b_plus.setToolTip("5 Minuten schlummern" if d["done"] else "1 Minute dazu")


class WeatherCard(QWidget):
    def __init__(self, app):
        super().__init__()
        self.app, self.d = app, None
        v = QVBoxLayout(self); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(8)
        row = QHBoxLayout(); row.setSpacing(6)
        self.search = QLineEdit(); self.search.setPlaceholderText("Ort suchen …")
        self.search.returnPressed.connect(self.do_search)
        self.b_ref = QPushButton("⟳"); self.b_ref.setObjectName("icon"); self.b_ref.setToolTip("Aktualisieren")
        self.b_ref.clicked.connect(self.refresh)
        row.addWidget(self.search, 1); row.addWidget(self.b_ref)
        v.addLayout(row)

        big = QHBoxLayout(); big.setSpacing(10)
        self.icon = QLabel("☀️"); self.icon.setObjectName("bigicon")
        self.temp = QLabel("--°"); self.temp.setObjectName("bigtemp")
        info = QVBoxLayout(); info.setSpacing(0)
        self.place = QLabel("–"); self.place.setStyleSheet("font-weight:600;font-size:14px;")
        self.meta = QLabel(""); self.meta.setObjectName("muted")
        info.addWidget(self.place); info.addWidget(self.meta)
        big.addWidget(self.icon); big.addWidget(self.temp); big.addLayout(info, 1)
        v.addLayout(big)

        self.dayrow = QHBoxLayout(); self.dayrow.setSpacing(5)
        self.chips = []
        for i in range(5):
            b = QPushButton(""); b.setObjectName("day"); b.setCheckable(True)
            b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed); b.setFixedHeight(66)
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, i=i: self.select(i))
            self.chips.append(b); self.dayrow.addWidget(b)
        v.addLayout(self.dayrow)
        self.detail = QLabel(""); self.detail.setWordWrap(True); self.detail.setObjectName("muted")
        v.addWidget(self.detail)

    def set_loading(self):
        self.detail.setText("Lade Wetter …")

    def set_data(self, d):
        self.d = d
        self.place.setText(d["name"])
        self.icon.setText(ICON.get(d["code"], "🌡️"))
        self.temp.setText(f"{d['temp']}°")
        self.meta.setText(f"gefühlt {d['feels']}° · Wind {d['wind']} km/h")
        for i, b in enumerate(self.chips):
            if i < len(d["days"]):
                day = d["days"][i]
                b.setText(f"{day['label']}\n{ICON.get(day['code'], '')}\n{day['hi']}°/{day['lo']}°")
                b.setVisible(True)
            else:
                b.setVisible(False)
        self.select(0)

    def select(self, i):
        if not self.d:
            return
        day = self.d["days"][i]
        for k, b in enumerate(self.chips):
            b.setChecked(k == i)
        self.detail.setText(f"{day['long']}: {WMO.get(day['code'], 'wechselhaft')} · "
                            f"{day['lo']}° bis {day['hi']}° · Regen {day['rain']} %")

    def _lookup(self, city=None):
        if city:
            g = geocode(city)
            if not g:
                return {"error": f"„{city}“ nicht gefunden"}
        elif self.d:
            g = (self.d["lat"], self.d["lon"], self.d["name"])
        else:
            c = self.app.cfg
            g = (c["lat"], c["lon"], c["city"])
        return fetch_weather(*g)

    def _got(self, d):
        if "error" in d:
            self.detail.setText("Wetter nicht verfügbar: " + d["error"][:80])
        else:
            self.set_data(d)

    def do_search(self):
        city = self.search.text().strip()
        if city:
            self.set_loading()
            run_async(lambda: self._lookup(city), self._got)
            self.search.clear(); self.search.clearFocus()

    def refresh(self):
        self.set_loading()
        run_async(self._lookup, self._got)

    def reset(self):
        self.d = None


# ───────────────────────────── Popup ─────────────────────────────────────
def fmt_sw(el):
    h, m, sec = int(el // 3600), int(el % 3600 // 60), el % 60
    return (f"{h}:" if h else "") + f"{m:02d}:{sec:04.1f}"


class StopwatchCard(QFrame):
    def __init__(self, app, wid):
        super().__init__()
        self.setObjectName("card")
        h = QHBoxLayout(self); h.setContentsMargins(14, 9, 10, 9); h.setSpacing(8)
        v = QVBoxLayout(); v.setSpacing(0)
        self.time = QLabel("00:00.0"); self.time.setObjectName("ttime")
        self.laps = QLabel(""); self.laps.setObjectName("muted")
        v.addWidget(self.time); v.addWidget(self.laps)
        h.addLayout(v, 1)
        self.b_toggle, self.b_lap, self.b_del = QPushButton("⏸"), QPushButton("⚑"), QPushButton("✕")
        for b, tip in ((self.b_toggle, "Pause / Weiter"), (self.b_lap, "Runde"), (self.b_del, "Löschen")):
            b.setObjectName("icon"); b.setToolTip(tip); b.setCursor(Qt.PointingHandCursor); h.addWidget(b)
        a = app.assistant
        self.b_toggle.clicked.connect(lambda: a.sw_toggle(wid))
        self.b_lap.clicked.connect(lambda: a.sw_lap(wid))
        self.b_del.clicked.connect(lambda: a.sw_remove(wid))

    def refresh(self, d):
        self.time.setText(fmt_sw(d["el"]))
        self.b_toggle.setText("⏸" if d["running"] else "▶")
        laps = d["laps"][-3:]
        base = len(d["laps"]) - len(laps)
        prev = d["laps"][base - 1] if base > 0 else 0.0
        txt = []
        for i, t in enumerate(laps):
            txt.append(f"Runde {base + i + 1}: {fmt_sw(t - prev)}"); prev = t
        self.laps.setText("   ·   ".join(txt) if txt else ("läuft" if d["running"] else "gestoppt"))


class Popup(QWidget):
    def __init__(self, app):
        super().__init__()
        self.app = app
        self.setWindowFlags(Qt.Tool | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.setStyleSheet(QSS)
        self.bstate = "loading"
        self.deadline = 0.0
        self._target_visible = False
        self.cards, self.sw_cards = {}, {}
        self._app_count = -1

        outer = QVBoxLayout(self); outer.setContentsMargins(18, 14, 18, 26)
        outer.setSizeConstraint(QLayout.SetFixedSize)
        self.panel = QFrame(); self.panel.setObjectName("panel"); self.panel.setFixedWidth(412)
        sh = QGraphicsDropShadowEffect(self.panel); sh.setBlurRadius(46); sh.setOffset(0, 10)
        sh.setColor(QColor(0, 0, 0, 185)); self.panel.setGraphicsEffect(sh)
        outer.addWidget(self.panel)
        v = QVBoxLayout(self.panel); v.setContentsMargins(18, 14, 18, 18); v.setSpacing(11)

        # Kopf
        head = QHBoxLayout(); head.setSpacing(12)
        self.orb = Orb(size=92, ratio=0.2, glow=2.3); self.orb.clicked.connect(app.brain.activate)
        head.addWidget(self.orb)
        col = QVBoxLayout(); col.setSpacing(1)
        self.title = QLabel(name()); self.title.setObjectName("title")
        self.status = QLabel(label("loading")); self.status.setObjectName("status")
        col.addStretch(); col.addWidget(self.title); col.addWidget(self.status); col.addStretch()
        head.addLayout(col, 1)
        btns = QVBoxLayout()
        row = QHBoxLayout(); row.setSpacing(4)
        self.b_pin = QPushButton("📌"); self.b_pin.setObjectName("icon"); self.b_pin.setCheckable(True)
        self.b_pin.setToolTip("Popup offen halten")
        b_set = QPushButton("⚙"); b_set.setObjectName("icon"); b_set.setToolTip("Einstellungen"); b_set.clicked.connect(app.open_settings)
        b_x = QPushButton("✕"); b_x.setObjectName("icon"); b_x.clicked.connect(self.hide_popup)
        for b in (self.b_pin, b_set, b_x):
            b.setCursor(Qt.PointingHandCursor); row.addWidget(b)
        btns.addLayout(row); btns.addStretch()
        head.addLayout(btns)
        v.addLayout(head)

        self.level = QProgressBar(); self.level.setObjectName("level"); self.level.setRange(0, 100)
        self.level.setTextVisible(False); self.level.setFixedHeight(4); v.addWidget(self.level)

        # Gespräch
        self.heard = QLabel(""); self.heard.setObjectName("bubbleUser"); self.heard.setWordWrap(True); self.heard.hide()
        self.reply = QLabel(""); self.reply.setObjectName("bubbleVia"); self.reply.setWordWrap(True); self.reply.hide()
        v.addWidget(self.heard); v.addWidget(self.reply)

        # Chips
        chips = QHBoxLayout(); chips.setSpacing(6)
        self.t_btn, self.s_btn, self.w_btn, self.a_btn = (QPushButton(x) for x in
                                                          ("⏱ Timer", "⏲ Stoppuhr", "☀ Wetter", "▦ Apps"))
        for b in (self.t_btn, self.s_btn, self.w_btn, self.a_btn):
            b.setObjectName("chip"); b.setCheckable(True); b.setCursor(Qt.PointingHandCursor); chips.addWidget(b)
        v.addLayout(chips)

        # Timer
        self.t_sec = QWidget(); ts = QVBoxLayout(self.t_sec); ts.setContentsMargins(0, 0, 0, 0); ts.setSpacing(8)
        quick = QHBoxLayout(); quick.setSpacing(5)
        for m in (1, 5, 10, 30):
            b = QPushButton(f"+ {m} min"); b.setObjectName("pill"); b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, m=m: self.add_timer(m * 60)); quick.addWidget(b)
        quick.addStretch(); ts.addLayout(quick)
        custom = QHBoxLayout(); custom.setSpacing(6)
        self.spin = QSpinBox(); self.spin.setRange(1, 999); self.spin.setValue(7); self.spin.setSuffix(" min")
        go = QPushButton("▶ Start"); go.setObjectName("pill"); go.setCursor(Qt.PointingHandCursor)
        go.clicked.connect(lambda: self.add_timer(self.spin.value() * 60))
        custom.addWidget(self.spin); custom.addWidget(go); custom.addStretch(); ts.addLayout(custom)
        self.cards_box = QVBoxLayout(); self.cards_box.setSpacing(7); ts.addLayout(self.cards_box)
        self.empty = QLabel("Kein Timer aktiv"); self.empty.setObjectName("muted"); ts.addWidget(self.empty)
        v.addWidget(self.t_sec)

        # Stoppuhr
        self.s_sec = QWidget(); ss = QVBoxLayout(self.s_sec); ss.setContentsMargins(0, 0, 0, 0); ss.setSpacing(8)
        sb = QPushButton("▶ Neue Stoppuhr"); sb.setObjectName("pill"); sb.setCursor(Qt.PointingHandCursor)
        sb.clicked.connect(lambda: (app.assistant.sw_new(), self.s_btn.setChecked(True), self.touch()))
        ss.addWidget(sb, 0, Qt.AlignLeft)
        self.sw_box = QVBoxLayout(); self.sw_box.setSpacing(7); ss.addLayout(self.sw_box)
        self.sw_empty = QLabel("Keine Stoppuhr aktiv"); self.sw_empty.setObjectName("muted"); ss.addWidget(self.sw_empty)
        v.addWidget(self.s_sec)

        # Apps
        self.a_sec = QWidget(); ap = QVBoxLayout(self.a_sec); ap.setContentsMargins(0, 0, 0, 0); ap.setSpacing(8)
        self.launch_in = QLineEdit(); self.launch_in.setPlaceholderText("App, Webseite oder Ordner öffnen …")
        self.launch_in.returnPressed.connect(lambda: self.launch(self.launch_in.text()))
        self.completer = QCompleter(); self.completer.setCaseSensitivity(Qt.CaseInsensitive)
        self.completer.setFilterMode(Qt.MatchContains); self.launch_in.setCompleter(self.completer)
        ap.addWidget(self.launch_in)
        self.favs = QGridLayout(); self.favs.setSpacing(6); ap.addLayout(self.favs)
        v.addWidget(self.a_sec)
        self.refresh_favs()

        # Wetter
        self.weather = WeatherCard(app)
        v.addWidget(self.weather)

        self.t_btn.toggled.connect(self.t_sec.setVisible)
        self.s_btn.toggled.connect(self.s_sec.setVisible)
        self.a_btn.toggled.connect(self.a_sec.setVisible)
        self.w_btn.toggled.connect(self._weather_toggled)
        for w in (self.t_sec, self.s_sec, self.a_sec, self.weather):
            w.hide()

        self.fade = QPropertyAnimation(self, b"windowOpacity", self)
        self.fade.setDuration(170)
        self.fade.finished.connect(self._fade_done)

        b = app.brain
        b.state.connect(self.on_state); b.heard.connect(self.on_heard); b.reply.connect(self.on_reply)
        b.hint.connect(self.on_hint); b.weather.connect(self.on_weather); b.error.connect(self.on_error)
        b.level.connect(self.on_level)
        QTimer(self, interval=100, timeout=self.tick).start()

    # ---- Aktionen
    def _weather_toggled(self, on):
        self.weather.setVisible(on)
        if on and self.weather.d is None:
            self.weather.refresh()

    def add_timer(self, sec):
        self.app.assistant.add_timer(sec)
        self.t_btn.setChecked(True)
        self.touch()

    def refresh_favs(self):
        while self.favs.count():
            w = self.favs.takeAt(0).widget()
            if w:
                w.deleteLater()
        names = self.app.cfg.get("fav_apps") or ["Rechner", "Editor", "Datei-Explorer", "Browser"]
        for i, n in enumerate(names[:9]):
            b = QPushButton(n); b.setObjectName("appbtn"); b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, n=n: self.launch(n))
            self.favs.addWidget(b, i // 3, i % 3)

    def launch(self, text):
        n = (text or "").strip()
        if not n:
            return
        hit = self.app.assistant.apps.open(n)
        self.reply.setText(f"Öffne {hit}." if hit else f"„{n}“ habe ich nicht gefunden.")
        self.reply.show()
        self.launch_in.clear()
        self.touch()

    def touch(self):
        self.deadline = time.time() + float(self.app.cfg.get("autohide", 7))

    def _reposition(self):
        geo = QGuiApplication.primaryScreen().availableGeometry()
        m, w, h = 10, self.width(), self.height()
        c = self.app.cfg.get("corner", "tr")
        x = geo.right() - w - m + 1 if c in ("tr", "br") else geo.left() + m
        y = geo.top() + m if c in ("tr", "tl") else geo.bottom() - h - m + 1
        self.move(x, y)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._reposition()

    def show_popup(self):
        self.touch()
        if self._target_visible:
            return
        self._target_visible = True
        self.adjustSize(); self._reposition()
        self.fade.stop()
        self.setWindowOpacity(0.0)
        self.show()
        self.fade.setStartValue(0.0); self.fade.setEndValue(1.0); self.fade.start()

    def hide_popup(self):
        if not self.isVisible() or not self._target_visible:
            return
        self._target_visible = False
        self.fade.stop()
        self.fade.setStartValue(self.windowOpacity()); self.fade.setEndValue(0.0); self.fade.start()

    def toggle_popup(self):
        if self._target_visible:
            self.hide_popup()
        else:
            self.t_btn.setChecked(bool(self.app.assistant.snapshot()))
            self.s_btn.setChecked(bool(self.app.assistant.sw_snapshot()))
            self.show_popup()

    def _fade_done(self):
        if not self._target_visible:
            self.hide()

    # ---- Signale vom Gehirn
    def on_state(self, s):
        self.bstate = s
        if s == "listening":
            self.reply.hide(); self.reply.setText(""); self.heard.hide(); self.heard.setText("")
            self.t_btn.setChecked(bool(self.app.assistant.snapshot()))
            self.s_btn.setChecked(bool(self.app.assistant.sw_snapshot()))
            self.show_popup()
        elif s in ("thinking", "loading"):
            self.touch()

    def on_level(self, lvl):
        self.level.setValue(int(min(1.0, lvl * 1.6) * 100) if self.bstate == "listening" else 0)

    def on_heard(self, t):
        if t:
            self.heard.setText("„" + t.strip("„“") + "“"); self.heard.show()
            self.show_popup()
        else:
            self.heard.hide()

    def on_reply(self, t):
        self.reply.setText(t); self.reply.show()
        self.show_popup()

    def on_error(self, t):
        self.reply.setText(t); self.reply.show()
        self.show_popup()

    def on_hint(self, h):
        if h == "timers":
            self.t_btn.setChecked(True)
        elif h == "weather":
            self.w_btn.setChecked(True)
        elif h == "stopwatch":
            self.s_btn.setChecked(True)
        elif h == "settings":
            self.app.open_settings()
        elif h == "codelab":
            self.app.open_codelab()
        self.touch()

    def on_weather(self, d):
        self.weather.set_data(d)

    # ---- Takt
    @staticmethod
    def _sync(cards, box, snap, make, refresh):
        ids = [d["id"] for d in snap]
        if ids != list(cards.keys()):
            for c in cards.values():
                box.removeWidget(c); c.deleteLater()
            cards.clear()
            for d in snap:
                c = make(d["id"]); cards[d["id"]] = c; box.addWidget(c)
        for d in snap:
            refresh(cards[d["id"]], d)

    def tick(self):
        a, sp = self.app.assistant, self.app.speaker
        st = "speaking" if sp.pending and self.bstate != "error" else self.bstate
        self.orb.state = st
        self.title.setText(name())
        self.status.setText(label(st))
        self.status.setStyleSheet(f"color:{COL.get(st, '#fff')};")

        for lab, first in a.pop_alarms():
            sp.sound("alarm")
            if first:
                sp.say(f"Dein Timer für {lab} ist abgelaufen.")
            self.reply.setText(f"⏰ Timer abgelaufen: {lab}"); self.reply.show()
            self.t_btn.setChecked(True)
            self.show_popup()

        snap, sws = a.snapshot(), a.sw_snapshot()
        if self.isVisible():
            self._sync(self.cards, self.cards_box, snap, lambda i: TimerCard(self.app, i), lambda c, d: c.refresh(d))
            self._sync(self.sw_cards, self.sw_box, sws, lambda i: StopwatchCard(self.app, i), lambda c, d: c.refresh(d))
            self.empty.setVisible(not snap)
            self.sw_empty.setVisible(not sws)
            n = len(a.apps.apps)
            if n != self._app_count:
                self._app_count = n
                self.completer.setModel(QStringListModel(a.apps.names()))
        self.t_btn.setText(f"⏱ Timer ({len(snap)})" if snap else "⏱ Timer")
        self.s_btn.setText(f"⏲ Stoppuhr ({len(sws)})" if sws else "⏲ Stoppuhr")

        if not self._target_visible:
            return
        fw = QApplication.focusWidget()
        stay = (self.app.cfg.get("pin") or self.b_pin.isChecked() or sp.pending
                or self.bstate in ("listening", "thinking", "loading")
                or any(d["done"] for d in snap)
                or self.geometry().contains(QCursor.pos())
                or (fw is not None and self.isAncestorOf(fw) and isinstance(fw, (QLineEdit, QSpinBox)))
                or self.app.settings_open())
        if stay:
            self.touch()
        elif time.time() > self.deadline:
            self.hide_popup()


VOICES = {"Thorsten · hoch (beste Qualität)": ("thorsten", "high"), "Thorsten · mittel (schneller)": ("thorsten", "medium"),
          "Thorsten · emotional": ("thorsten_emotional", "medium"), "Ramona": ("ramona", "low"),
          "Karlsson": ("karlsson", "low"), "Kerstin": ("kerstin", "low"), "MLS · mittel": ("mls", "medium")}


class SettingsDialog(QDialog):
    def __init__(self, app):
        super().__init__()
        self.app, self.cfg = app, app.cfg
        self.setWindowTitle(f"{name()} · Einstellungen")
        self.setStyleSheet(QSS)
        self.setMinimumWidth(440)
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame)
        inner = QWidget(); scroll.setWidget(inner); outer.addWidget(scroll)
        self.resize(520, 780)
        v = QVBoxLayout(inner); v.setContentsMargins(22, 20, 22, 20); v.setSpacing(8)

        def sec(text):
            l = QLabel(text.upper()); l.setObjectName("sec"); l.setContentsMargins(0, 10, 0, 0); v.addWidget(l)

        sec("Name des Assistenten")
        row = QHBoxLayout()
        self.name_edit = QLineEdit(name()); self.name_edit.returnPressed.connect(self.on_name)
        nb = QPushButton("Übernehmen"); nb.setObjectName("pill"); nb.clicked.connect(self.on_name)
        row.addWidget(self.name_edit, 1); row.addWidget(nb); v.addLayout(row)
        nh = QLabel("Aufgerufen wird er mit „Hey <Name>“ oder einfach „Hey“. Kurze, klare Namen werden am besten erkannt.")
        nh.setObjectName("muted"); nh.setWordWrap(True); v.addWidget(nh)

        sec("Mikrofon")
        row = QHBoxLayout()
        self.mic = QComboBox(); row.addWidget(self.mic, 1)
        rb = QPushButton("↻"); rb.setObjectName("icon"); rb.setToolTip("Geräte neu laden"); rb.clicked.connect(self.fill_devices)
        row.addWidget(rb); v.addLayout(row)
        self.meter = QProgressBar(); self.meter.setRange(0, 100); self.meter.setTextVisible(False)
        v.addWidget(self.meter)
        hint = QLabel("Sprich etwas: Der Balken zeigt, ob das Mikrofon dich hört."); hint.setObjectName("muted"); v.addWidget(hint)
        self.mute = QCheckBox("Mikrofon stummschalten (Via hört nicht zu)")
        self.mute.setChecked(app.brain.muted); self.mute.toggled.connect(self.on_mute); v.addWidget(self.mute)
        row = QHBoxLayout(); row.addWidget(QLabel("Empfindlichkeit"))
        self.gate = QSlider(Qt.Horizontal); self.gate.setRange(100, 1500); self.gate.setInvertedAppearance(True)
        self.gate.setValue(int(self.cfg.get("mic_gate", 150))); self.gate.valueChanged.connect(lambda x: self.set("mic_gate", x))
        row.addWidget(self.gate, 1); v.addLayout(row)
        row = QHBoxLayout(); row.addWidget(QLabel("Spracherkennung"))
        self.stt = QComboBox()
        for lab, key in (("Whisper small · sehr genau", "whisper-small"), ("Whisper base · schneller", "whisper-base"),
                         ("Vosk · einfach", "vosk")):
            self.stt.addItem(lab, key)
        self.stt.setCurrentIndex(max(0, self.stt.findData(self.cfg.get("stt", "whisper-small"))))
        self.stt.currentIndexChanged.connect(self.on_stt)
        row.addWidget(self.stt, 1)
        mt = QPushButton("🎙 Aufnahme-Test"); mt.setObjectName("pill"); mt.clicked.connect(self.mic_test); row.addWidget(mt)
        v.addLayout(row)
        self.stt_info = QLabel(""); self.stt_info.setObjectName("muted"); self.stt_info.setWordWrap(True); v.addWidget(self.stt_info)

        sec("Lautsprecher & Stimme")
        row = QHBoxLayout()
        self.out = QComboBox(); row.addWidget(self.out, 1)
        tb = QPushButton("🔊 Test"); tb.setObjectName("pill"); tb.clicked.connect(self.test_sound); row.addWidget(tb)
        v.addLayout(row)
        self.speak = QCheckBox("Via spricht Antworten aus"); self.speak.setChecked(self.cfg.get("speak", True))
        self.speak.toggled.connect(lambda x: self.set("speak", x)); v.addWidget(self.speak)
        row = QHBoxLayout(); row.addWidget(QLabel("Lautstärke"))
        self.vol = QSlider(Qt.Horizontal); self.vol.setRange(10, 100); self.vol.setValue(int(self.cfg.get("volume", 0.9) * 100))
        self.vol.valueChanged.connect(lambda x: self.set("volume", x / 100)); row.addWidget(self.vol, 1)
        v.addLayout(row)

        row = QHBoxLayout(); row.addWidget(QLabel("Stimme"))
        self.voice = QComboBox(); row.addWidget(self.voice, 1); v.addLayout(row)
        row = QHBoxLayout(); row.addWidget(QLabel("Sprechtempo"))
        self.speed = QSlider(Qt.Horizontal); self.speed.setRange(70, 140); self.speed.setValue(int(self.cfg.get("speed", 1.0) * 100))
        self.speed.valueChanged.connect(lambda x: self.set("speed", x / 100)); row.addWidget(self.speed, 1)
        v.addLayout(row)
        row = QHBoxLayout()
        self.dl = QComboBox()
        for lab in VOICES:
            self.dl.addItem(lab)
        db = QPushButton("⬇ Stimme laden"); db.setObjectName("pill"); db.clicked.connect(self.dl_voice)
        row.addWidget(self.dl, 1); row.addWidget(db); v.addLayout(row)
        self.voice_info = QLabel(""); self.voice_info.setObjectName("muted"); v.addWidget(self.voice_info)

        sec("Standard-Ort für das Wetter")
        row = QHBoxLayout()
        self.city = QLineEdit(self.cfg.get("city", "")); self.city.returnPressed.connect(self.find_city)
        cb = QPushButton("Suchen"); cb.setObjectName("pill"); cb.clicked.connect(self.find_city)
        row.addWidget(self.city, 1); row.addWidget(cb); v.addLayout(row)
        self.city_info = QLabel(f"✓ {self.cfg.get('city')}"); self.city_info.setObjectName("muted"); v.addWidget(self.city_info)

        sec("Gehirn · wer antwortet im Gespräch?")
        self.brain_sel = QComboBox()
        self.brain_sel.addItem("Eigenes Via-Gehirn · offline, selbst trainiert, trainierbar", "own")
        self.brain_sel.addItem("KI-Modell · Ollama (lokal) oder Gemini (online), vortrainiert", "llm")
        cur = "llm" if self.cfg.get("brain", "own") in ("llm", "gemini") else "own"
        self.brain_sel.setCurrentIndex(max(0, self.brain_sel.findData(cur)))
        self.brain_sel.currentIndexChanged.connect(lambda: self.set("brain", self.brain_sel.currentData()))
        v.addWidget(self.brain_sel)
        self.prov = QComboBox()
        self.prov.addItem("KI-Modell läuft lokal mit Ollama (empfohlen)", "ollama")
        self.prov.addItem("KI-Modell online bei Google (Gemini)", "gemini")
        self.prov.setCurrentIndex(max(0, self.prov.findData(llmapi.provider(self.cfg))))
        v.addWidget(self.prov)
        self.gkey = QLineEdit(self.cfg.get("gemini_key", "")); self.gkey.setEchoMode(QLineEdit.Password)
        self.gkey.setPlaceholderText("Gemini-API-Schlüssel (kostenlos: aistudio.google.com)")
        self.gkey.editingFinished.connect(lambda: self.set("gemini_key", self.gkey.text().strip()))
        v.addWidget(self.gkey)
        row = QHBoxLayout()
        self.gmodel = QComboBox(); self.gmodel.setEditable(True)
        self.gmodel.setEditText(self._model_text())
        self.gmodel.editTextChanged.connect(self.on_model_text)
        gm = QPushButton("Modelle laden"); gm.setObjectName("pill"); gm.clicked.connect(self.load_models)
        row.addWidget(self.gmodel, 1); row.addWidget(gm); v.addLayout(row)
        self.pull_row = QWidget(); pr = QHBoxLayout(self.pull_row); pr.setContentsMargins(0, 0, 0, 0)
        self.rec = QComboBox(); self.rec.addItems(llmapi.RECOMMENDED)
        pl = QPushButton("⬇ Herunterladen"); pl.setObjectName("pill"); pl.clicked.connect(self.pull_model)
        oi = QPushButton("Ollama holen"); oi.setObjectName("pill"); oi.clicked.connect(lambda: webbrowser.open("https://ollama.com/download"))
        pr.addWidget(self.rec, 1); pr.addWidget(pl); pr.addWidget(oi); v.addWidget(self.pull_row)
        self.gem_info = QLabel(""); self.gem_info.setObjectName("muted"); self.gem_info.setWordWrap(True); v.addWidget(self.gem_info)
        self.prov.currentIndexChanged.connect(self.on_provider)
        self.on_provider(save=False)
        row = QHBoxLayout()
        pb = QPushButton("💻 Programmierecke"); pb.setObjectName("pill"); pb.clicked.connect(self.app.open_codelab)
        tb2 = QPushButton("🧠 Trainings-App"); tb2.setObjectName("pill"); tb2.clicked.connect(self.open_trainer)
        row.addWidget(pb); row.addWidget(tb2); row.addStretch(); v.addLayout(row)

        sec("Apps öffnen")
        self.app_info = QLabel(""); self.app_info.setObjectName("muted"); self.app_info.setWordWrap(True); v.addWidget(self.app_info)
        row = QHBoxLayout()
        self.favs_edit = QLineEdit(", ".join(self.cfg.get("fav_apps") or []))
        self.favs_edit.setPlaceholderText("Schnellstart im Popup, z. B.: Chrome, Spotify, Rechner")
        self.favs_edit.editingFinished.connect(self.on_favs)
        rb = QPushButton("Neu einlesen"); rb.setObjectName("pill"); rb.clicked.connect(lambda: self.app.assistant.apps.rescan())
        row.addWidget(self.favs_edit, 1); row.addWidget(rb); v.addLayout(row)
        row = QHBoxLayout()
        self.cust_name = QLineEdit(); self.cust_name.setPlaceholderText("Name, z. B. Mein Spiel")
        self.cust_path = QLineEdit(); self.cust_path.setPlaceholderText("Pfad zur Datei / Ordner")
        pk = QPushButton("…"); pk.setObjectName("pill"); pk.clicked.connect(self.pick_path)
        ad = QPushButton("＋"); ad.setObjectName("pill"); ad.clicked.connect(self.add_custom)
        row.addWidget(self.cust_name, 1); row.addWidget(self.cust_path, 2); row.addWidget(pk); row.addWidget(ad); v.addLayout(row)
        self.cust_list = QListWidget(); self.cust_list.setMaximumHeight(80); v.addWidget(self.cust_list)
        rm = QPushButton("Ausgewählte entfernen"); rm.setObjectName("pill"); rm.clicked.connect(self.rm_custom)
        v.addWidget(rm, 0, Qt.AlignLeft)
        self.refresh_custom()

        sec("KI · Vias eigenes Gehirn")
        self.llm_on = QCheckBox("Frei mit Via sprechen (Vias eigenes Gehirn antwortet)")
        self.llm_on.setChecked(self.cfg.get("llm", True)); self.llm_on.toggled.connect(lambda x: self.set("llm", x))
        v.addWidget(self.llm_on)
        self.llm_info = QLabel(""); self.llm_info.setObjectName("muted"); self.llm_info.setWordWrap(True)
        v.addWidget(self.llm_info)
        self.force = QCheckBox("Auch ein unfertig trainiertes Gehirn benutzen (experimentell, Neustart nötig)")
        self.force.setChecked(self.cfg.get("brain_force", False)); self.force.toggled.connect(lambda x: self.set("brain_force", x))
        v.addWidget(self.force)
        rs = QPushButton("Gespräch zurücksetzen"); rs.setObjectName("pill"); rs.clicked.connect(self.app.llm.reset)
        v.addWidget(rs, 0, Qt.AlignLeft)
        self._lt = QTimer(self, interval=1000, timeout=self.refresh_llm); self._lt.start()
        self.refresh_llm()

        sec("Popup")
        row = QHBoxLayout(); row.addWidget(QLabel("Position"))
        self.corner = QComboBox()
        for k, n in (("tr", "Oben rechts"), ("tl", "Oben links"), ("br", "Unten rechts"), ("bl", "Unten links")):
            self.corner.addItem(n, k)
        self.corner.setCurrentIndex(max(0, self.corner.findData(self.cfg.get("corner", "tr"))))
        self.corner.currentIndexChanged.connect(self.on_corner)
        row.addWidget(self.corner, 1); v.addLayout(row)
        row = QHBoxLayout(); row.addWidget(QLabel("Automatisch ausblenden nach"))
        self.hide = QSpinBox(); self.hide.setRange(2, 60); self.hide.setSuffix(" s"); self.hide.setValue(int(self.cfg.get("autohide", 7)))
        self.hide.valueChanged.connect(lambda x: self.set("autohide", x)); row.addWidget(self.hide); row.addStretch()
        v.addLayout(row)
        self.pin = QCheckBox("Popup immer offen lassen"); self.pin.setChecked(self.cfg.get("pin", False))
        self.pin.toggled.connect(lambda x: self.set("pin", x)); v.addWidget(self.pin)

        v.addSpacing(8)
        done = QPushButton("Fertig"); done.setObjectName("pill"); done.clicked.connect(self.close)
        v.addWidget(done, 0, Qt.AlignRight)

        self.mic.currentIndexChanged.connect(self.on_mic)
        self.out.currentIndexChanged.connect(self.on_out)
        app.brain.level.connect(self.on_level)
        self.fill_devices()
        self.fill_voices()
        self.voice.currentIndexChanged.connect(self.on_voice)

    def set(self, k, val):
        self.cfg[k] = val; save_cfg(self.cfg)

    def refresh_llm(self):
        l = self.app.llm
        if not self.cfg.get("llm", True):
            txt = "Aus: Via versteht nur feste Befehle."
        elif l.error:
            txt = "✗ " + l.error[:120]
        elif l.ready:
            txt = "✓ Bereit · " + l.info
        else:
            txt = "Lädt …"
        self.llm_info.setText(txt)
        w = self.app.whisper
        if not self.cfg.get("stt", "whisper-small").startswith("whisper"):
            self.stt_info.setText("Vosk: schnell, aber ungenau. Für gute Erkennung Whisper wählen.")
        elif w.ready:
            self.stt_info.setText(f"✓ Whisper {w.size} bereit")
        elif w.error:
            self.stt_info.setText("✗ " + w.error[:140] + "  (Dann nutzt Via Vosk.)")
        else:
            self.stt_info.setText("Whisper lädt (beim ersten Mal wird das Modell heruntergeladen) …")
        a = self.app.assistant.apps
        self.app_info.setText(f"{len(a.apps)} Programme gefunden" if a.ready else "Lese installierte Programme ein …")

    def fill_devices(self):
        for combo, kind, key in ((self.mic, "input", "input_device"), (self.out, "output", "output_device")):
            combo.blockSignals(True); combo.clear()
            combo.addItem("Standard (System)", None)
            for _, name in list_devices(kind):
                combo.addItem(name, name)
            idx = combo.findData(self.cfg.get(key))
            combo.setCurrentIndex(idx if idx >= 0 else 0)
            combo.blockSignals(False)

    def on_mic(self):
        self.app.brain.set_input(self.mic.currentData())

    def on_out(self):
        self.set("output_device", self.out.currentData())
        self.app.speaker.sound("chime")

    def test_sound(self):
        self.app.speaker.say(f"So klinge ich. Hallo, ich bin {name()}.")

    def on_mute(self, x):
        self.app.set_muted(x)

    def on_level(self, lvl):
        if self.isVisible():
            self.meter.setValue(int(min(1.0, lvl * 1.4) * 100))

    def on_corner(self):
        self.set("corner", self.corner.currentData())
        self.app.popup._reposition()

    def find_city(self):
        c = self.city.text().strip()
        if not c:
            return
        self.city_info.setText("Suche …")

        def done(g):
            if isinstance(g, dict) or not g:
                self.city_info.setText("✗ Ort nicht gefunden")
                return
            lat, lon, name = g
            self.cfg.update(city=name, lat=lat, lon=lon); save_cfg(self.cfg)
            self.city.setText(name)
            self.city_info.setText(f"✓ {name} ({lat:.2f}, {lon:.2f})")
            self.app.popup.weather.reset()
        run_async(lambda: geocode(c), done)

    def _model_key(self):
        return "gemini_model" if llmapi.provider(self.cfg) == "gemini" else "ollama_model"

    def _model_text(self):
        return self.cfg.get(self._model_key()) or "automatisch"

    def on_model_text(self, t):
        self.set(self._model_key(), "" if t.strip() in ("", "automatisch") else t.strip())

    def on_provider(self, *_, save=True):
        if save:
            self.set("llm_provider", self.prov.currentData())
        g = llmapi.provider(self.cfg) == "gemini"
        self.gkey.setVisible(g)
        self.pull_row.setVisible(not g)
        self.gmodel.blockSignals(True); self.gmodel.clear(); self.gmodel.setEditText(self._model_text()); self.gmodel.blockSignals(False)
        self.gem_info.setText(
            "Gemini: Deine Sätze gehen an Google. Schlüssel kostenlos auf aistudio.google.com." if g else
            "Ollama läuft lokal, nichts verlässt deinen PC. Erst Ollama installieren, dann ein Modell herunterladen. "
            "Für Gespräche reichen kleine Modelle (3B), für Code ist ein Coder-Modell (7B) besser.")

    def load_models(self):
        self.set("gemini_key", self.gkey.text().strip())
        self.gem_info.setText("Lade Modelle …")
        cfg = self.cfg

        def work():
            return gemini.list_models(gemini.api_key(cfg)) if llmapi.provider(cfg) == "gemini" else llmapi.ollama_models(cfg)

        def done(ms):
            if isinstance(ms, dict):
                self.gem_info.setText("✗ " + ms.get("error", "")[:160]); return
            self.gmodel.blockSignals(True); self.gmodel.clear(); self.gmodel.addItems(["automatisch"] + ms)
            self.gmodel.setEditText(self._model_text()); self.gmodel.blockSignals(False)
            self.gem_info.setText(f"✓ {len(ms)} Modelle gefunden. „automatisch“ wählt ein passendes." if ms else
                                  "Noch kein Modell installiert. Wähle unten eines zum Herunterladen.")
        run_async(work, done)

    def pull_model(self):
        name = self.rec.currentText().strip()
        self.gem_info.setText(f"Lade {name} herunter … das kann einige Minuten dauern, du kannst weiterarbeiten.")
        cfg = self.cfg

        def done(res):
            if isinstance(res, dict):
                self.gem_info.setText("✗ " + res.get("error", "")[:160]); return
            self.gmodel.setEditText(name)
            self.gem_info.setText(f"✓ {name} ist installiert und ausgewählt.")
        run_async(lambda: llmapi.pull(cfg, name), done)

    def open_trainer(self):
        subprocess.Popen([sys.executable, str(BASE / "trainer_app.py")], cwd=str(BASE))

    def refresh_custom(self):
        self.cust_list.clear()
        for n, p in (self.cfg.get("apps") or {}).items():
            self.cust_list.addItem(f"{n}  →  {p}")

    def add_custom(self):
        n, p = self.cust_name.text().strip(), self.cust_path.text().strip().strip('"')
        if n and p:
            apps = dict(self.cfg.get("apps") or {}); apps[n] = p
            self.set("apps", apps)
            self.cust_name.clear(); self.cust_path.clear()
            self.refresh_custom(); self.app.assistant.apps.rescan()

    def rm_custom(self):
        row = self.cust_list.currentRow()
        apps = dict(self.cfg.get("apps") or {})
        if 0 <= row < len(apps):
            del apps[list(apps)[row]]
            self.set("apps", apps); self.refresh_custom(); self.app.assistant.apps.rescan()

    def pick_path(self):
        f, _ = QFileDialog.getOpenFileName(self, "App oder Datei wählen")
        if f:
            self.cust_path.setText(f)
            if not self.cust_name.text():
                self.cust_name.setText(Path(f).stem)

    def on_favs(self):
        self.set("fav_apps", [x.strip() for x in self.favs_edit.text().split(",") if x.strip()])
        self.app.popup.refresh_favs()

    def fill_voices(self):
        self.voice.blockSignals(True); self.voice.clear()
        for f in Speaker.available_voices():
            self.voice.addItem(f.replace(".onnx", ""), f)
        i = self.voice.findData(self.cfg.get("voice"))
        self.voice.setCurrentIndex(i if i >= 0 else 0)
        self.voice.blockSignals(False)

    def on_voice(self):
        self.set("voice", self.voice.currentData())
        self.app.speaker.reload_voice()
        self.app.speaker.say(f"Hallo, ich bin {name()}. So klinge ich jetzt.")

    def on_name(self):
        n = self.name_edit.text().strip()
        if n:
            self.set("name", n)
            self.app.name_changed()
            self.app.speaker.say(f"Okay, ich heiße jetzt {n}.")

    def on_stt(self):
        self.set("stt", self.stt.currentData())
        self.app.whisper.configure()

    def mic_test(self):
        """Nimmt 4 Sekunden auf und spielt sie ab - so hörst du, was Via hört."""
        self.stt_info.setText("🎙 Sprich jetzt … (4 Sekunden)")
        b = self.app.brain
        was = b.muted
        b.muted = True

        def work():
            dev_in = find_device(self.cfg.get("input_device"), "input")
            dev_out = find_device(self.cfg.get("output_device"), "output")
            rec = sd.rec(int(4 * SR_IN), samplerate=SR_IN, channels=1, dtype="int16", device=dev_in)
            sd.wait()
            peak = int(np.abs(rec).max())
            sd.play(rec, SR_IN, device=dev_out); sd.wait()
            return peak

        def done(peak):
            b.muted = was
            if isinstance(peak, dict):
                self.stt_info.setText("✗ Aufnahme-Test fehlgeschlagen: " + peak.get("error", "")[:100])
            else:
                self.stt_info.setText("✓ Das war deine Aufnahme." if peak > 800 else
                                      "⚠ Sehr leise - anderes Mikrofon wählen oder Empfindlichkeit erhöhen.")
        run_async(work, done)

    def dl_voice(self):
        nm, q = VOICES[self.dl.currentText()]
        base = f"https://huggingface.co/rhasspy/piper-voices/resolve/main/de/de_DE/{nm}/{q}/de_DE-{nm}-{q}"
        self.voice_info.setText("Lade Stimme herunter …")

        def work():
            for ext in (".onnx", ".onnx.json"):
                dest = MODELS / f"de_DE-{nm}-{q}{ext}"
                if not dest.exists():
                    urllib.request.urlretrieve(base + ext, str(dest) + ".part")
                    os.replace(str(dest) + ".part", dest)
            return f"de_DE-{nm}-{q}.onnx"

        def done(res):
            if isinstance(res, dict):
                self.voice_info.setText("✗ Download fehlgeschlagen: " + res.get("error", "")[:90]); return
            self.voice_info.setText("✓ Geladen: " + res)
            self.fill_voices()
            self.voice.setCurrentIndex(self.voice.findData(res))
        run_async(work, done)

    def closeEvent(self, e):
        self.app.popup.touch()
        super().closeEvent(e)


# ───────────────────────────── App ───────────────────────────────────────
def make_icon():
    pix = QPixmap(64, 64); pix.fill(Qt.transparent)
    p = QPainter(pix); p.setRenderHint(QPainter.Antialiasing)
    g = QRadialGradient(QPointF(32, 32), 28, QPointF(24, 22))
    g.setColorAt(0, QColor("#c9d0ff")); g.setColorAt(0.55, QColor("#6c7bff")); g.setColorAt(1, QColor("#2a2f8f"))
    p.setPen(Qt.NoPen); p.setBrush(g); p.drawEllipse(QPointF(32, 32), 27, 27)
    p.end()
    return QIcon(pix)


class ViaApp(QObject):
    quitRequest = Signal()

    def __init__(self):
        super().__init__()
        global BRIDGE, CFG
        BRIDGE = Bridge()
        self.cfg = load_cfg()
        CFG = self.cfg
        self.assistant = Assistant(self.cfg)
        self.speaker = Speaker(self.cfg)
        self.llm = LLM(self.cfg)
        self.cloud = llmapi.ChatBrain(self.cfg, name)
        self.codelab = None
        self.whisper = Whisper(self.cfg)
        self.brain = Brain(self.cfg, self.assistant, self.speaker, self.llm, self.whisper)
        self.brain.cloud = self.cloud
        self.settings = None
        self.popup = Popup(self)
        self.quitting = False

        self.tray = QSystemTrayIcon(make_icon())
        self.tray.setToolTip(f"{name()} – sag „Hey {name()}“")
        menu = QMenu()
        self.open_act = menu.addAction(f"{name()} öffnen", self.popup.show_popup)
        menu.addAction("Programmierecke", self.open_codelab)
        menu.addAction("Einstellungen", self.open_settings)
        self.mute_act = QAction("Mikrofon stumm", menu, checkable=True)
        self.mute_act.toggled.connect(self.set_muted)
        menu.addAction(self.mute_act)
        menu.addSeparator()
        menu.addAction("Beenden", self.quit)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(lambda r: self.popup.toggle_popup()
                                    if r == QSystemTrayIcon.Trigger else None)
        self.tray.show()
        self._menu = menu

        self.brain.quit.connect(lambda: setattr(self, "quitting", True))
        self.quitRequest.connect(self.quit)
        QTimer(self, interval=200, timeout=self._poll).start()
        self.brain.start()
        self.assistant.apps.rescan()
        self.whisper.configure()
        self.popup.show_popup()
        if QSystemTrayIcon.isSystemTrayAvailable():
            self.tray.showMessage(f"{name()} läuft", f"Sag „Hey {name()}“ – oder klicke auf das Symbol.",
                                  QSystemTrayIcon.Information, 3000)

    def _poll(self):
        if self.quitting and not self.speaker.pending:
            self.quit()

    def settings_open(self):
        return self.settings is not None and self.settings.isVisible()

    def open_settings(self):
        if self.settings is None:
            self.settings = SettingsDialog(self)
        self.settings.fill_devices()
        self.settings.show(); self.settings.raise_(); self.settings.activateWindow()

    def open_codelab(self):
        if self.codelab is None:
            import codelab
            self.codelab = codelab.CodeLab(self.cfg)
        self.codelab.show(); self.codelab.raise_(); self.codelab.activateWindow()

    def set_muted(self, x):
        self.brain.muted = x
        self.mute_act.blockSignals(True); self.mute_act.setChecked(x); self.mute_act.blockSignals(False)
        if self.settings:
            self.settings.mute.blockSignals(True); self.settings.mute.setChecked(x); self.settings.mute.blockSignals(False)
        self.tray.setToolTip(f"{name()} – stumm" if x else f"{name()} – sag „Hey {name()}“")

    def name_changed(self):
        self.tray.setToolTip(f"{name()} – sag „Hey {name()}“")
        self.open_act.setText(f"{name()} öffnen")
        self.brain.refresh_wake()
        if self.settings:
            self.settings.setWindowTitle(f"{name()} · Einstellungen")

    def quit(self):
        self.brain.running = False
        self.tray.hide()
        QApplication.quit()


PORT = 47653


def single_instance():
    """Nur eine Via gleichzeitig: eine schon laufende (neuere) Via wird beendet, dann übernehmen wir."""
    import socket
    try:
        c = socket.create_connection(("127.0.0.1", PORT), timeout=1.0)
        c.sendall(b"quit"); c.close()
        time.sleep(2.0)
    except OSError:
        pass
    srv = socket.socket()
    for _ in range(12):
        try:
            srv.bind(("127.0.0.1", PORT)); srv.listen(2)
            return srv
        except OSError:
            time.sleep(0.5)
    return None


def main():
    srv = single_instance()
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    f = QFont(); f.setFamilies(["Inter", "Segoe UI", "SF Pro Display", "Helvetica Neue", "Noto Sans"])
    app.setFont(f)
    via = ViaApp()   # noqa: F841 (Referenz halten)
    if srv is not None:
        def listen():
            while True:
                try:
                    conn, _ = srv.accept()
                    if conn.recv(16).startswith(b"quit"):
                        via.quitRequest.emit()
                    conn.close()
                except Exception:
                    return
        threading.Thread(target=listen, daemon=True).start()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
