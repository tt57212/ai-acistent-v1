"""
trainer.py - der Trainings-Kern für Vias eigenes Gehirn (reines NumPy, ohne Qt).
Wird von train.py (Kommandozeile) und trainer_app.py (Trainings-App) benutzt.
"""
import math
import re
import time
from pathlib import Path

import numpy as np

import via_ai as ai

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
MODEL = BASE / "models" / "via_gpt.npz"
BASE_CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZäöüÄÖÜß0123456789 \n.,!?:;-'()%/+="

# Größen: (Dimension, Schichten, Köpfe, Lernrate, Beschreibung)
PRESETS = {
    "klein":  dict(D=128, L=4, H=4, lr=3.0e-3, info="0,9 Mio. Parameter · schnell · gut zum Ausprobieren"),
    "mittel": dict(D=192, L=6, H=6, lr=2.0e-3, info="3 Mio. Parameter · merklich klüger · ca. 3x langsamer"),
    "groß":   dict(D=256, L=8, H=8, lr=1.5e-3, info="7 Mio. Parameter · am klügsten · für starke PCs / lange Läufe"),
}
TEST_PROMPTS = ["wie geht es dir", "was ist die hauptstadt von frankreich", "ich habe hunger", "erzähl mir einen witz"]


def parse_examples(path):
    """Liest Beispiele im Format 'Du: ...' / 'Via: ...' (durch Leerzeile getrennt)."""
    if not path.exists():
        return []
    raw = [l for l in path.read_text(encoding="utf-8").splitlines() if not l.startswith("#")]
    out = []
    for block in re.split(r"\n\s*\n", "\n".join(raw)):
        lines = []
        for l in block.strip().splitlines():
            l = l.strip()
            if l.startswith("Du:"):
                lines.append("Du: " + ai.norm_user(l[3:]) + "\n")
            elif l.startswith("Via:"):
                lines.append("Via: " + l[4:].strip() + "\n")
        if len(lines) >= 2:
            out.append("".join(lines))
    return out


def add_example(du, via):
    """Fügt ein eigenes Beispiel hinzu (landet in data/eigene_daten.txt)."""
    DATA.mkdir(exist_ok=True)
    f = DATA / "eigene_daten.txt"
    with open(f, "a", encoding="utf-8") as fh:
        fh.write(f"\nDu: {du.strip()}\nVia: {via.strip()}\n")


def load_text(log=print):
    text = (DATA / "train.txt").read_text(encoding="utf-8")
    extra = parse_examples(DATA / "eigene_daten.txt")
    if extra:
        log(f"{len(extra)} eigene Beispiele (werden 25-fach gewichtet)")
        text += "\n" + "\n".join(extra * 25) + "\n"
    return text


def build_arrays(text, tok):
    text = "".join(c for c in text if c in set(tok.chars))
    ids, offs = tok.encode_offsets(text)
    offs = np.array(offs, dtype=np.int64)
    cmask = np.zeros(len(text), dtype=np.float32)
    for m in re.finditer(r"Via:( .*?)\n", text):          # Antwort inkl. führendem Leerzeichen und Zeilenende
        cmask[m.start(1):m.end()] = 1.0
    cstarts = np.array([0] + [m.end() for m in re.finditer(r"\n\n", text)], dtype=np.int64)
    return (np.array(ids, dtype=np.int32), cmask[offs] if len(offs) else cmask,
            np.unique(np.searchsorted(offs, cstarts)))


def get_batch(ids, mask, starts, B, T, rng):
    x = np.zeros((B, T), np.int32)
    y = np.zeros((B, T), np.int32)
    w = np.zeros((B, T), np.float32)
    for b in range(B):
        for _ in range(50):
            s = int(starts[rng.integers(len(starts))])
            if s + T + 1 <= len(ids):
                break
        x[b], y[b], w[b] = ids[s:s + T], ids[s + 1:s + T + 1], mask[s + 1:s + T + 1]
    return x, y, w


def prompt_for(tok, q):
    return f"Du: {ai.norm_user(q)}\nVia:" + (" " if tok.kind == "char" else "")


def sample_answers(path, prompts=TEST_PROMPTS, temp=0.5):
    g = ai.Generator(str(path))
    res = []
    for q in prompts:
        out = "".join(g.stream_chars(prompt_for(g.tok, q), max_new=140 if g.tok.kind == "char" else 60,
                                     temp=temp, top_k=8)).strip()
        res.append((q, out))
    return res


class Trainer:
    def __init__(self, log=print):
        self.log = log
        self.params = self.cfg = self.tok = self.opt = None
        self.step = 0
        self.ema = None

    # ---- Vorbereiten
    def prepare(self, preset="klein", ctx=96, merges=1200, resume=False, seed=1):
        text = load_text(self.log)
        ckpt = MODEL.with_suffix(".ckpt.npz")
        if resume and MODEL.exists():
            self.params, self.cfg, self.tok = ai.load_model(MODEL)
            self.log(f"Setze fort: {self.tok.kind}-Modell, {ai.count_params(self.params)/1e6:.2f} Mio. Parameter")
        else:
            p = PRESETS[preset]
            chars = sorted(set(text) | set(BASE_CHARS))
            self.log(f"Lerne den Tokenizer (BPE, {merges} Verschmelzungen) …")
            self.tok = ai.train_bpe(text, merges, chars)
            self.cfg = dict(V=self.tok.size, T=ctx, D=p["D"], L=p["L"], H=p["H"], lr=p["lr"])
            self.params = ai.init_params(self.cfg, seed=seed)
        self.ids, self.mask, self.starts = build_arrays(text, self.tok)
        self.opt = ai.Adam(self.params)
        self.step = 0
        if resume and ckpt.exists() and MODEL.exists():
            z = np.load(ckpt)
            if all(("m_" + k) in z.files for k in self.opt.m):
                self.opt.t = int(z["t"])
                for k in self.opt.m:
                    self.opt.m[k], self.opt.v[k] = z["m_" + k], z["v_" + k]
                self.step = int(z["step"])
        self.log(f"Daten: {len(self.ids)/1000:.0f}k Tokens · Vokabular {self.tok.size} · "
                 f"{ai.count_params(self.params)/1e6:.2f} Mio. Parameter · Schritt {self.step}")

    def save(self):
        self.cfg["step"] = self.step
        if self.ema is not None:
            self.cfg["loss"] = round(float(self.ema), 3)
        MODEL.parent.mkdir(exist_ok=True)
        ai.save_model(MODEL, self.params, self.cfg, self.tok)
        d = {"step": np.array(self.step), "t": np.array(self.opt.t)}
        d.update({"m_" + k: v for k, v in self.opt.m.items()})
        d.update({"v_" + k: v for k, v in self.opt.v.items()})
        np.savez(MODEL.with_suffix(".ckpt.npz"), **d)

    # ---- Trainieren
    def run(self, total_steps, batch=24, lr=None, on_step=None, should_stop=lambda: False,
            sample_every=500, on_sample=None):
        cfg, T = self.cfg, self.cfg["T"]
        lr = lr or cfg.get("lr", 2.5e-3)
        rng = np.random.default_rng(self.step + 7)
        t0, s0, warm = time.time(), self.step, 60
        while self.step < total_steps and not should_stop():
            step = self.step + 1
            cur = lr * min(1.0, step / warm)
            if step > warm:
                prog = min(1.0, (step - warm) / max(1, total_steps - warm))
                cur = lr * (0.08 + 0.92 * 0.5 * (1 + math.cos(math.pi * prog)))
            x, y, w = get_batch(self.ids, self.mask, self.starts, batch, T, rng)
            logits, cache = ai.forward(self.params, cfg, x)
            loss, dl = ai.loss_and_grad_logits(logits, y, w)
            grads = ai.backward(self.params, cfg, cache, dl)
            self.opt.step(self.params, grads, cur)
            self.step = step
            self.ema = loss if self.ema is None else 0.95 * self.ema + 0.05 * loss
            sps = (self.step - s0) / max(1e-9, time.time() - t0)
            if on_step and (step % 5 == 0 or step == 1):
                on_step(step, total_steps, float(self.ema), cur, sps)
            if step % 50 == 0:
                self.save()
            if on_sample and (step % sample_every == 0):
                self.save()
                on_sample(step, sample_answers(MODEL))
        self.save()
