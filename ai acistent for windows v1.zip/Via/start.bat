@echo off
chcp 65001 >nul
title Via
cd /d "%~dp0"

rem Alte, noch laufende Via-Instanzen beenden (sonst hören mehrere gleichzeitig zu)
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -match 'venv\\Scripts\\pythonw?\.exe' -and $_.CommandLine -match 'main\.py|trainer_app\.py' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }" >nul 2>nul

set PY=
for %%V in (3.12 3.11 3.10) do (
    if not defined PY (
        py -%%V --version >nul 2>nul && set PY=py -%%V
    )
)
if not defined PY (
    python --version >nul 2>nul && set PY=python
)
if not defined PY goto nopython

if not exist venv\Scripts\python.exe (
    echo Erstelle virtuelle Umgebung...
    %PY% -m venv venv
    if errorlevel 1 goto fail
)

if not exist venv\.installed (
    echo Installiere Pakete, das dauert einmalig ein paar Minuten...
    venv\Scripts\python.exe -m pip install --upgrade pip
    venv\Scripts\python.exe -m pip install -r requirements.txt
    if errorlevel 1 goto fail
    echo ok> venv\.installed
)

set NEED=0
if not exist models\de_DE-thorsten-high.onnx set NEED=1
if not exist models\vosk-model-small-de-0.15 set NEED=1
if not exist models\whisper set NEED=1
if "%NEED%"=="1" (
    echo Lade Sprachmodelle herunter, einmalig ca. 700 MB...
    venv\Scripts\python.exe setup_models.py
    if errorlevel 1 goto fail
)

start "" venv\Scripts\pythonw.exe main.py
exit /b 0

:nopython
echo Python wurde nicht gefunden.
echo Bitte Python 3.12 installieren: https://www.python.org/downloads/
echo Wichtig: Haken bei "Add python.exe to PATH" setzen.
start https://www.python.org/downloads/
pause
exit /b 1

:fail
echo.
echo Es ist ein Fehler aufgetreten. Siehe Meldungen oben.
pause
exit /b 1
