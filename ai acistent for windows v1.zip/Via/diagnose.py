"""Audio-Diagnose: prüft Stimme, Mikrofon und Spracherkennung und zeigt, was genau schlecht ist."""
import os, sys, time, subprocess, json
os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")
from pathlib import Path
import numpy as np
import sounddevice as sd
import speech

BASE = Path(__file__).resolve().parent
M = BASE / "models"
print("=" * 60, "\nVIA AUDIO-DIAGNOSE\n" + "=" * 60)

# 1) laufende Instanzen
try:
    out = subprocess.run(["powershell", "-NoProfile", "-Command",
        "(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'main\\.py' -and $_.Name -match 'python' }).Count"],
        capture_output=True, text=True).stdout.strip()
    print(f"\n[1] Laufende Via-Programme: {out or '0'}  (soll 0 sein, solange du diesen Test machst - sonst beenden.bat starten)")
except Exception:
    pass

# 2) Geräte
print("\n[2] Standard-Mikrofon :", sd.query_devices(kind="input")["name"])
print("    Standard-Lautsprecher:", sd.query_devices(kind="output")["name"])

# 3) Stimme
print("\n[3] Stimme (Piper) ...")
try:
    cfg = {"speak": True, "volume": 0.9, "speed": 1.0}
    sp = speech.Speaker(cfg)
    t = time.time()
    while sp.voice is None and sp.error is None and time.time() - t < 60:
        time.sleep(0.2)
    if sp.error:
        print("    FEHLER:", sp.error)
    else:
        txt = "Hallo, ich bin Via. Heute ist Sonntag, der fünfundzwanzigste Oktober. Es ist 20 Uhr 28 und draußen sind es 8 Grad."
        t0 = time.time(); data, sr = sp._synth(speech.split_sentences(speech.speakable(txt))[0]); dt = time.time() - t0
        print(f"    Erster Satz berechnet in {dt:.2f} s (Abtastrate {sr} Hz, Länge {len(data)/sr:.1f} s)")
        print("    Gesprochener Text:", speech.speakable(txt))
        sp.say(txt)
        while sp.pending:
            time.sleep(0.2)
        print("    -> Hast du die Stimme klar gehört? Wenn nicht: Einstellungen > Stimme > andere Stimme / Ausgabegerät.")
except Exception as e:
    print("    FEHLER:", e)

# 4) Mikrofon
print("\n[4] Mikrofon: sprich in 2 Sekunden einen Satz, z. B. 'Hey Via, stell einen Timer auf fünf Minuten' ...")
time.sleep(2)
print("    Aufnahme läuft (5 Sekunden) ...")
rec = sd.rec(5 * 16000, samplerate=16000, channels=1, dtype="int16"); sd.wait()
a = rec[:, 0].astype(np.float32)
blocks = [float(np.sqrt(np.mean(a[i:i + 1600] ** 2))) for i in range(0, len(a) - 1600, 1600)]
print(f"    Lautstärke: leise={min(blocks):.0f}  laut={max(blocks):.0f}  (Sprache sollte deutlich über 300 liegen)")
if max(blocks) < 250:
    print("    PROBLEM: Mikrofon zu leise -> in Windows lauter stellen oder ein anderes Mikrofon wählen.")
audio = rec.tobytes()

# 5) Erkennung
print("\n[5] Erkennung ...")
try:
    from vosk import Model, KaldiRecognizer, SetLogLevel
    SetLogLevel(-1)
    r = KaldiRecognizer(Model(str(M / "vosk-model-small-de-0.15")), 16000)
    r.AcceptWaveform(audio)
    print("    Vosk   :", json.loads(r.FinalResult()).get("text", ""))
except Exception as e:
    print("    Vosk Fehler:", e)
try:
    w = speech.Whisper({"stt": "whisper-small"}); w._load("small")
    if w.error:
        print("    Whisper Fehler:", w.error)
    else:
        t0 = time.time(); txt = w.transcribe(audio, "Hey Via, stelle einen Timer auf fünf Minuten.")
        print(f"    Whisper: {txt}   ({time.time() - t0:.1f} s)")
except Exception as e:
    print("    Whisper Fehler:", e)
print("\nFertig. Schick mir diese Ausgabe, dann sehe ich genau, was schlecht ist.")
