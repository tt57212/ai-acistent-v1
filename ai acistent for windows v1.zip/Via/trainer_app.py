#!/usr/bin/env python3
"""
Via Trainings-App - bringe deiner eigenen KI Neues bei.

  Training : Größe wählen, Start drücken, live zusehen (Verlustkurve + Beispielantworten)
  Daten    : eigene Frage/Antwort-Beispiele hinzufügen, Trainingsdaten neu erzeugen
  Gespräche: was Via im Alltag nicht wusste - korrigiere die Antwort, sie lernt daraus
  Testen   : sprich direkt mit dem aktuellen Gehirn
"""
import re
import subprocess
import sys
import threading
import time
from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal, QRectF, QPointF, QTimer
from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QHBoxLayout, QLabel, QLineEdit, QListWidget,
                               QMainWindow, QMessageBox, QPlainTextEdit, QProgressBar, QPushButton, QSpinBox,
                               QTabWidget, QVBoxLayout, QWidget)

import gemini
import llmapi
import trainer as tr
import via_ai as ai

BASE = Path(__file__).resolve().parent
CHATLOG = tr.DATA / "gespraeche.txt"

QSS = """
QMainWindow,QWidget{background:#12152b;color:#e9ecff;font-size:13px;}
QTabWidget::pane{border:1px solid rgba(255,255,255,30);border-radius:10px;top:-1px;}
QTabBar::tab{background:transparent;color:rgba(255,255,255,140);padding:9px 18px;border:none;font-weight:600;}
QTabBar::tab:selected{color:white;border-bottom:2px solid #6c7bff;}
QLabel#muted{color:rgba(255,255,255,125);}
QLabel#big{font-size:22px;font-weight:700;}
QPushButton{background:rgba(255,255,255,20);color:#eef0ff;border:none;border-radius:10px;padding:8px 16px;}
QPushButton:hover{background:rgba(255,255,255,40);}
QPushButton:disabled{color:rgba(255,255,255,70);}
QPushButton#go{background:#4f5fe8;font-weight:700;}
QPushButton#go:hover{background:#6372ff;}
QPushButton#stop{background:#c0415a;font-weight:700;}
QLineEdit,QSpinBox,QComboBox,QPlainTextEdit,QListWidget{background:rgba(255,255,255,14);color:#eef0ff;
  border:1px solid rgba(255,255,255,30);border-radius:9px;padding:6px 9px;selection-background-color:#6c7bff;}
QComboBox QAbstractItemView{background:#171a33;color:#e9ecff;selection-background-color:#6c7bff;}
QProgressBar{background:rgba(255,255,255,18);border:none;border-radius:6px;height:12px;text-align:center;color:white;}
QProgressBar::chunk{background:#2ee6c8;border-radius:6px;}
QListWidget::item{padding:6px;border-radius:6px;}
QListWidget::item:selected{background:rgba(108,123,255,120);}
"""


class Chart(QWidget):
    """Live-Verlustkurve."""

    def __init__(self):
        super().__init__()
        self.pts = []
        self.setMinimumHeight(190)

    def add(self, step, loss):
        self.pts.append((step, loss))
        if len(self.pts) > 4000:
            self.pts = self.pts[::2]
        self.update()

    def clear(self):
        self.pts = []
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(48, 12, self.width() - 62, self.height() - 34)
        p.setPen(QPen(QColor(255, 255, 255, 28), 1))
        for i in range(5):
            y = r.top() + r.height() * i / 4
            p.drawLine(QPointF(r.left(), y), QPointF(r.right(), y))
        if len(self.pts) < 2:
            p.setPen(QColor(255, 255, 255, 110))
            p.drawText(r, Qt.AlignCenter, "Die Verlustkurve erscheint, sobald das Training läuft.")
            return
        xs = [a for a, _ in self.pts]
        ys = [b for _, b in self.pts]
        x0, x1 = xs[0], max(xs[-1], xs[0] + 1)
        y0, y1 = max(0.0, min(ys) * 0.9), max(ys) * 1.05
        path = QPainterPath()
        for i, (a, b) in enumerate(self.pts):
            pt = QPointF(r.left() + (a - x0) / (x1 - x0) * r.width(),
                         r.bottom() - (b - y0) / max(1e-9, y1 - y0) * r.height())
            path.moveTo(pt) if i == 0 else path.lineTo(pt)
        p.setPen(QPen(QColor("#2ee6c8"), 2))
        p.drawPath(path)
        p.setPen(QColor(255, 255, 255, 130))
        for i in range(5):
            v = y1 - (y1 - y0) * i / 4
            p.drawText(QRectF(0, r.top() + r.height() * i / 4 - 9, 44, 18), Qt.AlignRight | Qt.AlignVCenter, f"{v:.2f}")
        p.drawText(QRectF(r.left(), r.bottom() + 4, r.width(), 18), Qt.AlignLeft, f"Schritt {x0}")
        p.drawText(QRectF(r.left(), r.bottom() + 4, r.width(), 18), Qt.AlignRight, f"Schritt {x1}")


class Worker(QThread):
    stepSig = Signal(int, int, float, float, float)
    sampleSig = Signal(int, object)
    logSig = Signal(str)
    finishedSig = Signal(str)

    def __init__(self, opts):
        super().__init__()
        self.o = opts
        self._stop = False

    def stop(self):
        self._stop = True

    def run(self):
        try:
            t = tr.Trainer(log=self.logSig.emit)
            o = self.o
            t.prepare(o["size"], o["ctx"], o["merges"], o["resume"])
            self.logSig.emit(f"Los geht's: Ziel {o['steps']} Schritte.")
            t.run(o["steps"], o["batch"], None, lambda *a: self.stepSig.emit(*a), lambda: self._stop,
                  sample_every=o["sample"], on_sample=lambda s, r: self.sampleSig.emit(s, r))
            self.finishedSig.emit("Training beendet. Stand gespeichert." if not self._stop
                                  else "Pausiert. Stand gespeichert - mit „Weitertrainieren“ geht es genau hier weiter.")
        except Exception as e:
            self.finishedSig.emit(f"Fehler: {e}")


class App(QMainWindow):
    genDone = Signal(object)

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Via · Trainings-App")
        self.resize(900, 720)
        self.worker = None
        self.gen = None
        tabs = QTabWidget()
        self.setCentralWidget(tabs)
        tabs.addTab(self.tab_train(), "Training")
        tabs.addTab(self.tab_data(), "Daten")
        tabs.addTab(self.tab_chats(), "Gespräche")
        tabs.addTab(self.tab_test(), "Testen")
        self.genDone.connect(self.on_gen_done)
        self.refresh_status()

    # ───────────── Training
    def tab_train(self):
        w = QWidget(); v = QVBoxLayout(w); v.setSpacing(10)
        self.status = QLabel(""); self.status.setObjectName("muted"); v.addWidget(self.status)
        row = QHBoxLayout()
        self.size = QComboBox()
        for k, p in tr.PRESETS.items():
            self.size.addItem(f"{k.capitalize()} – {p['info']}", k)
        self.steps = QSpinBox(); self.steps.setRange(100, 500000); self.steps.setValue(6000); self.steps.setSingleStep(500)
        self.batch = QSpinBox(); self.batch.setRange(4, 128); self.batch.setValue(24)
        row.addWidget(QLabel("Größe")); row.addWidget(self.size, 1)
        row.addWidget(QLabel("Schritte bis")); row.addWidget(self.steps)
        row.addWidget(QLabel("Batch")); row.addWidget(self.batch)
        v.addLayout(row)
        self.fresh = QCheckBox("Ganz neu anfangen (löscht das bisherige Gehirn)")
        v.addWidget(self.fresh)
        row = QHBoxLayout()
        self.b_go = QPushButton("▶  Training starten / weitertrainieren"); self.b_go.setObjectName("go")
        self.b_stop = QPushButton("⏸  Stopp & speichern"); self.b_stop.setObjectName("stop"); self.b_stop.setEnabled(False)
        self.b_go.clicked.connect(self.start); self.b_stop.clicked.connect(self.stop)
        row.addWidget(self.b_go, 2); row.addWidget(self.b_stop, 1)
        v.addLayout(row)
        self.bar = QProgressBar(); v.addWidget(self.bar)
        self.stats = QLabel("–"); self.stats.setObjectName("big"); v.addWidget(self.stats)
        self.chart = Chart(); v.addWidget(self.chart, 2)
        v.addWidget(QLabel("Beispielantworten (aktualisieren sich während des Trainings):"))
        self.samples = QPlainTextEdit(); self.samples.setReadOnly(True); v.addWidget(self.samples, 2)
        self.log = QPlainTextEdit(); self.log.setReadOnly(True); self.log.setMaximumHeight(70); v.addWidget(self.log)
        return w

    def refresh_status(self):
        if tr.MODEL.exists():
            try:
                _, cfg, tok = ai.load_model(tr.MODEL)
                self.status.setText(f"Aktuelles Gehirn: {tok.kind.upper()}-Tokenizer · Schritt {cfg.get('step', '?')} · "
                                    f"Verlust {cfg.get('loss', '?')} · Via nutzt es frei, sobald der Verlust unter "
                                    f"{0.30 if tok.kind == 'char' else 1.20} liegt")
                self.gen = None
            except Exception as e:
                self.status.setText(f"Gehirn nicht lesbar: {e}")
        else:
            self.status.setText("Noch kein Gehirn vorhanden – Start drückt ein neues.")
        n = len(tr.parse_examples(tr.DATA / "eigene_daten.txt"))
        if hasattr(self, "data_info"):
            self.data_info.setText(f"{n} eigene Beispiele gespeichert · Trainingsdaten: "
                                   f"{(tr.DATA / 'train.txt').stat().st_size // 1000 if (tr.DATA / 'train.txt').exists() else 0} KB")

    def start(self):
        if not (tr.DATA / "train.txt").exists():
            QMessageBox.information(self, "Daten fehlen", "Bitte zuerst im Tab „Daten“ die Trainingsdaten erzeugen.")
            return
        resume = tr.MODEL.exists() and not self.fresh.isChecked()
        if not resume and tr.MODEL.exists():
            tr.MODEL.rename(tr.MODEL.with_suffix(".backup.npz"))
            self.log.appendPlainText("Altes Gehirn als via_gpt.backup.npz gesichert.")
        self.chart.clear()
        o = dict(size=self.size.currentData(), steps=self.steps.value(), batch=self.batch.value(), ctx=96,
                 merges=1200, resume=resume, sample=500)
        self.worker = Worker(o)
        self.worker.stepSig.connect(self.on_step); self.worker.sampleSig.connect(self.on_sample)
        self.worker.logSig.connect(self.log.appendPlainText); self.worker.finishedSig.connect(self.on_done)
        self.b_go.setEnabled(False); self.b_stop.setEnabled(True)
        self.worker.start()

    def stop(self):
        if self.worker:
            self.worker.stop(); self.b_stop.setEnabled(False)
            self.log.appendPlainText("Stoppe nach dem aktuellen Schritt …")

    def on_step(self, step, total, loss, lr, sps):
        self.bar.setMaximum(total); self.bar.setValue(step)
        rest = (total - step) / max(sps, 1e-9)
        self.stats.setText(f"Schritt {step}/{total}  ·  Verlust {loss:.3f}  ·  {sps:.2f} Schritte/s  ·  noch ca. "
                           f"{int(rest // 3600)} h {int(rest % 3600 // 60)} min")
        self.chart.add(step, loss)

    def on_sample(self, step, res):
        self.samples.setPlainText(f"— nach Schritt {step} —\n" + "\n".join(f"Du: {q}\nVia: {a}\n" for q, a in res))

    def on_done(self, msg):
        self.log.appendPlainText(msg)
        self.b_go.setEnabled(True); self.b_stop.setEnabled(False)
        self.refresh_status()

    # ───────────── Daten
    def tab_data(self):
        w = QWidget(); v = QVBoxLayout(w); v.setSpacing(10)
        self.data_info = QLabel(""); self.data_info.setObjectName("muted"); v.addWidget(self.data_info)
        b = QPushButton("Trainingsdaten neu erzeugen (make_data.py)"); b.clicked.connect(self.make_data); v.addWidget(b)
        v.addWidget(QLabel("Wissen übernehmen: ein KI-Modell (Ollama lokal oder Gemini, wie in Via eingestellt) schreibt Beispiele, DEINE KI lernt sie:"))
        row = QHBoxLayout()
        self.g_topic = QLineEdit(); self.g_topic.setPlaceholderText("Thema, z. B. Kochen, Technik, Smalltalk, Allgemeinwissen")
        self.g_n = QSpinBox(); self.g_n.setRange(10, 80); self.g_n.setValue(40); self.g_n.setSuffix(" Beispiele")
        self.g_btn = QPushButton("✨ Erzeugen"); self.g_btn.clicked.connect(self.gen_examples)
        row.addWidget(self.g_topic, 1); row.addWidget(self.g_n); row.addWidget(self.g_btn)
        v.addLayout(row)
        v.addWidget(QLabel("Eigenes Beispiel hinzufügen – so soll Via antworten:"))
        self.f_du = QLineEdit(); self.f_du.setPlaceholderText("Du sagst … (z. B. wie heißt dein hund)")
        self.f_via = QLineEdit(); self.f_via.setPlaceholderText("Via antwortet … (z. B. Ich habe keinen Hund, aber ich mag Hunde.)")
        add = QPushButton("＋ Beispiel speichern"); add.setObjectName("go"); add.clicked.connect(self.add_example)
        v.addWidget(self.f_du); v.addWidget(self.f_via); v.addWidget(add)
        v.addWidget(QLabel("Alle eigenen Beispiele (frei bearbeitbar, Du-Zeile klein und ohne Satzzeichen):"))
        self.own = QPlainTextEdit(); v.addWidget(self.own, 1)
        sv = QPushButton("Änderungen speichern"); sv.clicked.connect(self.save_own); v.addWidget(sv)
        self.load_own()
        return w

    def load_own(self):
        f = tr.DATA / "eigene_daten.txt"
        self.own.setPlainText(f.read_text(encoding="utf-8") if f.exists() else "")

    def save_own(self):
        tr.DATA.mkdir(exist_ok=True)
        (tr.DATA / "eigene_daten.txt").write_text(self.own.toPlainText(), encoding="utf-8")
        self.refresh_status()

    def add_example(self):
        if self.f_du.text().strip() and self.f_via.text().strip():
            tr.add_example(self.f_du.text(), self.f_via.text())
            self.f_du.clear(); self.f_via.clear()
            self.load_own(); self.refresh_status()

    def gen_examples(self):
        import json
        try:
            cfg = json.loads((BASE / "config.json").read_text(encoding="utf-8"))
        except Exception:
            cfg = {}
        topic, n = self.g_topic.text().strip() or "Alltag und Smalltalk", self.g_n.value()
        if not llmapi.ready(cfg):
            QMessageBox.information(self, "KI-Modell", "Kein Gemini-Schlüssel gefunden. Trage ihn in Via unter Einstellungen > Gehirn "
                                                       "ein, oder stelle dort Ollama (lokal) ein."); return
        self.g_btn.setEnabled(False); self.g_btn.setText("KI schreibt …")
        prompt = (f"Schreibe {n} abwechslungsreiche, sachlich KORREKTE deutsche Dialog-Beispiele für einen Sprachassistenten "
                  f"namens Via zum Thema: {topic}.\nFormat GENAU so, Beispiele durch eine Leerzeile getrennt, ohne Nummerierung, "
                  "ohne Markdown:\nDu: <Frage oder Aussage, klein geschrieben, ohne Satzzeichen, wie gesprochen>\n"
                  "Via: <freundliche, kurze gesprochene Antwort, höchstens 110 Zeichen>\n"
                  "Wenn etwas nicht sicher bekannt ist, antworte ehrlich: Das weiß ich leider nicht.")

        def work():
            try:
                self.genDone.emit(llmapi.generate(cfg, "", [("user", prompt)], 0.9, 1200, max_tokens=4000))
            except Exception as e:
                self.genDone.emit(e)
        threading.Thread(target=work, daemon=True).start()

    def on_gen_done(self, res):
        self.g_btn.setEnabled(True); self.g_btn.setText("✨ Erzeugen")
        if isinstance(res, Exception):
            QMessageBox.warning(self, "Gemini", str(res)); return
        k = 0
        for block in re.split(r"\n\s*\n", res):
            m = re.search(r"Du:\s*(.+)\nVia:\s*(.+)", block)
            if m and len(m.group(2)) <= 125:
                tr.add_example(m.group(1), m.group(2)); k += 1
        self.load_own(); self.refresh_status()
        QMessageBox.information(self, "Gemini", f"{k} Beispiele wurden zu deinen eigenen Daten hinzugefügt.\n"
                                                "Prüfe sie unten und trainiere dann weiter - so lernt DEINE KI daraus.")

    def make_data(self):
        r = subprocess.run([sys.executable, str(BASE / "make_data.py")], capture_output=True, text=True, cwd=str(BASE))
        self.refresh_status()
        QMessageBox.information(self, "Trainingsdaten", (r.stdout or r.stderr).strip()[:400])

    # ───────────── Gespräche
    def tab_chats(self):
        w = QWidget(); v = QVBoxLayout(w); v.setSpacing(8)
        info = QLabel("Hier landen Sätze, bei denen Via im Alltag nur geraten oder nichts gewusst hat. "
                      "Schreibe die richtige Antwort, speichere sie – beim nächsten Training lernt Via sie.")
        info.setWordWrap(True); info.setObjectName("muted"); v.addWidget(info)
        self.chat_list = QListWidget(); self.chat_list.currentRowChanged.connect(self.pick_chat); v.addWidget(self.chat_list, 1)
        self.c_via = QLineEdit(); self.c_via.setPlaceholderText("So hätte Via antworten sollen …"); v.addWidget(self.c_via)
        row = QHBoxLayout()
        ok = QPushButton("✓ Als Beispiel speichern"); ok.setObjectName("go"); ok.clicked.connect(lambda: self.chat_action(True))
        no = QPushButton("✕ Verwerfen"); no.clicked.connect(lambda: self.chat_action(False))
        rl = QPushButton("↻ Neu laden"); rl.clicked.connect(self.load_chats)
        for b in (ok, no, rl):
            row.addWidget(b)
        v.addLayout(row)
        self.chats = []
        self.load_chats()
        return w

    def load_chats(self):
        self.chats = []
        if CHATLOG.exists():
            for block in re.split(r"\n\s*\n", CHATLOG.read_text(encoding="utf-8")):
                m = re.match(r"Du: (.*)\nVia: (.*)", block.strip())
                if m:
                    self.chats.append((m.group(1), m.group(2)))
        self.chat_list.clear()
        for du, via in self.chats:
            self.chat_list.addItem(f"Du: {du}    →    Via: {via[:70]}")

    def pick_chat(self, i):
        if 0 <= i < len(self.chats):
            self.c_via.setText(self.chats[i][1])

    def chat_action(self, save):
        i = self.chat_list.currentRow()
        if i < 0:
            return
        du, _ = self.chats[i]
        if save and self.c_via.text().strip():
            tr.add_example(du, self.c_via.text())
            self.load_own(); self.refresh_status()
        del self.chats[i]
        CHATLOG.write_text("".join(f"Du: {a}\nVia: {b}\n\n" for a, b in self.chats), encoding="utf-8")
        self.load_chats(); self.c_via.clear()

    # ───────────── Testen
    def tab_test(self):
        w = QWidget(); v = QVBoxLayout(w); v.setSpacing(8)
        self.t_out = QPlainTextEdit(); self.t_out.setReadOnly(True); v.addWidget(self.t_out, 1)
        row = QHBoxLayout()
        self.t_in = QLineEdit(); self.t_in.setPlaceholderText("Schreib etwas zu Via … (Enter)")
        self.t_in.returnPressed.connect(self.ask)
        b = QPushButton("Senden"); b.setObjectName("go"); b.clicked.connect(self.ask)
        row.addWidget(self.t_in, 1); row.addWidget(b)
        v.addLayout(row)
        return w

    def ask(self):
        q = self.t_in.text().strip()
        if not q:
            return
        self.t_in.clear()
        try:
            if self.gen is None:
                self.gen = ai.Generator(str(tr.MODEL))
            out = "".join(self.gen.stream_chars(tr.prompt_for(self.gen.tok, q), max_new=140 if self.gen.tok.kind == "char" else 60,
                                                temp=0.5, top_k=8)).strip()
            self.t_out.appendPlainText(f"Du: {q}\nVia: {out}   (Sicherheit {self.gen.confidence():.2f})\n")
        except Exception as e:
            self.t_out.appendPlainText(f"Kein Gehirn geladen: {e}\n")


def main():
    app = QApplication(sys.argv)
    f = QFont(); f.setFamilies(["Inter", "Segoe UI", "SF Pro Display", "Helvetica Neue", "Noto Sans"])
    app.setFont(f); app.setStyleSheet(QSS)
    w = App(); w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
