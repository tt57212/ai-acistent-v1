#!/usr/bin/env python3
"""
Lädt einmalig die Sprachmodelle: Vosk (Wake-Word), Piper-Stimme und Whisper (genaue Spracherkennung).
Vias Gehirn selbst wird NICHT geladen - das trainierst du mit der Trainings-App (trainer_app.py).
"""
import os, sys, zipfile, urllib.request
os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"
from pathlib import Path

MODELS = Path(__file__).resolve().parent / "models"
MODELS.mkdir(exist_ok=True)

VOSK_URL = "https://alphacephei.com/vosk/models/vosk-model-small-de-0.15.zip"
HF = "https://huggingface.co/rhasspy/piper-voices/resolve/main/de/de_DE/thorsten/high/"
VOICE_FILES = ["de_DE-thorsten-high.onnx", "de_DE-thorsten-high.onnx.json"]


def download(url, dest):
    if dest.exists():
        print("✓ vorhanden:", dest.name); return
    print("↓", dest.name)
    part = dest.with_suffix(dest.suffix + ".part")

    def hook(b, bs, total):
        if total > 0:
            sys.stdout.write(f"\r   {min(100, b * bs * 100 // total)} %"); sys.stdout.flush()
    urllib.request.urlretrieve(url, part, hook)
    part.rename(dest)
    print()


if not (MODELS / "vosk-model-small-de-0.15").exists():
    z = MODELS / "vosk-de.zip"
    download(VOSK_URL, z)
    with zipfile.ZipFile(z) as f:
        f.extractall(MODELS)
    z.unlink()
for f in VOICE_FILES:
    download(HF + f, MODELS / f)

size = "base" if "--base" in sys.argv else "small"
try:
    print(f"↓ Whisper {size} (Spracherkennung, einmalig ca. {'150' if size == 'base' else '470'} MB) …")
    from faster_whisper import WhisperModel
    WhisperModel(size, device="cpu", compute_type="int8", download_root=str(MODELS / "whisper"))
    print("✓ Whisper bereit")
except Exception as e:
    print("WARNUNG: Whisper konnte nicht geladen werden:", e)
    print("Via nutzt dann die einfachere Vosk-Erkennung. start.bat später erneut ausführen.")

print("\nFertig. Starte jetzt:  python main.py   |   Gehirn trainieren:  python trainer_app.py")
