"""
speech.py - Sprechen und Zuhören für Via

  * Piper-Stimme mit Textaufbereitung (Zahlen, Datum, Einheiten werden richtig ausgesprochen),
    satzweise vorberechnet und lückenlos abgespielt
  * Whisper (faster-whisper, offline) für sehr gute Spracherkennung
  * Segmenter: erkennt Anfang und Ende deines Satzes anhand der Lautstärke
"""
import io
import os
import re
import wave
import queue
import threading
import time
import math
from collections import OrderedDict, deque
from pathlib import Path

import numpy as np
import sounddevice as sd

os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")
os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")

BASE = Path(__file__).resolve().parent
MODELS = BASE / "models"
SR_IN = 16000
SR_OUT = 22050


# ───────────────────────────── Audio-Geräte ──────────────────────────────
def list_devices(kind):
    key = "max_input_channels" if kind == "input" else "max_output_channels"
    out = []
    try:
        api = sd.query_devices(kind=kind)["hostapi"]
        for i, d in enumerate(sd.query_devices()):
            if d[key] > 0 and d["hostapi"] == api:
                out.append((i, d["name"]))
    except Exception:
        pass
    return out


def find_device(name, kind):
    if not name:
        return None
    for i, n in list_devices(kind):
        if n == name:
            return i
    return None


# ───────────────────────────── Töne ──────────────────────────────────────
def tone(freqs, dur, vol=0.28):
    t = np.linspace(0, dur, int(SR_OUT * dur), False)
    w = sum(np.sin(2 * np.pi * f * t) for f in freqs) / len(freqs)
    env = np.minimum(1, np.minimum(t / 0.01, (dur - t) / 0.06))
    return (w * env * vol * 32767).astype(np.int16)


def gap(d):
    return np.zeros(int(SR_OUT * d), dtype=np.int16)


CHIME = np.concatenate([tone([880], .07), gap(.02), tone([1320], .11)])
ALARM = np.concatenate([np.concatenate([tone([1046, 1568], .16), gap(.08)] * 3), gap(.25)])


# ───────────────────────────── Deutsch sprechbar machen ──────────────────
ONES = ["null", "eins", "zwei", "drei", "vier", "fünf", "sechs", "sieben", "acht", "neun", "zehn", "elf",
        "zwölf", "dreizehn", "vierzehn", "fünfzehn", "sechzehn", "siebzehn", "achtzehn", "neunzehn"]
TENS = ["", "", "zwanzig", "dreißig", "vierzig", "fünfzig", "sechzig", "siebzig", "achtzig", "neunzig"]
MONTH_RE = "Januar|Februar|März|April|Mai|Juni|Juli|August|September|Oktober|November|Dezember"
EMOJI = re.compile("[\U00010000-\U0010ffff\u2600-\u27bf\ufe0f]")


def _below100(n):
    if n < 20:
        return ONES[n]
    t, o = divmod(n, 10)
    return TENS[t] if o == 0 else ("ein" if o == 1 else ONES[o]) + "und" + TENS[t]


def _below1000(n):
    h, r = divmod(n, 100)
    s = ("ein" if h == 1 else ONES[h]) + "hundert" if h else ""
    if r:
        s += _below100(r)
    return s or "null"


def num2de(n):
    if n < 0:
        return "minus " + num2de(-n)
    if n < 1000:
        return _below1000(n)
    if n < 1_000_000:
        th, r = divmod(n, 1000)
        w = _below1000(th)
        if w.endswith("eins"):
            w = w[:-1]
        s = w + "tausend"
        return s + (_below1000(r) if r else "")
    if n < 1_000_000_000:
        m, r = divmod(n, 1_000_000)
        w = "eine Million" if m == 1 else _below1000(m).replace("eins", "ein") + " Millionen"
        return w + (" " + num2de(r) if r else "")
    return " ".join(num2de(int(c)) for c in str(n))


def ordinal(n):
    special = {1: "erste", 3: "dritte", 7: "siebte", 8: "achte"}
    if n in special:
        return special[n]
    w = num2de(n)
    return w + ("te" if n < 20 else "ste")


ABBR = [(r"\bz\.\s?B\.", "zum Beispiel"), (r"\bd\.\s?h\.", "das heißt"), (r"\bca\.", "circa"),
        (r"\busw\.", "und so weiter"), (r"\bMio\.", "Millionen"), (r"\bMrd\.", "Milliarden"),
        (r"\bz\. ?T\.", "zum Teil"), (r"\bevtl\.", "eventuell"), (r"\bbzw\.", "beziehungsweise")]


def speakable(t):
    t = EMOJI.sub("", t)
    t = re.sub(r"[*_#`>~|]+", "", t)
    for pat, rep in ABBR:
        t = re.sub(pat, rep, t, flags=re.I)
    t = re.sub(rf"\b(\d{{1,2}})\.\s*({MONTH_RE})", lambda m: ordinal(int(m.group(1))) + " " + m.group(2), t)
    t = t.replace("°C", " Grad Celsius").replace("°", " Grad").replace("%", " Prozent")
    t = t.replace("€", " Euro").replace("&", " und ").replace("km/h", " Kilometer pro Stunde")
    t = re.sub(r"(\d{1,2}):(\d{2})\b", r"\1 Uhr \2", t)
    t = re.sub(r"\b(\d{1,3})(?:\.(\d{3}))+\b", lambda m: m.group(0).replace(".", ""), t)
    t = re.sub(r"(?<![\w.])-(?=\d)", "minus ", t)
    t = re.sub(r"(\d+)[,.](\d+)",
               lambda m: num2de(int(m.group(1))) + " Komma " + " ".join(num2de(int(c)) for c in m.group(2)), t)

    UNIT = re.compile(r"\s*(?:Euro|Cent|Meter|Kilometer|Prozent|Grad|Minuten|Sekunden|Stunden|Tage|Jahre|Gramm|Kilogramm|Liter|Millionen|Einwohner|Mal)")

    def number(m):
        s = m.group(0)
        n = int(s)
        if len(s) == 4 and 1100 <= n <= 1999 and not UNIT.match(m.string, m.end()):
            return _below100(n // 100) + "hundert" + (_below100(n % 100) if n % 100 else "")
        return num2de(n)
    t = re.sub(r"\d+", number, t)
    return re.sub(r"\s+", " ", t).strip()


def split_sentences(t):
    parts = [p.strip() for p in re.split(r"(?<=[.!?:;])\s+|\n+", t) if p.strip()]
    out = []
    for p in parts:
        if out and len(out[-1]) < 22:
            out[-1] += " " + p
        else:
            out.append(p)
    return out


# ───────────────────────────── Stimme ────────────────────────────────────
class Speaker:
    """Piper-Stimme. Sätze werden vorberechnet, während der vorige noch gesprochen wird."""

    def __init__(self, cfg):
        self.cfg = cfg
        self.pending = 0
        self.gen = 0
        self.lock = threading.Lock()
        self.inq = queue.Queue()
        self.outq = queue.Queue()
        self.cache = OrderedDict()
        self.voice = None
        self.voice_name = None
        self.error = None
        self._stream = None
        self._stream_key = None
        threading.Thread(target=self._synth_loop, daemon=True).start()
        threading.Thread(target=self._play_loop, daemon=True).start()

    # ---- Zähler (Mikrofon wird stumm, solange pending > 0)
    def _inc(self):
        with self.lock:
            self.pending += 1

    def _dec(self):
        with self.lock:
            self.pending = max(0, self.pending - 1)

    # ---- öffentliche API
    def say(self, text):
        if text and self.cfg.get("speak", True):
            self._inc(); self.inq.put((self.gen, "say", text))

    def sound(self, kind):
        self._inc(); self.inq.put((self.gen, kind, None))

    def stop(self):
        with self.lock:
            self.gen += 1
        try:
            sd.stop()
        except Exception:
            pass

    def reload_voice(self):
        self.inq.put((self.gen, "reload", None))

    @staticmethod
    def available_voices():
        return sorted(p.name for p in MODELS.glob("*.onnx"))

    # ---- Stimme laden
    def _voice_path(self):
        want = self.cfg.get("voice") or "de_DE-thorsten-high.onnx"
        p = MODELS / want
        if p.exists():
            return p
        voices = self.available_voices()
        return MODELS / voices[0] if voices else p

    def _load(self):
        try:
            from piper import PiperVoice
            p = self._voice_path()
            self.voice = PiperVoice.load(str(p))
            self.voice_name = p.name
            self.cache.clear()
            self.error = None
            self._synth("Hallo")
        except Exception as e:
            self.voice = None
            self.error = f"Stimme konnte nicht geladen werden: {e}"
            print(self.error)

    def _synth(self, text):
        ls = round(1.0 / max(0.5, float(self.cfg.get("speed", 1.0))), 2)
        key = (text, ls, self.voice_name)
        if key in self.cache:
            self.cache.move_to_end(key)
            return self.cache[key]
        v = self.voice
        attempts = []
        try:
            from piper import SynthesisConfig
            sc = SynthesisConfig(length_scale=ls, noise_scale=0.6, noise_w_scale=0.75)
            attempts.append(lambda wf: v.synthesize_wav(text, wf, syn_config=sc))
        except Exception:
            pass
        attempts.append(lambda wf: v.synthesize(text, wf, length_scale=ls, noise_scale=0.6, noise_w=0.75))
        attempts.append(lambda wf: v.synthesize_wav(text, wf) if hasattr(v, "synthesize_wav") else v.synthesize(text, wf))
        last = None
        for att in attempts:
            buf = io.BytesIO()
            try:
                with wave.open(buf, "wb") as wf:
                    att(wf)
                buf.seek(0)
                with wave.open(buf, "rb") as wf:
                    sr = wf.getframerate()
                    data = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16)
                if len(data) == 0:
                    continue
                self.cache[key] = (data, sr)
                if len(self.cache) > 80:
                    self.cache.popitem(last=False)
                return data, sr
            except Exception as e:
                last = e
        raise RuntimeError(f"Sprachsynthese fehlgeschlagen: {last}")

    # ---- Thread 1: Text -> Audio
    def _synth_loop(self):
        self._load()
        while True:
            gen, kind, payload = self.inq.get()
            if kind == "reload":
                self._load(); continue
            if gen != self.gen:
                self._dec(); continue
            if kind != "say":
                self.outq.put((gen, "sound", kind)); continue
            try:
                if not self.voice:
                    print("[Via]", payload)
                else:
                    first = True
                    for sent in split_sentences(speakable(payload)):
                        if gen != self.gen:
                            break
                        data, sr = self._synth(sent)
                        self.outq.put((gen, "audio", (data, sr, first)))
                        first = False
            except Exception as e:
                print("TTS-Fehler:", e)
            self.outq.put((gen, "end", None))

    # ---- Thread 2: Audio -> Lautsprecher
    def _open(self, sr):
        dev = find_device(self.cfg.get("output_device"), "output")
        key = (dev, sr)
        if self._stream_key != key:
            if self._stream is not None:
                try:
                    self._stream.stop(); self._stream.close()
                except Exception:
                    pass
            try:
                self._stream = sd.OutputStream(samplerate=sr, channels=1, dtype="int16", device=dev)
            except Exception:
                self._stream = sd.OutputStream(samplerate=sr, channels=1, dtype="int16")
            self._stream.start()
            self._stream_key = key
        return self._stream

    def _write(self, gen, data, sr):
        vol = float(self.cfg.get("volume", 0.9))
        x = data.astype(np.float32) * vol
        data = np.clip(x, -32768, 32767).astype(np.int16)
        st = self._open(sr)
        for i in range(0, len(data), 2048):
            if gen != self.gen:
                return
            st.write(data[i:i + 2048].reshape(-1, 1))

    def _play_loop(self):
        while True:
            gen, kind, payload = self.outq.get()
            try:
                if kind == "audio":
                    data, sr, first = payload
                    if gen == self.gen:
                        if first:      # Pause + Einblenden: verhindert verschluckte erste Silbe
                            pad = np.zeros(int(sr * 0.18), dtype=np.int16)
                            n = min(len(data), int(sr * 0.012))
                            data = data.copy()
                            data[:n] = (data[:n] * np.linspace(0, 1, n)).astype(np.int16)
                            data = np.concatenate([pad, data])
                        self._write(gen, data, sr)
                elif kind == "sound":
                    if gen == self.gen:
                        arr = CHIME if payload == "chime" else ALARM
                        self._write(gen, np.concatenate([np.zeros(int(SR_OUT * 0.12), np.int16), arr]), SR_OUT)
                    self._dec()
                elif kind == "end":
                    if gen == self.gen and self._stream is not None:
                        self._write(gen, np.zeros(int(SR_OUT * 0.12), np.int16), self._stream_key[1])
                    self._dec()
            except Exception as e:
                print("Audio-Fehler:", e)
                if kind in ("sound", "end"):
                    self._dec()


# ───────────────────────────── Spracherkennung (Whisper) ─────────────────
HALLUCINATIONS = ("untertitel", "amara.org", "fürs zuschauen", "für's zuschauen", "vielen dank für ihre aufmerksamkeit",
                  "abonniert", "copyright", "im auftrag des zdf", "swr")


class Whisper:
    def __init__(self, cfg):
        self.cfg = cfg
        self.model = None
        self.size = None
        self.ready = False
        self.loading = False
        self.error = None
        self.lock = threading.Lock()

    def wanted(self):
        s = self.cfg.get("stt", "whisper-small")
        return s.split("-", 1)[1] if s.startswith("whisper-") else None

    def configure(self):
        """Lädt (bei Bedarf neu) das gewählte Whisper-Modell im Hintergrund."""
        size = self.wanted()
        if size is None or (self.size == size and self.ready) or self.loading:
            return
        threading.Thread(target=self._load, args=(size,), daemon=True).start()

    def _load(self, size):
        self.loading = True
        self.ready = False
        try:
            from faster_whisper import WhisperModel
            threads = max(2, (os.cpu_count() or 4) - 1)
            kw = dict(device="cpu", compute_type="int8", cpu_threads=threads, download_root=str(MODELS / "whisper"))
            try:                      # zuerst rein lokal (schnell, kein Internet nötig)
                self.model = WhisperModel(size, local_files_only=True, **kw)
            except Exception:
                self.model = WhisperModel(size, **kw)
            self.model.transcribe(np.zeros(SR_IN, dtype=np.float32), language="de", beam_size=1)
            self.size, self.ready, self.error = size, True, None
        except Exception as e:
            self.error = str(e)
            print("Whisper nicht verfügbar:", e)
        finally:
            self.loading = False

    def transcribe(self, audio_bytes, prompt=""):
        x = np.frombuffer(audio_bytes, dtype=np.int16).astype(np.float32) / 32768.0
        with self.lock:
            segs, _ = self.model.transcribe(
                x, language="de", beam_size=1, temperature=0.0, vad_filter=True,
                vad_parameters=dict(min_silence_duration_ms=350, speech_pad_ms=200),
                condition_on_previous_text=False, initial_prompt=prompt or None,
                no_speech_threshold=0.55)
            text = " ".join(s.text.strip() for s in segs).strip()
        low = text.lower()
        if len(text) < 2 or any(h in low for h in HALLUCINATIONS):
            return ""
        return text


# ───────────────────────────── Satz-Erkennung per Lautstärke ─────────────
class Segmenter:
    """Schneidet aus dem Mikrofonstrom einzelne gesprochene Sätze (100-ms-Blöcke)."""

    def __init__(self, gate=150):
        self.gate = gate
        self.reset()
        self.floor = 150.0

    def reset(self):
        self.pre = deque(maxlen=4)
        self.seg = []
        self.in_speech = False
        self.hang = 0
        self.run = 0
        self.loud_blocks = 0

    def feed(self, data, fast_end=False):
        """Gibt (fertiger_satz_oder_None, lautstärke, gerade_gestartet) zurück."""
        a = np.frombuffer(data, dtype=np.int16).astype(np.float32)
        rms = float(np.sqrt(np.mean(a * a))) if len(a) else 0.0
        thr = max(self.gate, self.floor * 2.5)
        loud = rms > thr
        if not loud and not self.in_speech:
            self.floor = min(1500.0, 0.95 * self.floor + 0.05 * rms)
        started, done = False, None
        if self.in_speech:
            self.seg.append(data)
            if loud:
                self.hang, self.loud_blocks = 0, self.loud_blocks + 1
            else:
                self.hang += 1
            if self.hang >= (5 if fast_end else 7) or len(self.seg) > 150:
                if self.loud_blocks >= 3:
                    done = b"".join(self.seg)
                self.reset()
        else:
            self.pre.append(data)
            self.run = self.run + 1 if loud else 0
            if self.run >= 2:
                self.in_speech, started = True, True
                self.seg = list(self.pre)
                self.hang, self.loud_blocks = 0, self.run
        return done, rms, started
