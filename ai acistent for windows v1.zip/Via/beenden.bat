@echo off
chcp 65001 >nul
echo Beende alle laufenden Via-Programme ...
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -match 'venv\\Scripts\\pythonw?\.exe' -and $_.CommandLine -match 'main\.py|trainer_app\.py' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"
echo Fertig. Alle alten Via-Fenster und Hintergrundprozesse sind beendet.
pause
