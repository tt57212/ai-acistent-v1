@echo off
chcp 65001 >nul
title Via Trainings-App
cd /d "%~dp0"
if not exist venv\Scripts\python.exe (
    echo Bitte zuerst start.bat ausfuehren.
    pause
    exit /b 1
)
start "" venv\Scripts\pythonw.exe trainer_app.py
