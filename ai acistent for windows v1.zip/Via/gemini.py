"""
gemini.py - Verbindung zu Google Gemini (REST, ohne Zusatzpaket)

Wird NUR benutzt für: die Programmierecke, das optionale Online-Gehirn und die Erzeugung von Trainingsdaten.
Vias eigenes Gehirn (via_ai.py) bleibt komplett offline.
"""
import datetime
import json
import os
import re
import urllib.error
import urllib.request

BASE_URL = "https://generativelanguage.googleapis.com/v1beta"
SKIP_MODELS = re.compile(r"image|tts|embed|live|audio|robot|veo|lyria|imagen|aqa|deep-research|antigravity|computer-use|learnlm",
                         re.I)


def api_key(cfg):
    return (cfg.get("gemini_key") or os.environ.get("GEMINI_API_KEY") or "").strip()


def _request(url, key, body=None, timeout=120):
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json", "x-goog-api-key": key})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.load(r)
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode("utf-8", "ignore")).get("error", {}).get("message", "")
        except Exception:
            msg = ""
        hint = {400: "Anfrage ungültig oder Schlüssel falsch", 403: "Schlüssel hat keine Berechtigung",
                404: "Modell nicht gefunden (Modelle neu laden)", 429: "Zu viele Anfragen / Kontingent aufgebraucht"}.get(e.code, "")
        raise RuntimeError(f"Gemini-Fehler {e.code}: {msg or hint}".strip())
    except urllib.error.URLError as e:
        raise RuntimeError(f"Keine Verbindung zu Gemini ({e.reason})")


def _version(name):
    m = re.search(r"gemini-(\d+(?:\.\d+)?)", name)
    return float(m.group(1)) if m else 0.0


def list_models(key):
    """Alle Textmodelle, die generateContent können - neueste zuerst (Flash vor Pro vor Lite, Stabil vor Vorschau)."""
    out, token = [], ""
    for _ in range(5):
        d = _request(f"{BASE_URL}/models?pageSize=200" + (f"&pageToken={token}" if token else ""), key, timeout=30)
        for m in d.get("models", []):
            n = m["name"].replace("models/", "")
            if "generateContent" in m.get("supportedGenerationMethods", []) and n.startswith("gemini") \
                    and not SKIP_MODELS.search(n):
                out.append(n)
        token = d.get("nextPageToken", "")
        if not token:
            break

    def rank(n):
        kind = 0 if re.search(r"flash$", n) else 1 if "pro" in n and "preview" not in n else 2 if "flash" in n else 3
        return (-_version(n), kind, "preview" in n, n)
    return sorted(set(out), key=rank)


def pick_default(models):
    for n in models:                       # neuestes stabiles Flash
        if re.fullmatch(r"gemini-\d+(?:\.\d+)?-flash", n):
            return n
    return models[0] if models else "gemini-2.5-flash"


def generate(key, model, system, history, temperature=0.7, timeout=120, max_tokens=None):
    """history = [("user"|"model", text), ...] -> Antworttext."""
    body = {"contents": [{"role": r, "parts": [{"text": t}]} for r, t in history],
            "generationConfig": {"temperature": temperature}}
    if max_tokens:
        body["generationConfig"]["maxOutputTokens"] = max_tokens
    if system:
        body["systemInstruction"] = {"parts": [{"text": system}]}
    d = _request(f"{BASE_URL}/models/{model}:generateContent", key, body, timeout)
    try:
        parts = d["candidates"][0]["content"]["parts"]
        return "".join(p.get("text", "") for p in parts if not p.get("thought")).strip()
    except (KeyError, IndexError):
        reason = d.get("promptFeedback", {}).get("blockReason") or d.get("candidates", [{}])[0].get("finishReason", "")
        raise RuntimeError(f"Gemini hat nicht geantwortet ({reason or 'leere Antwort'}).")


def resolve_model(cfg, key):
    """Gewähltes Modell oder - wenn leer/'automatisch' - das neueste Flash-Modell."""
    m = (cfg.get("gemini_model") or "").strip()
    if m and m != "automatisch":
        return m
    cfg["_gemini_auto"] = cfg.get("_gemini_auto") or pick_default(list_models(key))
    return cfg["_gemini_auto"]


# ───────────────────────────── Online-Gehirn für Via ─────────────────────
SENT = re.compile(r"(?<=[.!?])\s+|\n+")


class GeminiBrain:
    """Optionales Gehirn: Gemini beantwortet das freie Gespräch (vortrainiert, aber online)."""
    kind = "gemini"

    def __init__(self, cfg, name_fn, city_fn=None):
        self.cfg, self.name_fn = cfg, name_fn
        self.history = []

    @property
    def ready(self):
        return bool(api_key(self.cfg))

    def reset(self):
        self.history.clear()

    def system(self, assistant):
        now = datetime.datetime.now()
        timers = ", ".join(f"{int(t['rem'])} Sekunden" for t in assistant.snapshot()) or "keine"
        return (f"Du bist {self.name_fn()}, ein freundlicher, kluger Sprachassistent auf dem Computer des Nutzers. "
                "Du duzt ihn und sprichst Deutsch. Deine Antworten werden laut vorgelesen: antworte natürlich und "
                "gesprochen, meistens in einem bis drei kurzen Sätzen, ohne Listen, ohne Markdown, ohne Emojis. "
                "Erfinde keine Fakten; sag ehrlich, wenn du etwas nicht weißt. Timer, Stoppuhren, Wetter, Uhrzeit, "
                "Rechnen, Notizen und das Öffnen von Apps erledigt das System selbst, wenn der Nutzer direkt danach fragt. "
                f"Jetzt ist {now:%A, %d.%m.%Y, %H:%M} Uhr. Standort: {self.cfg.get('city', 'unbekannt')}. "
                f"Laufende Timer: {timers}.")

    def stream(self, user, assistant):
        key = api_key(self.cfg)
        model = resolve_model(self.cfg, key)
        msgs = self.history[-10:] + [("user", user)]
        text = generate(key, model, self.system(assistant), msgs, temperature=0.7, timeout=40, max_tokens=300)
        text = re.sub(r"[*_#`>~|]+", "", text)
        sents = [s.strip() for s in SENT.split(text) if s.strip()]
        self.history = (msgs + [("model", text)])[-12:]
        for s in sents:
            yield s


# ───────────────────────────── Code-Änderungen (Programmierecke) ─────────
CODE_SYSTEM = """Du bist der Code-Assistent in Vias Programmierecke. Der Nutzer arbeitet an Python-Programmen, \
unter anderem an Via selbst (Sprachassistent mit eigenem Mini-GPT in NumPy). Antworte auf Deutsch, knapp und konkret.

WENN du Dateien änderst, nutze AUSSCHLIESSLICH dieses Format (beliebig viele Blöcke), damit die App die Änderung prüfen kann:

FILE: dateiname.py
<<<<<<< SEARCH
(exakter, unveränderter Originaltext aus der Datei, wenige Zeilen, eindeutig)
=======
(neuer Text)
>>>>>>> REPLACE

Regeln: SEARCH muss zeichengenau im Original stehen und genau einmal vorkommen. Für eine NEUE Datei lass SEARCH leer. \
Ändere nur, was nötig ist. Schreibe vor den Blöcken eine kurze Erklärung. Stelle sicher, dass der Code lauffähig bleibt."""

BLOCK = re.compile(r"<<<<<<< SEARCH\n(.*?)\n?=======\n(.*?)\n?>>>>>>> REPLACE", re.S)


def parse_edits(text):
    """-> [(dateiname, search, replace)]"""
    edits, parts = [], re.split(r"^FILE:\s*(.+?)\s*$", text.replace("\r\n", "\n"), flags=re.M)
    for i in range(1, len(parts), 2):
        for s, r in BLOCK.findall(parts[i + 1]):
            edits.append((parts[i].strip().strip("`*"), s, r))
    return edits


def apply_edit(source, search, replace):
    """Wendet einen Block an. Gibt (neuer_text, fehler_oder_None) zurück."""
    source = source.replace("\r\n", "\n")
    if search == "__WHOLE__":
        return replace + "\n", None
    if not search.strip():
        return (source.rstrip("\n") + "\n\n" + replace + "\n" if source.strip() else replace + "\n"), None
    n = source.count(search)
    if n == 0:
        # Toleranter Versuch: Zeilenenden-Leerzeichen ignorieren
        norm = lambda t: "\n".join(l.rstrip() for l in t.split("\n"))
        if norm(search) in norm(source):
            return norm(source).replace(norm(search), replace, 1), None
        return source, "Die zu ersetzende Stelle wurde nicht gefunden."
    if n > 1:
        return source, "Die Stelle kommt mehrfach vor (nicht eindeutig)."
    return source.replace(search, replace, 1), None
