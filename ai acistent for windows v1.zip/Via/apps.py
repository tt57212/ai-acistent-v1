"""
apps.py - Programme, Webseiten und Ordner per Sprache öffnen

Windows: liest alle Start-Menü-Programme ein (inkl. Store-Apps wie Spotify) und startet sie über ihren Namen.
Zusätzlich: eigene Apps (Einstellungen > Apps), bekannte Webseiten und Ordner.
"""
import difflib
import json
import os
import re
import subprocess
import sys
import threading
import webbrowser
from pathlib import Path
from urllib.parse import quote

WIN = sys.platform.startswith("win")
NO_WINDOW = 0x08000000 if WIN else 0

SITES = {
    "youtube": "https://www.youtube.com", "google": "https://www.google.com", "gmail": "https://mail.google.com",
    "wikipedia": "https://de.wikipedia.org", "netflix": "https://www.netflix.com", "amazon": "https://www.amazon.de",
    "google maps": "https://maps.google.com", "maps": "https://maps.google.com", "karten": "https://maps.google.com",
    "github": "https://github.com", "whatsapp": "https://web.whatsapp.com", "twitch": "https://www.twitch.tv",
    "reddit": "https://www.reddit.com", "instagram": "https://www.instagram.com", "facebook": "https://www.facebook.com",
    "ebay": "https://www.ebay.de", "nachrichten": "https://www.tagesschau.de", "tagesschau": "https://www.tagesschau.de",
    "übersetzer": "https://translate.google.com", "chatgpt": "https://chatgpt.com", "kalender": "https://calendar.google.com",
    "google drive": "https://drive.google.com", "drive": "https://drive.google.com", "disney plus": "https://www.disneyplus.com",
    "prime video": "https://www.primevideo.com", "spotify web": "https://open.spotify.com", "browser": "https://www.google.com",
    "internet": "https://www.google.com",
}
FOLDERS = {"downloads": "Downloads", "dokumente": "Documents", "bilder": "Pictures", "fotos": "Pictures",
           "musik": "Music", "videos": "Videos", "desktop": "Desktop", "schreibtisch": "Desktop"}
BUILTIN_WIN = {
    "rechner": ("Rechner", "calc.exe"), "taschenrechner": ("Rechner", "calc.exe"),
    "editor": ("Editor", "notepad.exe"), "notepad": ("Editor", "notepad.exe"), "paint": ("Paint", "mspaint.exe"),
    "explorer": ("Datei-Explorer", "explorer.exe"), "datei explorer": ("Datei-Explorer", "explorer.exe"),
    "dateien": ("Datei-Explorer", "explorer.exe"), "task manager": ("Task-Manager", "taskmgr.exe"),
    "taskmanager": ("Task-Manager", "taskmgr.exe"), "eingabeaufforderung": ("Eingabeaufforderung", "cmd.exe"),
    "cmd": ("Eingabeaufforderung", "cmd.exe"), "powershell": ("PowerShell", "powershell.exe"),
    "systemsteuerung": ("Systemsteuerung", "control.exe"), "windows einstellungen": ("Windows-Einstellungen", "ms-settings:"),
    "bildschirmtastatur": ("Bildschirmtastatur", "osk.exe"), "snipping tool": ("Snipping Tool", "snippingtool.exe"),
}
SKIP = re.compile(r"deinstall|uninstall|hilfe|\bhelp\b|readme|website|handbuch|lizenz|license|release notes", re.I)


def norm(s):
    s = s.lower()
    s = re.sub(r"\b(microsoft|windows|google|the)\b", " ", s)
    s = re.sub(r"[^a-z0-9äöüß ]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


class AppLauncher:
    def __init__(self, cfg):
        self.cfg = cfg
        self.apps = {}          # norm-Name -> (Anzeigename, Art, Ziel)
        self.ready = False
        self.scanning = False

    def rescan(self):
        if not self.scanning:
            threading.Thread(target=self._scan, daemon=True).start()

    # ---- Einlesen
    def _scan(self):
        self.scanning = True
        apps = {}
        try:
            if WIN:
                apps.update(self._scan_windows())
            elif sys.platform == "darwin":
                for d in ("/Applications", "/System/Applications"):
                    for p in Path(d).glob("*.app"):
                        apps[norm(p.stem)] = (p.stem, "mac", p.stem)
            else:
                for p in Path("/usr/share/applications").glob("*.desktop"):
                    try:
                        m = re.search(r"^Name=(.+)$", p.read_text(errors="ignore"), re.M)
                        if m and not SKIP.search(m.group(1)):
                            apps[norm(m.group(1))] = (m.group(1), "desktop", p.stem)
                    except Exception:
                        pass
        except Exception as e:
            print("App-Scan:", e)
        if WIN:
            for k, (label, target) in BUILTIN_WIN.items():
                apps.setdefault(k, (label, "file", target))
        for label, path in (self.cfg.get("apps") or {}).items():          # eigene Apps haben Vorrang
            apps[norm(label)] = (label, "file", path)
        self.apps, self.ready, self.scanning = apps, True, False

    def _scan_windows(self):
        apps = {}
        ps = ("[Console]::OutputEncoding=[Text.Encoding]::UTF8; "
              "Get-StartApps | Select-Object Name,AppID | ConvertTo-Json -Compress")
        try:
            r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, timeout=25,
                               creationflags=NO_WINDOW)
            data = json.loads(r.stdout.decode("utf-8", "ignore") or "[]")
            if isinstance(data, dict):
                data = [data]
            for it in data:
                name, appid = it.get("Name", ""), it.get("AppID", "")
                if name and appid and not SKIP.search(name):
                    apps[norm(name)] = (name, "appid", appid)
        except Exception as e:
            print("Get-StartApps:", e)
        if not apps:                       # Rückfall: Startmenü-Verknüpfungen
            roots = [Path(os.environ.get("ProgramData", "C:/ProgramData")) / "Microsoft/Windows/Start Menu/Programs",
                     Path(os.environ.get("APPDATA", "")) / "Microsoft/Windows/Start Menu/Programs",
                     Path.home() / "Desktop"]
            for root in roots:
                for p in root.rglob("*.lnk") if root.exists() else []:
                    if not SKIP.search(p.stem):
                        apps[norm(p.stem)] = (p.stem, "file", str(p))
        return apps

    def names(self):
        return sorted({v[0] for v in self.apps.values()} | set(SITES) | set(FOLDERS), key=str.lower)

    # ---- Suchen
    def find(self, query):
        q = norm(query)
        if not q:
            return None
        best, score = None, 0.0
        for key, val in self.apps.items():
            toks = key.split()
            if key == q: sc = 100
            elif q in toks: sc = 90
            elif key.startswith(q) or (len(q) >= 3 and q in key): sc = 80
            elif all(t in key for t in q.split()): sc = 75
            else: sc = difflib.SequenceMatcher(None, q, key).ratio() * 70
            if sc > score:
                best, score = val, sc
        return best if score >= 60 else None

    # ---- Öffnen
    def open(self, query):
        """Gibt den Anzeigenamen zurück, wenn etwas geöffnet wurde - sonst None."""
        q = norm(query)
        hit = self.find(query)
        if hit:
            try:
                self._launch(hit)
                return hit[0]
            except Exception as e:
                print("Start fehlgeschlagen:", e)
        for key, url in SITES.items():
            if q == key or (len(q) >= 4 and difflib.SequenceMatcher(None, q, key).ratio() >= 0.8):
                webbrowser.open(url)
                return key.title()
        for key, folder in FOLDERS.items():
            if q == key:
                os.startfile(str(Path.home() / folder)) if WIN else subprocess.Popen(["xdg-open", str(Path.home() / folder)])
                return folder
        m = re.match(r"^([\w-]+\.)+(de|com|org|net|eu|io|at|ch)$", query.strip().lower())
        if m:
            webbrowser.open("https://" + query.strip().lower())
            return query.strip().lower()
        return None

    def web_search(self, text):
        webbrowser.open("https://www.google.com/search?q=" + quote(text))

    def _launch(self, hit):
        label, kind, target = hit
        if kind == "appid":
            subprocess.Popen(["explorer.exe", f"shell:AppsFolder\\{target}"], creationflags=NO_WINDOW)
        elif kind == "file":
            os.startfile(target) if WIN else subprocess.Popen(["xdg-open", target])
        elif kind == "mac":
            subprocess.Popen(["open", "-a", target])
        elif kind == "desktop":
            subprocess.Popen(["gtk-launch", target])
