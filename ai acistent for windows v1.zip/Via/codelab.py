#!/usr/bin/env python3
"""
Via Programmierecke - Editor, Ausführen und ein Gemini-Assistent, der deinen Code (auch Vias eigenen) ändern kann.

Sicherheit: Gemini schlägt nur Änderungen VOR. Du siehst jeden Unterschied, bestätigst, es gibt einen Syntax-Check
und von jeder geänderten Datei ein Backup (Ordner backups/), das du mit einem Klick zurückholst.
"""
import difflib
import re
import shutil
import sys
import time
from pathlib import Path

from PySide6.QtCore import Qt, QProcess, QRect, QSize, QThread, Signal, QRegularExpression
from PySide6.QtGui import (QColor, QFont, QKeySequence, QPainter, QShortcut, QSyntaxHighlighter, QTextCharFormat)
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QHBoxLayout, QInputDialog, QLabel, QLineEdit,
                               QListWidget, QListWidgetItem, QMainWindow, QMessageBox, QPlainTextEdit, QPushButton,
                               QSplitter, QTabWidget, QVBoxLayout, QWidget)

import gemini
import llmapi

ROOT = Path(__file__).resolve().parent
WORK = ROOT / "werkstatt"
BACKUPS = ROOT / "backups"

CFG_FILE = ROOT / "config.json"


def persist(cfg, keys=("gemini_key", "gemini_model", "llm_provider", "ollama_model", "ollama_url")):
    """Schlüssel/Modell dauerhaft in config.json merken."""
    import json
    try:
        d = json.loads(CFG_FILE.read_text(encoding="utf-8")) if CFG_FILE.exists() else {}
        for k in keys:
            d[k] = cfg.get(k, "")
        CFG_FILE.write_text(json.dumps(d, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception as e:
        print("Konfig:", e)


QSS = """
QMainWindow,QWidget{background:#12152b;color:#e9ecff;font-size:13px;}
QLabel#muted{color:rgba(255,255,255,125);}
QLabel#head{font-size:15px;font-weight:700;}
QPushButton{background:rgba(255,255,255,20);color:#eef0ff;border:none;border-radius:9px;padding:7px 13px;}
QPushButton:hover{background:rgba(255,255,255,40);}
QPushButton:disabled{color:rgba(255,255,255,70);}
QPushButton#go{background:#4f5fe8;font-weight:700;}
QPushButton#ok{background:#1f9d78;font-weight:700;}
QPushButton#go:hover{background:#6372ff;}
QLineEdit,QComboBox,QPlainTextEdit,QListWidget,QTabWidget::pane{background:#0e1124;color:#eef0ff;
  border:1px solid rgba(255,255,255,26);border-radius:8px;selection-background-color:#4f5fe8;}
QLineEdit,QComboBox{padding:6px 9px;}
QComboBox QAbstractItemView{background:#171a33;color:#e9ecff;selection-background-color:#4f5fe8;}
QTabBar::tab{background:transparent;color:rgba(255,255,255,140);padding:7px 14px;}
QTabBar::tab:selected{color:white;border-bottom:2px solid #6c7bff;}
QListWidget::item{padding:4px 6px;border-radius:5px;}
QListWidget::item:selected{background:rgba(108,123,255,120);}
QSplitter::handle{background:rgba(255,255,255,14);}
"""


# ───────────────────────────── Editor ────────────────────────────────────
def fmt(color, bold=False, italic=False):
    f = QTextCharFormat()
    f.setForeground(QColor(color))
    if bold: f.setFontWeight(75)
    if italic: f.setFontItalic(True)
    return f


class PyHighlighter(QSyntaxHighlighter):
    KW = ("False None True and as assert async await break class continue def del elif else except finally for from "
          "global if import in is lambda nonlocal not or pass raise return try while with yield").split()

    def __init__(self, doc):
        super().__init__(doc)
        self.f_str = fmt("#a6e3a1")
        self.rules = [
            (QRegularExpression(r"\b(" + "|".join(self.KW) + r")\b"), fmt("#c792ea", True)),
            (QRegularExpression(r"\b(self|print|len|range|str|int|float|list|dict|set|open|super)\b"), fmt("#82aaff")),
            (QRegularExpression(r"\b\d+(\.\d+)?\b"), fmt("#f78c6c")),
            (QRegularExpression(r"(?<=def )\w+|(?<=class )\w+"), fmt("#ffcb6b", True)),
            (QRegularExpression(r"\"[^\"\\]*(\\.[^\"\\]*)*\"|'[^'\\]*(\\.[^'\\]*)*'"), self.f_str),
            (QRegularExpression(r"#[^\n]*"), fmt("#6c7a9c", italic=True)),
        ]

    def highlightBlock(self, text):
        for rx, f in self.rules:
            it = rx.globalMatch(text)
            while it.hasNext():
                m = it.next()
                self.setFormat(m.capturedStart(), m.capturedLength(), f)
        self.setCurrentBlockState(0)
        start = 0
        if self.previousBlockState() == 1:
            end = text.find('"""')
            if end == -1:
                self.setFormat(0, len(text), self.f_str); self.setCurrentBlockState(1); return
            self.setFormat(0, end + 3, self.f_str); start = end + 3
        while True:
            i = text.find('"""', start)
            if i == -1:
                break
            j = text.find('"""', i + 3)
            if j == -1:
                self.setFormat(i, len(text) - i, self.f_str); self.setCurrentBlockState(1); break
            self.setFormat(i, j + 3 - i, self.f_str); start = j + 3


class LineNumbers(QWidget):
    def __init__(self, ed):
        super().__init__(ed)
        self.ed = ed

    def sizeHint(self):
        return QSize(self.ed.line_width(), 0)

    def paintEvent(self, e):
        self.ed.paint_numbers(e)


class CodeEdit(QPlainTextEdit):
    def __init__(self):
        super().__init__()
        f = QFont("Cascadia Mono, Consolas, Menlo, DejaVu Sans Mono"); f.setStyleHint(QFont.Monospace); f.setPointSize(11)
        self.setFont(f)
        self.setLineWrapMode(QPlainTextEdit.NoWrap)
        self.setTabStopDistance(4 * self.fontMetrics().horizontalAdvance(" "))
        self.nums = LineNumbers(self)
        self.blockCountChanged.connect(self.update_width)
        self.updateRequest.connect(self.update_nums)
        self.update_width(0)
        self.hl = PyHighlighter(self.document())

    def line_width(self):
        return 16 + self.fontMetrics().horizontalAdvance("9") * len(str(max(1, self.blockCount())))

    def update_width(self, _):
        self.setViewportMargins(self.line_width(), 0, 0, 0)

    def update_nums(self, rect, dy):
        if dy:
            self.nums.scroll(0, dy)
        else:
            self.nums.update(0, rect.y(), self.nums.width(), rect.height())
        if rect.contains(self.viewport().rect()):
            self.update_width(0)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        cr = self.contentsRect()
        self.nums.setGeometry(QRect(cr.left(), cr.top(), self.line_width(), cr.height()))

    def paint_numbers(self, event):
        p = QPainter(self.nums)
        p.fillRect(event.rect(), QColor("#0b0d1e"))
        block = self.firstVisibleBlock()
        n = block.blockNumber()
        top = round(self.blockBoundingGeometry(block).translated(self.contentOffset()).top())
        bottom = top + round(self.blockBoundingRect(block).height())
        p.setPen(QColor(255, 255, 255, 90))
        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                p.drawText(0, top, self.nums.width() - 8, self.fontMetrics().height(), Qt.AlignRight, str(n + 1))
            block = block.next()
            top = bottom
            bottom = top + round(self.blockBoundingRect(block).height())
            n += 1

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Tab:
            self.insertPlainText("    "); return
        if e.key() in (Qt.Key_Return, Qt.Key_Enter):
            line = self.textCursor().block().text()
            indent = line[:len(line) - len(line.lstrip(" "))]
            if line.rstrip().endswith(":"):
                indent += "    "
            super().keyPressEvent(e)
            self.insertPlainText(indent)
            return
        super().keyPressEvent(e)


# ───────────────────────────── Gemini im Hintergrund ─────────────────────
WHOLE_SYSTEM = """Du bist der Code-Assistent in Vias Programmierecke. Antworte auf Deutsch, knapp. \
Wenn der Nutzer eine Änderung an der gezeigten Datei möchte: schreibe kurz, was du änderst, und gib dann die VOLLSTÄNDIGE neue \
Version der Datei in genau einem Markdown-Codeblock aus (```python ... ```). Keine Auslassungen, keine Platzhalter wie '...'."""


class AskWorker(QThread):
    done = Signal(str)
    failed = Signal(str)

    def __init__(self, cfg, history, whole=False):
        super().__init__()
        self.cfg, self.history, self.whole = cfg, history, whole

    def run(self):
        try:
            if not llmapi.ready(self.cfg):
                raise RuntimeError("Kein Gemini-Schlüssel eingetragen.")
            model = llmapi.resolve_model(self.cfg, "code")
            text = llmapi.generate(self.cfg, WHOLE_SYSTEM if self.whole else gemini.CODE_SYSTEM, self.history,
                                   temperature=0.3, timeout=900, purpose="code", ctx=16384)
            self.done.emit(f"[{llmapi.provider(self.cfg)} · {model}]\n" + text)
        except Exception as e:
            self.failed.emit(str(e))


class ModelsWorker(QThread):
    done = Signal(list)
    failed = Signal(str)

    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg

    def run(self):
        try:
            c = self.cfg
            self.done.emit(gemini.list_models(gemini.api_key(c)) if llmapi.provider(c) == "gemini" else llmapi.ollama_models(c))
        except Exception as e:
            self.failed.emit(str(e))


class PullWorker(QThread):
    done = Signal(str)
    failed = Signal(str)

    def __init__(self, cfg, name):
        super().__init__()
        self.cfg, self.name = cfg, name

    def run(self):
        try:
            llmapi.pull(self.cfg, self.name)
            self.done.emit(self.name)
        except Exception as e:
            self.failed.emit(str(e))


# ───────────────────────────── Fenster ───────────────────────────────────
class CodeLab(QMainWindow):
    def __init__(self, cfg=None):
        super().__init__()
        self.cfg = cfg if cfg is not None else {}
        self.setWindowTitle("Via · Programmierecke")
        self.resize(1320, 800)
        self.setStyleSheet(QSS)
        self.tabs_files = {}          # Path -> CodeEdit
        self.chat = []                # [(rolle, text)] ohne Datei-Anhänge
        self.pending = []             # [(datei, search, replace)]
        self.worker = None
        self._whole = False
        WORK.mkdir(exist_ok=True)
        if not any(WORK.glob("*.py")):
            (WORK / "hallo.py").write_text('# Meine erste Datei in der Programmierecke\nname = "Welt"\nprint(f"Hallo {name}!")\n',
                                           encoding="utf-8")
        self.proc = QProcess(self)
        self.proc.setProcessChannelMode(QProcess.MergedChannels)
        self.proc.readyRead.connect(lambda: self.out.insertPlainText(bytes(self.proc.readAll()).decode("utf-8", "replace")))
        self.proc.finished.connect(lambda c, s: self.out.appendPlainText(f"\n— beendet (Code {c}) —"))

        split = QSplitter()
        self.setCentralWidget(split)
        split.addWidget(self._left())
        split.addWidget(self._center())
        split.addWidget(self._right())
        split.setSizes([210, 700, 410])
        QShortcut(QKeySequence("Ctrl+S"), self, self.save)
        QShortcut(QKeySequence("F5"), self, self.run_file)
        self.refresh_files()
        self.open_file(WORK / "hallo.py")

    # ---- Layout
    def _left(self):
        w = QWidget(); v = QVBoxLayout(w); v.setContentsMargins(8, 8, 4, 8)
        h = QLabel("Dateien"); h.setObjectName("head"); v.addWidget(h)
        self.files = QListWidget(); self.files.itemDoubleClicked.connect(lambda it: self.open_file(Path(it.data(Qt.UserRole))))
        v.addWidget(self.files, 1)
        row = QHBoxLayout()
        nb = QPushButton("＋ Neu"); nb.clicked.connect(self.new_file)
        rb = QPushButton("↻"); rb.clicked.connect(self.refresh_files)
        row.addWidget(nb, 1); row.addWidget(rb)
        v.addLayout(row)
        info = QLabel("Doppelklick öffnet. „werkstatt/“ ist dein eigener Bereich, die anderen sind Vias Dateien."); info.setWordWrap(True)
        info.setObjectName("muted"); v.addWidget(info)
        return w

    def _center(self):
        w = QWidget(); v = QVBoxLayout(w); v.setContentsMargins(4, 8, 4, 8)
        bar = QHBoxLayout()
        for txt, fn, name in (("💾 Speichern", self.save, ""), ("▶ Ausführen (F5)", self.run_file, "go"),
                              ("■ Stopp", lambda: self.proc.kill(), ""), ("✓ Syntax prüfen", self.check, ""),
                              ("↶ Backup zurückholen", self.restore, "")):
            b = QPushButton(txt); b.clicked.connect(fn)
            if name: b.setObjectName(name)
            bar.addWidget(b)
        bar.addStretch()
        v.addLayout(bar)
        sp = QSplitter(Qt.Vertical)
        self.tabs = QTabWidget(); self.tabs.setTabsClosable(True); self.tabs.tabCloseRequested.connect(self.close_tab)
        sp.addWidget(self.tabs)
        self.out = QPlainTextEdit(); self.out.setReadOnly(True); self.out.setPlaceholderText("Ausgabe erscheint hier …")
        sp.addWidget(self.out)
        sp.setSizes([560, 180])
        v.addWidget(sp, 1)
        return w

    def _right(self):
        w = QWidget(); v = QVBoxLayout(w); v.setContentsMargins(4, 8, 8, 8); v.setSpacing(6)
        h = QLabel("KI-Assistent"); h.setObjectName("head"); v.addWidget(h)
        self.prov = QComboBox()
        self.prov.addItem("Ollama · lokal auf deinem PC (empfohlen)", "ollama")
        self.prov.addItem("Gemini · online bei Google", "gemini")
        self.prov.setCurrentIndex(max(0, self.prov.findData(llmapi.provider(self.cfg))))
        self.prov.currentIndexChanged.connect(self.on_provider)
        v.addWidget(self.prov)
        self.key = QLineEdit(self.cfg.get("gemini_key", "")); self.key.setEchoMode(QLineEdit.Password)
        self.key.setPlaceholderText("Gemini-API-Schlüssel (aistudio.google.com)")
        self.key.editingFinished.connect(self.save_key)
        v.addWidget(self.key)
        row = QHBoxLayout()
        self.model = QComboBox(); self.model.setEditable(True)
        self.model.setEditText(self._model_text())
        self.model.editTextChanged.connect(self.on_model_text)
        lb = QPushButton("Modelle laden"); lb.clicked.connect(self.load_models)
        row.addWidget(self.model, 1); row.addWidget(lb)
        v.addLayout(row)
        self.pull_row = QWidget(); pr = QHBoxLayout(self.pull_row); pr.setContentsMargins(0, 0, 0, 0)
        self.rec = QComboBox(); self.rec.addItems(llmapi.RECOMMENDED)
        pb = QPushButton("⬇ Herunterladen"); pb.clicked.connect(self.pull_model)
        pr.addWidget(self.rec, 1); pr.addWidget(pb)
        v.addWidget(self.pull_row)
        self.ctx_cur = QCheckBox("Aktuelle Datei mitschicken"); self.ctx_cur.setChecked(True); v.addWidget(self.ctx_cur)
        self.whole = QCheckBox("Ganze Datei neu schreiben (für kleine Modelle und kleine Dateien)"); v.addWidget(self.whole)
        v.addWidget(QLabel("Weitere Dateien als Kontext:"))
        self.ctx = QListWidget(); self.ctx.setMaximumHeight(90); v.addWidget(self.ctx)
        self.log = QPlainTextEdit(); self.log.setReadOnly(True)
        self.log.setPlaceholderText("Beispiel: „Füge in main.py den Sprachbefehl ‚spiel würfeln‘ hinzu“ oder „Erkläre mir diese Datei“.")
        v.addWidget(self.log, 1)
        self.prompt = QPlainTextEdit(); self.prompt.setFixedHeight(76)
        self.prompt.setPlaceholderText("Was soll die KI tun? (Strg+Enter sendet)")
        QShortcut(QKeySequence("Ctrl+Return"), self.prompt, self.send)
        v.addWidget(self.prompt)
        row = QHBoxLayout()
        self.b_send = QPushButton("➤ Senden"); self.b_send.setObjectName("go"); self.b_send.clicked.connect(self.send)
        self.b_apply = QPushButton("✓ Änderungen übernehmen"); self.b_apply.setObjectName("ok"); self.b_apply.setEnabled(False)
        self.b_apply.clicked.connect(self.apply_pending)
        self.b_drop = QPushButton("✕"); self.b_drop.setEnabled(False); self.b_drop.clicked.connect(self.drop_pending)
        row.addWidget(self.b_send, 2); row.addWidget(self.b_apply, 3); row.addWidget(self.b_drop)
        v.addLayout(row)
        self.status = QLabel(""); self.status.setObjectName("muted"); self.status.setWordWrap(True); v.addWidget(self.status)
        self.refresh_provider_ui()
        return w

    # ---- Dateien
    def project_files(self):
        fs = sorted(p for p in ROOT.iterdir() if p.is_file() and p.suffix in (".py", ".bat", ".txt", ".md"))
        return fs + sorted(WORK.glob("*.py"))

    def refresh_files(self):
        self.files.clear(); self.ctx.clear()
        for p in self.project_files():
            rel = str(p.relative_to(ROOT)).replace("\\", "/")
            it = QListWidgetItem(rel); it.setData(Qt.UserRole, str(p)); self.files.addItem(it)
            c = QListWidgetItem(rel); c.setData(Qt.UserRole, str(p)); c.setFlags(c.flags() | Qt.ItemIsUserCheckable)
            c.setCheckState(Qt.Unchecked); self.ctx.addItem(c)

    def open_file(self, path):
        path = Path(path)
        if path in self.tabs_files:
            self.tabs.setCurrentWidget(self.tabs_files[path]); return
        ed = CodeEdit()
        ed.setPlainText(path.read_text(encoding="utf-8", errors="replace") if path.exists() else "")
        ed.document().setModified(False)
        self.tabs_files[path] = ed
        self.tabs.setCurrentIndex(self.tabs.addTab(ed, path.name))

    def current(self):
        ed = self.tabs.currentWidget()
        for p, e in self.tabs_files.items():
            if e is ed:
                return p, ed
        return None, None

    def close_tab(self, i):
        ed = self.tabs.widget(i)
        for p, e in list(self.tabs_files.items()):
            if e is ed:
                del self.tabs_files[p]
        self.tabs.removeTab(i)

    def new_file(self):
        name, ok = QInputDialog.getText(self, "Neue Datei", "Name (z. B. meinprogramm.py):")
        if ok and name.strip():
            n = name.strip() if "." in name else name.strip() + ".py"
            p = WORK / n
            if not p.exists():
                p.write_text("# " + n + "\n", encoding="utf-8")
            self.refresh_files(); self.open_file(p)

    def save(self):
        p, ed = self.current()
        if p:
            p.write_text(ed.toPlainText(), encoding="utf-8")
            ed.document().setModified(False)
            self.status.setText(f"Gespeichert: {p.name}")

    def backup(self, path):
        if path.exists():
            BACKUPS.mkdir(exist_ok=True)
            shutil.copy2(path, BACKUPS / f"{path.stem}.{time.strftime('%Y%m%d-%H%M%S')}{path.suffix}")

    def restore(self):
        p, ed = self.current()
        if not p or not BACKUPS.exists():
            return
        cands = sorted(BACKUPS.glob(f"{p.stem}.*{p.suffix}"))
        if not cands:
            QMessageBox.information(self, "Backup", "Für diese Datei gibt es noch kein Backup."); return
        if QMessageBox.question(self, "Backup zurückholen", f"{cands[-1].name}\nin {p.name} wiederherstellen?") == QMessageBox.Yes:
            self.backup(p)
            ed.setPlainText(cands[-1].read_text(encoding="utf-8")); p.write_text(ed.toPlainText(), encoding="utf-8")

    def check(self):
        p, ed = self.current()
        if not p:
            return
        try:
            compile(ed.toPlainText(), p.name, "exec")
            self.status.setText("✓ Syntax in Ordnung.")
        except SyntaxError as e:
            self.status.setText(f"✗ Syntaxfehler in Zeile {e.lineno}: {e.msg}")

    def run_file(self):
        p, ed = self.current()
        if not p or p.suffix != ".py":
            return
        self.save()
        self.out.clear()
        exe = sys.executable.replace("pythonw", "python")
        self.proc.setWorkingDirectory(str(p.parent))
        self.proc.start(exe, ["-u", str(p)])

    # ---- KI (Ollama / Gemini)
    def _model_key(self):
        return "gemini_model" if llmapi.provider(self.cfg) == "gemini" else "ollama_model"

    def _model_text(self):
        return self.cfg.get(self._model_key()) or "automatisch"

    def on_model_text(self, t):
        self.cfg[self._model_key()] = "" if t.strip() in ("", "automatisch") else t.strip()
        persist(self.cfg)

    def on_provider(self):
        self.cfg["llm_provider"] = self.prov.currentData()
        persist(self.cfg)
        self.model.blockSignals(True); self.model.clear(); self.model.setEditText(self._model_text()); self.model.blockSignals(False)
        self.refresh_provider_ui()

    def refresh_provider_ui(self):
        g = llmapi.provider(self.cfg) == "gemini"
        self.key.setVisible(g)
        self.pull_row.setVisible(not g)
        self.status.setText(("Hinweis: Dein Code wird an Google gesendet. " if g else
                             "Alles bleibt auf deinem PC (Ollama). Für Code ist ein Coder-Modell ab 7B am besten. ")
                            + "Änderungen werden erst nach deiner Bestätigung gespeichert.")

    def save_key(self):
        self.cfg["gemini_key"] = self.key.text().strip()
        persist(self.cfg)

    def load_models(self):
        self.save_key()
        self.status.setText("Lade Modelle …")
        self.mw = ModelsWorker(self.cfg)

        def done(ms):
            self.model.blockSignals(True); self.model.clear(); self.model.addItems(["automatisch"] + ms)
            self.model.setEditText(self._model_text()); self.model.blockSignals(False)
            self.status.setText(f"{len(ms)} Modelle gefunden. „automatisch“ wählt ein passendes." if ms else
                                "Noch kein Modell installiert. Wähle eines zum Herunterladen.")
        self.mw.done.connect(done)
        self.mw.failed.connect(lambda e: self.status.setText("✗ " + e))
        self.mw.start()

    def pull_model(self):
        name = self.rec.currentText().strip()
        self.status.setText(f"Lade {name} herunter … das kann einige Minuten dauern.")
        self.pw = PullWorker(self.cfg, name)
        self.pw.done.connect(lambda n: (self.model.setEditText(n), self.status.setText(f"✓ {n} ist installiert und ausgewählt.")))
        self.pw.failed.connect(lambda e: self.status.setText("✗ " + e))
        self.pw.start()

    def build_context(self):
        paths = []
        p, _ = self.current()
        if (self.ctx_cur.isChecked() or self.whole.isChecked()) and p:
            paths.append(p)
        for i in range(self.ctx.count()):
            it = self.ctx.item(i)
            if it.checkState() == Qt.Checked and Path(it.data(Qt.UserRole)) not in paths:
                paths.append(Path(it.data(Qt.UserRole)))
        parts = []
        for q in paths:
            ed = self.tabs_files.get(q)
            txt = ed.toPlainText() if ed else q.read_text(encoding="utf-8", errors="replace")
            parts.append(f"===== Datei: {q.name} =====\n{txt}")
        return "\n\n".join(parts)

    def send(self):
        text = self.prompt.toPlainText().strip()
        if not text or (self.worker and self.worker.isRunning()):
            return
        if self.whole.isChecked() and not self.current()[0]:
            self.status.setText("Für „Ganze Datei“ zuerst eine Datei öffnen."); return
        self.save_key()
        ctx = self.build_context()
        full = (f"Aktuelle Dateien:\n{ctx}\n\n" if ctx else "") + f"Aufgabe: {text}"
        self.log.appendPlainText(f"\n🧑 Du: {text}\n")
        self.prompt.clear()
        self.status.setText("Die KI denkt nach … (lokale Modelle können je nach PC einige Minuten brauchen)")
        self.b_send.setEnabled(False)
        self._clean_user = text
        self._whole = self.whole.isChecked()
        self.worker = AskWorker(self.cfg, self.chat[-8:] + [("user", full)], self._whole)
        self.worker.done.connect(self.on_answer)
        self.worker.failed.connect(lambda e: (self.log.appendPlainText("✗ " + e), self.status.setText("✗ " + e),
                                              self.b_send.setEnabled(True)))
        self.worker.start()

    def on_answer(self, text):
        self.b_send.setEnabled(True)
        self.chat += [("user", self._clean_user), ("model", text)]
        self.chat = self.chat[-12:]
        self.log.appendPlainText("🤖 KI:\n" + text + "\n")
        if self._whole:
            m = re.search(r"```[\w+-]*\n(.*?)```", text, re.S)
            p, _ = self.current()
            self.pending = [(p.name, "__WHOLE__", m.group(1).rstrip("\n"))] if (m and p) else []
        else:
            self.pending = gemini.parse_edits(text)
        if not self.pending:
            self.status.setText("Antwort erhalten (keine Code-Änderungen erkannt). Kleine Modelle halten das Format oft nicht ein: "
                                "probiere „Ganze Datei neu schreiben“."); return
        shown = []
        for fname, s, r in self.pending:
            if s == "__WHOLE__":
                p, ed = self.current()
                s = ed.toPlainText() if ed else ""
            shown.append(f"— {fname} —\n" + "".join(difflib.unified_diff(s.splitlines(True), r.splitlines(True), "alt", "neu", n=1)))
        self.log.appendPlainText("📝 VORSCHAU der Änderungen:\n" + "\n".join(shown))
        self.b_apply.setEnabled(True); self.b_drop.setEnabled(True)
        self.status.setText(f"{len(self.pending)} Änderung(en) vorgeschlagen. Prüfen, dann „Übernehmen“.")

    def drop_pending(self):
        self.pending = []; self.b_apply.setEnabled(False); self.b_drop.setEnabled(False)
        self.status.setText("Vorschlag verworfen.")

    def resolve(self, name):
        n = Path(name.replace("\\", "/")).name
        for base in (ROOT, WORK):
            if (base / n).exists():
                return base / n
        return WORK / n

    def apply_pending(self):
        by_file, problems, results = {}, [], {}
        for fname, s, r in self.pending:
            by_file.setdefault(self.resolve(fname), []).append((s, r))
        for path, blocks in by_file.items():
            ed = self.tabs_files.get(path)
            src = ed.toPlainText() if ed else (path.read_text(encoding="utf-8") if path.exists() else "")
            for s, r in blocks:
                src, err = gemini.apply_edit(src, s, r)
                if err:
                    problems.append(f"{path.name}: {err}"); break
            else:
                if path.suffix == ".py":
                    try:
                        compile(src, path.name, "exec")
                    except SyntaxError as e:
                        problems.append(f"{path.name}: würde einen Syntaxfehler erzeugen (Zeile {e.lineno}: {e.msg})")
                        continue
                results[path] = src
        if problems:
            QMessageBox.warning(self, "Nichts gespeichert", "Die Änderung wurde NICHT angewendet:\n\n" + "\n".join(problems) +
                                "\n\nBitte Gemini bitten, es noch einmal zu versuchen.")
            return
        for path, src in results.items():
            self.backup(path)
            path.write_text(src, encoding="utf-8")
            if path in self.tabs_files:
                self.tabs_files[path].setPlainText(src)
            else:
                self.open_file(path)
        self.refresh_files()
        self.drop_pending()
        names = ", ".join(p.name for p in results)
        self.status.setText(f"✓ Übernommen: {names}. Backups liegen im Ordner „backups“. Via-Dateien wirken nach einem Neustart.")


def main():
    app = QApplication(sys.argv)
    import json
    cfg = {}
    try:
        cfg = json.loads(CFG_FILE.read_text(encoding="utf-8"))
    except Exception:
        pass
    w = CodeLab(cfg)
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
