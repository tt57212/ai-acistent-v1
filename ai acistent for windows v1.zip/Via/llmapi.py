"""
llmapi.py - ein gemeinsamer Zugang zu KI-Modellen für Programmierecke, Gespräch und Trainingsdaten

  Ollama (Standard): läuft lokal auf deinem PC, nichts verlässt ihn. Installieren: ollama.com
  Gemini (optional): online bei Google, braucht einen API-Schlüssel.
"""
import json
import re
import urllib.error
import urllib.request

import gemini

OLLAMA_URL = "http://127.0.0.1:11434"
RECOMMENDED = ["qwen2.5-coder:7b", "qwen2.5-coder:3b", "qwen2.5:7b", "qwen2.5:3b", "llama3.2:3b", "gemma3:4b", "mistral:7b"]
NO_MODEL = "Kein Ollama-Modell installiert. Lade eins in den Einstellungen (Gehirn) oder mit:  ollama pull qwen2.5-coder:7b"
SENT = re.compile(r"(?<=[.!?])\s+|\n+")


def provider(cfg):
    return "gemini" if cfg.get("llm_provider") == "gemini" else "ollama"


def base_url(cfg):
    return (cfg.get("ollama_url") or OLLAMA_URL).rstrip("/")


def _ollama(cfg, path, body=None, timeout=120, stream=False):
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(base_url(cfg) + path, data=data, headers={"Content-Type": "application/json"})
    try:
        r = urllib.request.urlopen(req, timeout=timeout)
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode("utf-8", "ignore")).get("error", "")
        except Exception:
            msg = ""
        if e.code == 404:
            raise RuntimeError(f"Modell nicht installiert. Lade es mit:  ollama pull <name>   ({msg[:80]})")
        raise RuntimeError(f"Ollama-Fehler {e.code}: {msg[:120]}")
    except TimeoutError:
        raise RuntimeError("Ollama antwortet zu langsam (Zeitlimit). Nimm ein kleineres Modell.")
    except (urllib.error.URLError, OSError):
        raise RuntimeError("Ollama läuft nicht. Installiere es von ollama.com und starte es, dann geht es hier.")
    if stream:
        return r
    with r:
        return json.load(r)


def ollama_models(cfg):
    d = _ollama(cfg, "/api/tags", timeout=8)
    return sorted(m["name"] for m in d.get("models", []) if "embed" not in m["name"].lower())


def pull(cfg, name):
    """Lädt ein Modell herunter (kann Minuten dauern)."""
    return _ollama(cfg, "/api/pull", {"model": name, "stream": False}, timeout=7200).get("status", "")


def resolve_model(cfg, purpose="chat"):
    if provider(cfg) == "gemini":
        return gemini.resolve_model(cfg, gemini.api_key(cfg))
    m = (cfg.get("ollama_model") or "").strip()
    if m and m != "automatisch":
        return m
    models = ollama_models(cfg)
    if not models:
        raise RuntimeError(NO_MODEL)
    prefs = (("qwen2.5-coder", "qwen3-coder", "deepseek-coder", "codellama", "qwen3", "qwen2.5", "llama3", "gemma", "mistral")
             if purpose == "code" else ("qwen2.5:", "llama3", "gemma", "qwen3", "mistral", "qwen2.5"))
    for p in prefs:
        for n in models:
            if n.startswith(p):
                return n
    return models[0]


def ready(cfg):
    return bool(gemini.api_key(cfg)) if provider(cfg) == "gemini" else True


def _no_think(text):
    return re.sub(r"<think>.*?</think>", "", text, flags=re.S).strip()


def _msgs(system, history):
    m = [{"role": "system", "content": system}] if system else []
    return m + [{"role": "assistant" if r == "model" else r, "content": t} for r, t in history]


def generate(cfg, system, history, temperature=0.7, timeout=120, max_tokens=None, purpose="chat", ctx=None):
    """history = [("user"|"model", text)] -> kompletter Antworttext."""
    if provider(cfg) == "gemini":
        key = gemini.api_key(cfg)
        if not key:
            raise RuntimeError("Kein Gemini-Schlüssel eingetragen.")
        return gemini.generate(key, gemini.resolve_model(cfg, key), system, history, temperature, timeout, max_tokens)
    opts = {"temperature": temperature, "num_ctx": ctx or (16384 if purpose == "code" else 4096)}
    if max_tokens:
        opts["num_predict"] = max_tokens
    d = _ollama(cfg, "/api/chat", {"model": resolve_model(cfg, purpose), "messages": _msgs(system, history),
                                    "stream": False, "options": opts}, timeout)
    return _no_think(d.get("message", {}).get("content", "") or "")


def stream_chunks(cfg, system, history, temperature=0.7, timeout=90, max_tokens=300):
    """Antwort stückweise (Ollama streamt echt, Gemini liefert alles auf einmal)."""
    if provider(cfg) == "gemini":
        yield generate(cfg, system, history, temperature, timeout, max_tokens)
        return
    body = {"model": resolve_model(cfg, "chat"), "messages": _msgs(system, history), "stream": True,
            "options": {"temperature": temperature, "num_ctx": 4096, "num_predict": max_tokens}}
    in_think, acc = False, ""
    with _ollama(cfg, "/api/chat", body, timeout, stream=True) as r:
        for line in r:
            if not line.strip():
                continue
            d = json.loads(line)
            acc += d.get("message", {}).get("content", "")
            out = ""
            while True:                                   # <think>…</think> von Denkmodellen ausblenden
                if in_think:
                    i = acc.find("</think>")
                    if i == -1:
                        acc = acc[-8:]; break
                    acc, in_think = acc[i + 8:], False
                else:
                    i = acc.find("<think>")
                    if i == -1:
                        keep = max((k for k in range(1, min(7, len(acc) + 1)) if acc.endswith("<think>"[:k])), default=0)
                        out, acc = out + acc[:len(acc) - keep], acc[len(acc) - keep:]
                        break
                    out, acc, in_think = out + acc[:i], acc[i + 7:], True
            if out:
                yield out
            if d.get("done"):
                break
    if acc and not in_think:
        yield acc


class ChatBrain:
    """Gespräch mit einem KI-Modell (Ollama oder Gemini). Antwortet satzweise, damit Via früh anfängt zu sprechen."""
    kind = "llm"

    def __init__(self, cfg, name_fn):
        self.cfg, self.name_fn = cfg, name_fn
        self.history = []

    @property
    def ready(self):
        return ready(self.cfg)

    def reset(self):
        self.history.clear()

    def system(self, assistant):
        import datetime
        now = datetime.datetime.now()
        timers = ", ".join(f"{int(t['rem'])} Sekunden" for t in assistant.snapshot()) or "keine"
        return (f"Du bist {self.name_fn()}, ein freundlicher, kluger Sprachassistent auf dem Computer des Nutzers. "
                "Du duzt ihn und antwortest IMMER auf Deutsch. Deine Antworten werden laut vorgelesen: natürlich und "
                "gesprochen, meistens ein bis drei kurze Sätze, ohne Listen, ohne Markdown, ohne Emojis. "
                "Erfinde keine Fakten; sag ehrlich, wenn du etwas nicht weißt. Timer, Stoppuhren, Wetter, Uhrzeit, "
                "Rechnen, Notizen und das Öffnen von Apps erledigt das System selbst, wenn der Nutzer direkt danach fragt. "
                f"Jetzt ist {now:%d.%m.%Y, %H:%M} Uhr. Standort: {self.cfg.get('city', 'unbekannt')}. Laufende Timer: {timers}.")

    def stream(self, user, assistant):
        msgs = self.history[-10:] + [("user", user)]
        buf, full = "", []
        clean = lambda t: re.sub(r"\s+", " ", re.sub(r"[*_#`>~|]+", "", t)).strip()
        for piece in stream_chunks(self.cfg, self.system(assistant), msgs, 0.7, 90, 300):
            buf += piece
            while True:
                m = SENT.search(buf, 14)
                if not m:
                    break
                sent, buf = clean(buf[:m.start()]), buf[m.end():]
                if sent:
                    full.append(sent); yield sent
        sent = clean(buf)
        if sent:
            full.append(sent); yield sent
        self.history = (msgs + [("model", " ".join(full))])[-12:]
